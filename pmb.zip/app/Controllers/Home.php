<?php

namespace App\Controllers;


use Dompdf\Dompdf as Dompdf;
use Dompdf\Options;

class Home extends BaseController
{
	public function index()
	{
		$pengaturan = $this->pengaturanModel->find(1);
		$data = [
			'title' => 'PMB IAI IBRAHIMY',
			'home' => 'active',
			'online' => '',
			'login' => '',
			'informasi' => '',
			'listmaba' => '',
			'pengatur' => $pengaturan,
			'slider' => $this->SliderModel->findAll()
		];

		echo view('home/beranda', $data);
	}

	public function login()
	{
		$pengaturan = $this->pengaturanModel->find(1);
		$data = [
			'title' => 'PMB LOGIN',
			'home' => '',
			'online' => '',
			'login' => 'active',
			'informasi' => '',
			'listmaba' => '',
			'pengatur' => $pengaturan
		];

		echo view('home/logins', $data);
	}

	public function informasi()
	{
		$pengaturan = $this->pengaturanModel->find(1);
		$data = [
			'title' => 'INFORMASI PMB',
			'home' => '',
			'online' => '',
			'login' => '',
			'informasi' => 'active',
			'listmaba' => '',
			'pengatur' => $pengaturan
		];

		echo view('home/informasion', $data);
	}

	public function login_panitia()
	{
		$pengaturan = $this->pengaturanModel->find(1);
		$data = [
			'title' => 'PMB LOGIN',
			'home' => '',
			'online' => '',
			'login' => 'active',
			'informasi' => '',
			'listmaba' => '',
			'pengatur' => $pengaturan,
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
		];

		echo view('admin/loginpanitia', $data);
	}

	public function login_panitiaa()
	{
		$table = 'panitia_pmb';
		$username = $this->request->getPost('username');
		$password = $this->request->getPost('password');
		$tahun_akademikss = $this->request->getVar('tahun_akademik');
		$row = $this->AuthModel->get_panitia_login($username, $table);

		\session()->set('cobas', $tahun_akademikss);
		if ($row == NULL) {
			session()->setFlashdata('pesan', 'Username Anda Salah');
			return redirect()->to('/home/login_panitia');
		}
		if (password_verify($password, $row->password)) {
			$data = array(
				'log1' => TRUE,
				'nama_panitia' => $row->nama_panitia,
				'username' => $row->username,
			);
			session()->set($data);
			return redirect()->to('/panitia');
		}
		session()->setFlashdata('pesan', 'Password Anda Salah');
		return redirect()->to('/home/login_panitia');
	}

	public function logoutpanitia()
	{
		$session = session();
		$session->destroy();
		session()->setFlashdata('pesan', 'Anda Telah Keluar dari Sistem');
		return redirect()->to('/home/login_panitia');
	}



	public function daftar_online()
	{
		$pengaturan = $this->pengaturanModel->find(1);
		$data = [
			'validation' => $this->validation,
			'title' => 'DAFTAR ONLINE',
			'home' => '',
			'online' => 'active',
			'login' => '',
			'informasi' => '',
			'listmaba' => '',
			'pengatur' => $pengaturan,
			'validation' => $this->validation,
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'gelombang' => $this->GelombangModel->getStatusGelombang(1),
			'jalur_pendaftaran' => $this->MahasiswaModel->getJalurPendaftaran(),
			'jenis_kelamin' => $this->MahasiswaModel->getJenisKelamin(),
			'status_pendaftaran' => $this->MahasiswaModel->getStatusPendaftaran(),
			'agama' => $this->MahasiswaModel->getAgamaa(),
			'wn' => $this->MahasiswaModel->getNegaraa(),
			'status' => $this->MahasiswaModel->getStatuss(),
			'pendidikan_ayah' => $this->MahasiswaModel->getPendidikan(),
			'pekerjaan_ayah' => $this->MahasiswaModel->getPekerjaan(),
			'jurusan' => $this->MahasiswaModel->getJurusann(),
			'penghasilan' => $this->MahasiswaModel->getPenghasilann(),
			'tutup' => $this->TutupModel->find(1),
		];

		echo view('home/daftar-online', $data);
	}

	public function cetakkartu()
	{

		$tahun_akademik = $this->request->getVar('tahun_akademik');
		\session()->set('panda_4', $tahun_akademik);
		$keyword = $this->request->getVar('keyword');
		\session()->set('panda_3', $keyword);

		if ($tahun_akademik) {
			if ($keyword) {
				$cetak = $this->MahasiswaModel9->GetCalonMahasiswa3($tahun_akademik, $keyword);
			} else {
				$cetak = $this->MahasiswaModel9->GetCalonMahasiswa3();
			}
		} else {
			$cetak = $this->MahasiswaModel9->GetCalonMahasiswa3();
		}

		$currentPage = $this->request->getVar('page_mahasiswa_baru') ? $this->request->getVar('page_mahasiswa_baru') : 1;
		$pengaturan = $this->pengaturanModel->find(1);
		$data = [
			'title' => 'CETAK KARTU TES',
			'home' => '',
			'online' => '',
			'login' => '',
			'informasi' => '',
			'listmaba' => 'active',
			'validation' => $this->validation,
			'pengatur' => $pengaturan,
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'cetaks' => $cetak->paginate(10, 'mahasiswa_baru'),
			'pager' => $this->MahasiswaModel9->pager,
			'currentPage' => $currentPage,
			'keywords' => \session('panda_3'),
		];

		echo view('home/cetak-kartu', $data);
	}

	public function daftar_online_magister()
	{
		$pengaturan = $this->pengaturanModel->find(1);
		$data = [
			'validation' => $this->validation,
			'title' => 'DAFTAR ONLINE MAGISTER',
			'home' => '',
			'online' => 'active',
			'login' => '',
			'informasi' => '',
			'listmaba' => '',
			'pengatur' => $pengaturan,
			'validation' => $this->validation,
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'gelombang' => $this->GelombangModel->getStatusGelombang(1),
			'jalur_pendaftaran' => $this->MahasiswaModel->getJalurPendaftaran(),
			'jenis_kelamin' => $this->MahasiswaModel->getJenisKelamin(),
			'status_pendaftaran' => $this->MahasiswaModel->getStatusPendaftaran(),
			'agama' => $this->MahasiswaModel->getAgamaa(),
			'wn' => $this->MahasiswaModel->getNegaraa(),
			'status' => $this->MahasiswaModel->getStatuss(),
			'pendidikan_ayah' => $this->MahasiswaModel->getPendidikan(),
			'pekerjaan_ayah' => $this->MahasiswaModel->getPekerjaan(),
			'jurusan' => $this->MahasiswaModel->getJurusann3(),
			'penghasilan' => $this->MahasiswaModel->getPenghasilann(),
			'tutup' => $this->TutupModel->find(1),
		];

		echo view('home/daftar-online-magister', $data);
	}

	public function daftar_onlines()
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'gelombang' => [
					'label' => 'Gelombang',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendaftaran' => [
					'label' => 'Status Awal Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'bukti_pembayaran' => [
					'label' => 'Bukti Pembayaran',
					'rules' => 'uploaded[bukti_pembayaran]|mime_in[bukti_pembayaran,image/png,image/jpg,image/jpeg]|is_image[bukti_pembayaran]|max_size[bukti_pembayaran,5500]',
					'errors' => [
						'uploaded' => '{field} wajib diisi',
						'mime_in' => '{field} harus berformat PNG atau JPG atau JPEG',
						'max_size' => '{field} tidak boleh lebih dari 5000kb',
					]
				],
				'tahun_akademik' => [
					'label' => 'Tahun Akademik',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalur_pendaftaran' => [
					'label' => 'Jalur Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_mahasiswa' => [
					'label' => 'Nama Lengkap Anda',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nik' => [
					'label' => 'NIK',
					'rules' => 'required|is_unique[mahasiswa_baru.nik]|numeric|exact_length[16]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => '{field} anda sudah terdaftar, anda tidak bisa mengisi form ini lagi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} salah',
					]
				],
				'tempat_lahir' => [
					'label' => 'Tempat Lahir',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_lahir' => [
					'label' => 'Tanggal Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'bulan_lahir' => [
					'label' => 'Bulan Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'tahun_lahir' => [
					'label' => 'Tahun Lahir',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'jenis_kelamin' => [
					'label' => 'Jenis Kelamin',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'agama' => [
					'label' => 'Agama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'wn' => [
					'label' => 'Kewarganegaraan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'status' => [
					'label' => 'Status',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalan' => [
					'label' => 'Jalan',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'dusun' => [
					'label' => 'Dusun',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'rt' => [
					'label' => 'RT',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'rw' => [
					'label' => 'RW',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kelurahan' => [
					'label' => 'Kelurahan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kecamatan' => [
					'label' => 'Kecamatan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kabupaten' => [
					'label' => 'Kabupaten',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'no_hp' => [
					'label' => 'Nomor HP',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'asal_sekolah' => [
					'label' => 'Asal Sekolah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nisn' => [
					'label' => 'NISN',
					'rules' => 'permit_empty|numeric',
					'errors' => [
						'numeric' => '{field} harus angka',
					]
				],
				'tahun_lulus' => [
					'label' => 'Tahun Lulus',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} tidak valid',
					]
				],
				'jurusan_1' => [
					'label' => 'Pilihan Pertama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jurusan_2' => [
					'label' => 'Pilihan Ke-dua',
					'rules' => 'required|differs[jurusan_1]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'differs' => '{field} tidak boleh sama dengan pilihan pertama',
					]
				],
				'nisn' => [
					'label' => 'NISN',
					'rules' => 'required|numeric',
					'errors' => [
						'numeric' => '{field} harus angka',
						'required' => '{field} wajib diisi',
					]
				],
				'tempat_kerja' => [
					'label' => 'Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_tel_kerja' => [
					'label' => 'Nomor Telpon Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'alamat_temker' => [
					'label' => 'Alamat Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nama_ayah' => [
					'label' => 'Nama Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_ibu' => [
					'label' => 'Nama Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'penghasilan_wali' => [
					'label' => 'Penghasilan Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_hp_wali' => [
					'label' => 'Nomor HP Wali',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'alamat_wali' => [
					'label' => 'Alamat Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_daftar' => [
					'label' => 'Tanggal Daftar',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_rekomendasi' => [
					'label' => 'Nama Perekomendasi',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_rekomendasi' => [
					'label' => 'Nomor HP Perekomendasi',
					'rules' => 'permit_empty|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'gelombang' => $validation->getError('gelombang'),
						'pendaftaran' => $validation->getError('pendaftaran'),
						'bukti_pembayaran' => $validation->getError('bukti_pembayaran'),
						'tahun_akademik' => $validation->getError('tahun_akademik'),
						'jalur_pendaftaran' => $validation->getError('jalur_pendaftaran'),
						'nama_mahasiswa' => $validation->getError('nama_mahasiswa'),
						'nik' => $validation->getError('nik'),
						'tempat_lahir' => $validation->getError('tempat_lahir'),
						'tanggal_lahir' => $validation->getError('tanggal_lahir'),
						'bulan_lahir' => $validation->getError('bulan_lahir'),
						'tahun_lahir' => $validation->getError('tahun_lahir'),
						'jenis_kelamin' => $validation->getError('jenis_kelamin'),
						'agama' => $validation->getError('agama'),
						'wn' => $validation->getError('wn'),
						'status' => $validation->getError('status'),
						'jalan' => $validation->getError('jalan'),
						'dusun' => $validation->getError('dusun'),
						'rt' => $validation->getError('rt'),
						'rw' => $validation->getError('rw'),
						'kelurahan' => $validation->getError('kelurahan'),
						'kecamatan' => $validation->getError('kecamatan'),
						'kabupaten' => $validation->getError('kabupaten'),
						'no_hp' => $validation->getError('no_hp'),
						'asal_sekolah' => $validation->getError('asal_sekolah'),
						'nisn' => $validation->getError('nisn'),
						'tahun_lulus' => $validation->getError('tahun_lulus'),
						'jurusan_1' => $validation->getError('jurusan_1'),
						'jurusan_2' => $validation->getError('jurusan_2'),
						'tempat_kerja' => $validation->getError('tempat_kerja'),
						'nomor_tel_kerja' => $validation->getError('nomor_tel_kerja'),
						'alamat_temker' => $validation->getError('alamat_temker'),
						'nama_ayah' => $validation->getError('nama_ayah'),
						'pendidikan_ayah' => $validation->getError('pendidikan_ayah'),
						'pekerjaan_ayah' => $validation->getError('pekerjaan_ayah'),
						'nama_ibu' => $validation->getError('nama_ibu'),
						'pendidikan_ibu' => $validation->getError('pendidikan_ibu'),
						'pekerjaan_ibu' => $validation->getError('pekerjaan_ibu'),
						'penghasilan_wali' => $validation->getError('penghasilan_wali'),
						'nomor_hp_wali' => $validation->getError('nomor_hp_wali'),
						'alamat_wali' => $validation->getError('alamat_wali'),
						'nama_rekomendasi' => $validation->getError('nama_rekomendasi'),
						'nomor_rekomendasi' => $validation->getError('nomor_rekomendasi'),
						'tanggal_daftar' => $validation->getError('tanggal_daftar'),
					]
				];
			} else {

				$filebuktipembayaran = $this->request->getFile('bukti_pembayaran');
				$namabuktipembayaran = $filebuktipembayaran->getRandomName();
				$filebuktipembayaran->move('homes/buktitf', $namabuktipembayaran);
				

				$this->MahasiswaModel->save([
					'id_status_pendaftaran' => '2',
					'id_gelombang' => $this->request->getVar('gelombang'),
					'pendaftaran' => $this->request->getVar('pendaftaran'),
					'tahun_akademik' => $this->request->getVar('tahun_akademik'),
					'id_jalur_pendaftaran' => $this->request->getVar('jalur_pendaftaran'),
					'bukti_pembayaran' => $namabuktipembayaran,
					'smt_1' => 'raport-hardfile.jpg',
					'smt_2' => 'raport-hardfile.jpg',
					'id_validasi_pendaftaran' => '0',
					'nama_mahasiswa' => $this->request->getVar('nama_mahasiswa'),
					'rerata_smt1' => 'Raport Offline',
					'rerata_smt2' => 'Raport Offline',
					'nik' => $this->request->getVar('nik'),
					'tempat_lahir' => $this->request->getVar('tempat_lahir'),
					'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
					'bulan_lahir' => $this->request->getVar('bulan_lahir'),
					'tahun_lahir' => $this->request->getVar('tahun_lahir'),
					'id_jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
					'id_agama' => $this->request->getVar('agama'),
					'id_wn' => $this->request->getVar('wn'),
					'id_status' => $this->request->getVar('status'),
					'nama_jalan' => $this->request->getVar('jalan'),
					'dusun' => $this->request->getVar('dusun'),
					'rt' => $this->request->getVar('rt'),
					'rw' => $this->request->getVar('rw'),
					'kelurahan' => $this->request->getVar('kelurahan'),
					'kecamatan' => $this->request->getVar('kecamatan'),
					'kabupaten' => $this->request->getVar('kabupaten'),
					'no_hp' => $this->request->getVar('no_hp'),
					'asal_sekolah' => $this->request->getVar('asal_sekolah'),
					'nisn' => $this->request->getVar('nisn'),
					'tahun_lulus' => $this->request->getVar('tahun_lulus'),
					'id_pilihan_1' => $this->request->getVar('jurusan_1'),
					'id_pilihan_2' => $this->request->getVar('jurusan_2'),
					'nama_tempat_kerja' => $this->request->getVar('tempat_kerja'),
					'nomor_telephone_kerja' => $this->request->getVar('nomor_tel_kerja'),
					'alamat_tempat_kerja' => $this->request->getVar('alamat_temker'),
					'nama_ayah' => $this->request->getVar('nama_ayah'),
					'id_pendidikan_ayah' => $this->request->getVar('pendidikan_ayah'),
					'id_pekerjaan_ayah' => $this->request->getVar('pekerjaan_ayah'),
					'nama_ibu' => $this->request->getVar('nama_ibu'),
					'id_pendidikan_ibu' => $this->request->getVar('pendidikan_ibu'),
					'id_pekerjaan_ibu' => $this->request->getVar('pekerjaan_ibu'),
					'id_penghasilan_wali' => $this->request->getVar('penghasilan_wali'),
					'nomor_hp_wali' => $this->request->getVar('nomor_hp_wali'),
					'alamat_wali' => $this->request->getVar('alamat_wali'),
					'nama_rekomendasi' => $this->request->getVar('nama_rekomendasi'),
					'nomor_rekomendasi' => $this->request->getVar('nomor_rekomendasi'),
					'tanggal_daftar' => $this->request->getVar('tanggal_daftar'),
					'code_recom' => password_hash($this->request->getVar('nama_rekomendasi'), PASSWORD_DEFAULT),
				]);

				$msg = [
					'sukses' => 'Selamat!! Pendaftaran anda berhasil. Tunggu Validasi untuk mencetak kartu anda di tab CETAK KARTU BUKTI PENDAFTARAN'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/daftar-online');
		}
	}

	public function daftar_onlines_magister()
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'gelombang' => [
					'label' => 'Gelombang',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendaftaran' => [
					'label' => 'Status Awal Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'bukti_pembayaran' => [
					'label' => 'Bukti Pembayaran',
					'rules' => 'uploaded[bukti_pembayaran]|mime_in[bukti_pembayaran,image/png,image/jpg,image/jpeg]|is_image[bukti_pembayaran]|max_size[bukti_pembayaran,5500]',
					'errors' => [
						'uploaded' => '{field} wajib diisi',
						'mime_in' => '{field} harus berformat PNG atau JPG atau JPEG',
						'max_size' => '{field} tidak boleh lebih dari 5000kb',
					]
				],
				'tahun_akademik' => [
					'label' => 'Tahun Akademik',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalur_pendaftaran' => [
					'label' => 'Jalur Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'foto_smt1' => [
					'label' => 'File Transkip Nilai ',
					'rules' => 'uploaded[foto_smt1]|mime_in[foto_smt1,application/pdf]|max_size[foto_smt1,5000]',
					'errors' => [
						'uploaded' => '{field} wajib diisi',
						'mime_in' => '{field} harus berformat PDF',
						'max_size' => '{field} tidak boleh lebih dari 5000kb',
					]
				],
				'rata_rata1' => [
					'label' => 'Nilai IPK',
					'rules' => 'required|numeric',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
					]
				],
				'nama_mahasiswa' => [
					'label' => 'Nama Lengkap Anda',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nik' => [
					'label' => 'NIK',
					'rules' => 'required|is_unique[mahasiswa_baru.nik]|numeric|exact_length[16]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => '{field} anda sudah terdaftar, anda tidak bisa mengisi form ini lagi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} salah',
					]
				],
				'tempat_lahir' => [
					'label' => 'Tempat Lahir',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_lahir' => [
					'label' => 'Tanggal Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'bulan_lahir' => [
					'label' => 'Bulan Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'tahun_lahir' => [
					'label' => 'Tahun Lahir',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'jenis_kelamin' => [
					'label' => 'Jenis Kelamin',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'agama' => [
					'label' => 'Agama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'wn' => [
					'label' => 'Kewarganegaraan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'status' => [
					'label' => 'Status',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalan' => [
					'label' => 'Jalan',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'dusun' => [
					'label' => 'Dusun',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'rt' => [
					'label' => 'RT',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'rw' => [
					'label' => 'RW',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kelurahan' => [
					'label' => 'Kelurahan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kecamatan' => [
					'label' => 'Kecamatan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kabupaten' => [
					'label' => 'Kabupaten',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'no_hp' => [
					'label' => 'Nomor HP',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],

				'jurusan_1' => [
					'label' => 'Pilihan Pertama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tempat_kerja' => [
					'label' => 'Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_tel_kerja' => [
					'label' => 'Nomor Telpon Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'alamat_temker' => [
					'label' => 'Alamat Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nama_ayah' => [
					'label' => 'Nama Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_ibu' => [
					'label' => 'Nama Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'penghasilan_wali' => [
					'label' => 'Penghasilan Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_hp_wali' => [
					'label' => 'Nomor HP Wali',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'alamat_wali' => [
					'label' => 'Alamat Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_daftar' => [
					'label' => 'Tanggal Daftar',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_rekomendasi' => [
					'label' => 'Nama Perekomendasi',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_rekomendasi' => [
					'label' => 'Nomor HP Perekomendasi',
					'rules' => 'permit_empty|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'nama_kampus' => [
					'label' => 'Asal Kampus',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'prodi_sarjana' => [
					'label' => 'Asal Prodi Sarjana',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'ipk_sarjana' => [
					'label' => 'IPK Sarjana',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'namsd_sar' => [
					'label' => 'Nama SD/MI',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'namsmp_sar' => [
					'label' => 'Nama SMP/MTS',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'namsma_sar' => [
					'label' => 'Nama SMA/MA',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tlulus_sd' => [
					'label' => 'Tahun Lulus SD/MI',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'tlulus_smp' => [
					'label' => 'Tahun Lulus SMP/MTS',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'tlulus_sma' => [
					'label' => 'Tahun Lulus SMA/MA',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'tlulus_kul' => [
					'label' => 'Tahun Lulus Sarjana',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'noser_ijas' => [
					'label' => 'Nomor Seri Ijasah Sarjana',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'byatung' => [
					'label' => 'Tanggungan Biaya',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'gelombang' => $validation->getError('gelombang'),
						'pendaftaran' => $validation->getError('pendaftaran'),
						'bukti_pembayaran' => $validation->getError('bukti_pembayaran'),
						'foto_smt1' => $validation->getError('foto_smt1'),
						'rata_rata1' => $validation->getError('rata_rata1'),
						'tahun_akademik' => $validation->getError('tahun_akademik'),
						'jalur_pendaftaran' => $validation->getError('jalur_pendaftaran'),
						'nama_mahasiswa' => $validation->getError('nama_mahasiswa'),
						'nik' => $validation->getError('nik'),
						'tempat_lahir' => $validation->getError('tempat_lahir'),
						'tanggal_lahir' => $validation->getError('tanggal_lahir'),
						'bulan_lahir' => $validation->getError('bulan_lahir'),
						'tahun_lahir' => $validation->getError('tahun_lahir'),
						'jenis_kelamin' => $validation->getError('jenis_kelamin'),
						'agama' => $validation->getError('agama'),
						'wn' => $validation->getError('wn'),
						'status' => $validation->getError('status'),
						'jalan' => $validation->getError('jalan'),
						'dusun' => $validation->getError('dusun'),
						'rt' => $validation->getError('rt'),
						'rw' => $validation->getError('rw'),
						'kelurahan' => $validation->getError('kelurahan'),
						'kecamatan' => $validation->getError('kecamatan'),
						'kabupaten' => $validation->getError('kabupaten'),
						'no_hp' => $validation->getError('no_hp'),
						'jurusan_1' => $validation->getError('jurusan_1'),
						'tempat_kerja' => $validation->getError('tempat_kerja'),
						'nomor_tel_kerja' => $validation->getError('nomor_tel_kerja'),
						'alamat_temker' => $validation->getError('alamat_temker'),
						'nama_ayah' => $validation->getError('nama_ayah'),
						'pendidikan_ayah' => $validation->getError('pendidikan_ayah'),
						'pekerjaan_ayah' => $validation->getError('pekerjaan_ayah'),
						'nama_ibu' => $validation->getError('nama_ibu'),
						'pendidikan_ibu' => $validation->getError('pendidikan_ibu'),
						'pekerjaan_ibu' => $validation->getError('pekerjaan_ibu'),
						'penghasilan_wali' => $validation->getError('penghasilan_wali'),
						'nomor_hp_wali' => $validation->getError('nomor_hp_wali'),
						'alamat_wali' => $validation->getError('alamat_wali'),
						'nama_rekomendasi' => $validation->getError('nama_rekomendasi'),
						'nomor_rekomendasi' => $validation->getError('nomor_rekomendasi'),
						'tanggal_daftar' => $validation->getError('tanggal_daftar'),
						'nama_kampus' => $validation->getError('nama_kampus'),
						'prodi_sarjana' => $validation->getError('prodi_sarjana'),
						'ipk_sarjana' => $validation->getError('ipk_sarjana'),
						'namsd_sar' => $validation->getError('namsd_sar'),
						'namsmp_sar' => $validation->getError('namsmp_sar'),
						'namsma_sar' => $validation->getError('namsma_sar'),
						'tlulus_sd' => $validation->getError('tlulus_sd'),
						'tlulus_smp' => $validation->getError('tlulus_smp'),
						'tlulus_sma' => $validation->getError('tlulus_sma'),
						'tlulus_kul' => $validation->getError('tlulus_kul'),
						'noser_ijas' => $validation->getError('noser_ijas'),
						'byatung' => $validation->getError('byatung'),
					]
				];
			} else {

				$filebuktipembayaran = $this->request->getFile('bukti_pembayaran');
				$namabuktipembayaran = $filebuktipembayaran->getRandomName();
				$filebuktipembayaran->move('homes/buktitf', $namabuktipembayaran);

				$filefotosmt1 = $this->request->getFile('foto_smt1');
				$namafilesmt1 = $filefotosmt1->getRandomName();
				$filefotosmt1->move('homes/smt1', $namafilesmt1);

				$this->MahasiswaModel->save([
					'id_status_pendaftaran' => '2',
					'id_gelombang' => $this->request->getVar('gelombang'),
					'pendaftaran' => $this->request->getVar('pendaftaran'),
					'tahun_akademik' => $this->request->getVar('tahun_akademik'),
					'id_jalur_pendaftaran' => $this->request->getVar('jalur_pendaftaran'),
					'bukti_pembayaran' => $namabuktipembayaran,
					'smt_1' => $namafilesmt1,
					'smt_2' => 'pascasarjana.jpg',
					'id_validasi_pendaftaran' => '0',
					'nama_mahasiswa' => $this->request->getVar('nama_mahasiswa'),
					'rerata_smt1' => $this->request->getVar('rata_rata1'),
					'rerata_smt1' => 'Pascasarjana',
					'nik' => $this->request->getVar('nik'),
					'tempat_lahir' => $this->request->getVar('tempat_lahir'),
					'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
					'bulan_lahir' => $this->request->getVar('bulan_lahir'),
					'tahun_lahir' => $this->request->getVar('tahun_lahir'),
					'id_jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
					'id_agama' => $this->request->getVar('agama'),
					'id_wn' => $this->request->getVar('wn'),
					'id_status' => $this->request->getVar('status'),
					'nama_jalan' => $this->request->getVar('jalan'),
					'dusun' => $this->request->getVar('dusun'),
					'rt' => $this->request->getVar('rt'),
					'rw' => $this->request->getVar('rw'),
					'kelurahan' => $this->request->getVar('kelurahan'),
					'kecamatan' => $this->request->getVar('kecamatan'),
					'kabupaten' => $this->request->getVar('kabupaten'),
					'no_hp' => $this->request->getVar('no_hp'),
					'id_pilihan_1' => $this->request->getVar('jurusan_1'),
					'id_pilihan_2' => '9',
					'nama_tempat_kerja' => $this->request->getVar('tempat_kerja'),
					'nomor_telephone_kerja' => $this->request->getVar('nomor_tel_kerja'),
					'alamat_tempat_kerja' => $this->request->getVar('alamat_temker'),
					'nama_ayah' => $this->request->getVar('nama_ayah'),
					'id_pendidikan_ayah' => $this->request->getVar('pendidikan_ayah'),
					'id_pekerjaan_ayah' => $this->request->getVar('pekerjaan_ayah'),
					'nama_ibu' => $this->request->getVar('nama_ibu'),
					'id_pendidikan_ibu' => $this->request->getVar('pendidikan_ibu'),
					'id_pekerjaan_ibu' => $this->request->getVar('pekerjaan_ibu'),
					'id_penghasilan_wali' => $this->request->getVar('penghasilan_wali'),
					'nomor_hp_wali' => $this->request->getVar('nomor_hp_wali'),
					'alamat_wali' => $this->request->getVar('alamat_wali'),
					'nama_rekomendasi' => $this->request->getVar('nama_rekomendasi'),
					'nomor_rekomendasi' => $this->request->getVar('nomor_rekomendasi'),
					'tanggal_daftar' => $this->request->getVar('tanggal_daftar'),
					'nama_kampus' => $this->request->getVar('nama_kampus'),
					'prodi_sarjana' => $this->request->getVar('prodi_sarjana'),
					'ipk_sarjana' => $this->request->getVar('ipk_sarjana'),
					'namsd_sar' => $this->request->getVar('namsd_sar'),
					'namsmp_sar' => $this->request->getVar('namsmp_sar'),
					'namsma_sar' => $this->request->getVar('namsma_sar'),
					'tlulus_sd' => $this->request->getVar('tlulus_sd'),
					'tlulus_smp' => $this->request->getVar('tlulus_smp'),
					'tlulus_sma' => $this->request->getVar('tlulus_sma'),
					'tlulus_kul' => $this->request->getVar('tlulus_kul'),
					'noser_ijas' => $this->request->getVar('noser_ijas'),
					'byatung' => $this->request->getVar('byatung'),
					'code_recom' => password_hash($this->request->getVar('nama_rekomendasi'), PASSWORD_DEFAULT),
				]);

				$msg = [
					'sukses' => 'Selamat!! Pendaftaran anda berhasil. Tunggu Validasi untuk mencetak kartu anda di tab CETAK KARTU'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/daftar-online-magister');
		}
	}


	public function login_developer()
	{
		$pengaturan = $this->pengaturanModel->find(1);
		$data = [
			'title' => 'PMB LOGIN',
			'home' => '',
			'online' => '',
			'login' => 'active',
			'informasi' => '',
			'listmaba' => '',
			'pengatur' => $pengaturan
		];

		echo view('admin/logindeveloper', $data);
	}

	public function login_developerr()
	{
		$tabl = 'developer';
		$username = $this->request->getPost('username');
		$password = $this->request->getPost('password');
		$row = $this->AutheModel->get_developer_login($username, $tabl);

		if ($row == NULL) {
			session()->setFlashdata('pesan', 'Username Anda Salah');
			return redirect()->to('/home/login_developer');
		}
		if (password_verify($password, $row->password)) {
			$data = array(
				'log2' => TRUE,
				'nama_developer' => $row->nama_developer,
				'username' => $row->username,
			);
			session()->set($data);
			return redirect()->to('/developer');
		}
		session()->setFlashdata('pesan', 'Password Anda Salah');
		return redirect()->to('/home/login_developer');
	}

	public function logoutdeveloper()
	{
		$session = session();
		$session->destroy();
		session()->setFlashdata('pesan', 'Anda Telah Keluar dari Sistem');
		return redirect()->to('/home/login_developer');
	}

	public function simpankartu($nomor_pendaftaran)
	{
		$data = [
			'gelombangs' => $this->MahasiswaModel->getMahasiswa5($nomor_pendaftaran),
			'kartu' => $this->KartuModel->find(1),
		];

		echo view('home/download-kartu', $data);
	}
}
