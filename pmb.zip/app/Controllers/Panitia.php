<?php

namespace App\Controllers;

class Panitia extends BaseController
{
	public function index()
	{

		$tahun_akademik = \session('cobas');
		\session()->set('panda_1', $tahun_akademik);
		if ($tahun_akademik) {
			$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
			$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
			$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
			$ekos1 = $this->MahasiswaModel->GetEkos1($tahun_akademik);
			$ekos2 = $this->MahasiswaModel->GetEkos2($tahun_akademik);
			$laki = $this->MahasiswaModel->GetCountLaki($tahun_akademik);
			$cewek = $this->MahasiswaModel->GetCountCewek($tahun_akademik);
			$gel1 = $this->MahasiswaModel->GetCountGel1($tahun_akademik);
			$gel2 = $this->MahasiswaModel->GetCountGel2($tahun_akademik);
			$pai1 = $this->MahasiswaModel->GetPai1($tahun_akademik);
			$pai2 = $this->MahasiswaModel->GetPai2($tahun_akademik);
			$pgmi1 = $this->MahasiswaModel->GetPgmi1($tahun_akademik);
			$pgmi2 = $this->MahasiswaModel->GetPgmi2($tahun_akademik);
			$piaud1 = $this->MahasiswaModel->GetPiaud1($tahun_akademik);
			$piaud2 = $this->MahasiswaModel->GetPiaud2($tahun_akademik);
			$ps1 = $this->MahasiswaModel->GetPs1($tahun_akademik);
			$ps2 = $this->MahasiswaModel->GetPs2($tahun_akademik);
			$hki1 = $this->MahasiswaModel->GetHki1($tahun_akademik);
			$hki2 = $this->MahasiswaModel->GetHki2($tahun_akademik);
			$pmi1 = $this->MahasiswaModel->GetPmi1($tahun_akademik);
			$pmi2 = $this->MahasiswaModel->GetPmi2($tahun_akademik);
			$mat1 = $this->MahasiswaModel->GetMat1($tahun_akademik);
			$mat2 = $this->MahasiswaModel->GetMat2($tahun_akademik);
			$pasca = $this->MahasiswaModel->GetPasca($tahun_akademik);
		} else {
			$havevalidation = "error";
			$allpendaftar = "error";
		}

		$data = [
			'title' => 'PMB IAI IBRAHIMY',
			'dashboard' => 'active',
			'gel' => '',
			'gel1' => '',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'gelombang' => $this->MahasiswaModel->getGelombang(),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'laki' => $laki,
			'cewek' => $cewek,
			'gel1' => $gel1,
			'gel2' => $gel2,
			'pai1' => $pai1,
			'pai2' => $pai2,
			'pgmi1' => $pgmi1,
			'pgmi2' => $pgmi2,
			'piaud1' => $piaud1,
			'piaud2' => $piaud2,
			'ekos1' => $ekos1,
			'ekos2' => $ekos2,
			'ps1' => $ps1,
			'ps2' => $ps2,
			'hki1' => $hki1,
			'hki2' => $hki2,
			'pmi1' => $pmi1,
			'pmi2' => $pmi2,
			'mat1' => $mat1,
			'mat2' => $mat2,
			'pasca' => $pasca,
			'validation' => $this->validation,
		];

		echo view('admin/panitia/panitia-pmb', $data);
	}

	public function tmahasiswa()
	{
		if (!$this->validate([
			'nomor_pendaftaran' => [
				'rules' => 'required|is_unique[mahasiswa_baru.nomor_pendaftaran]',
				'errors' => [
					'required' => 'Nomor Pendaftaran wajib diisi',
					'is_unique' => 'Nomor Pendaftaran sudah terdaftar',
					'numeric' => 'Nomor Pendaftaran harus berbentuk angka',
				]
			],
			'gelombang' => [
				'rules' => 'required',
				'errors' => [
					'required' => 'Gelombang wajib diisi',
				]
			],
			'password_mahasiswa' => [
				'rules' => 'required|min_length[4]',
				'errors' => [
					'required' => 'Password tidak boleh kosong',
					'min_length' => 'Password minimal 4 karakter',
				]
			]
		])) {
			return redirect()->to('/panitia')->withInput()->with('validation', $this->validation);
		}

		$this->MahasiswaModel->save([
			'nomor_pendaftaran' => $this->request->getVar('nomor_pendaftaran'),
			'id_gelombang' => $this->request->getVar('gelombang'),
			'password_mahasiswa' => password_hash($this->request->getVar('password_mahasiswa'), PASSWORD_DEFAULT),
		]);

		session()->setFlashdata('pesan', 'Panitia baru berhasil ditambahkan');

		return redirect()->to('/panitia');
	}

	public function tammhs()
	{

		$tahun_akademik = \session('cobas');
		if ($tahun_akademik) {
			$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
			$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
			$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
			$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
			$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
			$nomorpai = $this->MahasiswaModel->GetNomorPai($tahun_akademik);
			$nomorpgmi = $this->MahasiswaModel2->GetNomorPgmi($tahun_akademik);
			$nomorpiaud = $this->MahasiswaModel3->GetNomorPiaud($tahun_akademik);
			$nomorekos = $this->MahasiswaModel4->GetNomorEkos($tahun_akademik);
			$nomorps = $this->MahasiswaModel5->GetNomorPs($tahun_akademik);
			$nomorhki = $this->MahasiswaModel6->GetNomorHki($tahun_akademik);
			$nomorpmi = $this->MahasiswaModel7->GetNomorPmi($tahun_akademik);
			$nomormat = $this->MahasiswaModel11->GetNomorMat($tahun_akademik);
		} else {
			$havevalidation = "error";
			$allpendaftar = "error";
			$nomorpai = "Error";
		}

		$data = [
			'title' => 'FORM TAMBAH MAHASISWA',
			'dashboard' => '',
			'gel' => 'active',
			'gel1' => 'active',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'gelombang' => $this->GelombangModel->getStatusGelombang(1),
			'jalur_pendaftaran' => $this->MahasiswaModel->getJalurPendaftaran(),
			'status_pendaftaran' => $this->MahasiswaModel->getStatusPendaftaran(),
			'jenis_kelamin' => $this->MahasiswaModel->getJenisKelamin(),
			'agama' => $this->MahasiswaModel->getAgamaa(),
			'wn' => $this->MahasiswaModel->getNegaraa(),
			'status' => $this->MahasiswaModel->getStatuss(),
			'pendidikan_ayah' => $this->MahasiswaModel->getPendidikan(),
			'pekerjaan_ayah' => $this->MahasiswaModel->getPekerjaan(),
			'jurusan' => $this->MahasiswaModel->getJurusann(),
			'penghasilan' => $this->MahasiswaModel->getPenghasilann(),
			'nomor_pai' => $nomorpai->paginate(1),
			'nomor_pgmi' => $nomorpgmi->paginate(1),
			'nomor_piaud' => $nomorpiaud->paginate(1),
			'nomor_ekos' => $nomorekos->paginate(1),
			'nomor_ps' => $nomorps->paginate(1),
			'nomor_hki' => $nomorhki->paginate(1),
			'nomor_pmi' => $nomorpmi->paginate(1),
			'nomor_mat' => $nomormat->paginate(1),
			'tutup' => $this->TutupModel->find(1),
		];

		return view('admin/panitia/tambah-calon-mahasiswa', $data);
	}

	public function tammhsmgs()
	{

		$tahun_akademik = \session('cobas');
		if ($tahun_akademik) {
			$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
			$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
			$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
			$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
			$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
			$nomorpai = $this->MahasiswaModel->GetNomorPai($tahun_akademik);
			$nomorpgmi = $this->MahasiswaModel2->GetNomorPgmi($tahun_akademik);
			$nomorpiaud = $this->MahasiswaModel3->GetNomorPiaud($tahun_akademik);
			$nomorekos = $this->MahasiswaModel4->GetNomorEkos($tahun_akademik);
			$nomorps = $this->MahasiswaModel5->GetNomorPs($tahun_akademik);
			$nomorhki = $this->MahasiswaModel6->GetNomorHki($tahun_akademik);
			$nomorpmi = $this->MahasiswaModel7->GetNomorPmi($tahun_akademik);
			$nomormagisterpai = $this->MahasiswaModel10->GetNomorMagisterPai($tahun_akademik);
		} else {
			$havevalidation = "error";
			$allpendaftar = "error";
			$nomorpai = "Error";
		}

		$data = [
			'title' => 'FORM TAMBAH MAHASISWA MAGISTER',
			'dashboard' => '',
			'gel' => 'active',
			'gel1' => 'active',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'gelombang' => $this->GelombangModel->getStatusGelombang(1),
			'jalur_pendaftaran' => $this->MahasiswaModel->getJalurPendaftaran(),
			'status_pendaftaran' => $this->MahasiswaModel->getStatusPendaftaran(),
			'jenis_kelamin' => $this->MahasiswaModel->getJenisKelamin(),
			'agama' => $this->MahasiswaModel->getAgamaa(),
			'wn' => $this->MahasiswaModel->getNegaraa(),
			'status' => $this->MahasiswaModel->getStatuss(),
			'pendidikan_ayah' => $this->MahasiswaModel->getPendidikan(),
			'pekerjaan_ayah' => $this->MahasiswaModel->getPekerjaan(),
			'jurusan' => $this->MahasiswaModel->getJurusann3(),
			'jurusan2' => $this->MahasiswaModel->getJurusann4(),
			'penghasilan' => $this->MahasiswaModel->getPenghasilann(),
			'nomor_pai' => $nomorpai->paginate(1),
			'nomor_pgmi' => $nomorpgmi->paginate(1),
			'nomor_piaud' => $nomorpiaud->paginate(1),
			'nomor_ekos' => $nomorekos->paginate(1),
			'nomor_ps' => $nomorps->paginate(1),
			'nomor_hki' => $nomorhki->paginate(1),
			'nomor_pmi' => $nomorpmi->paginate(1),
			'nomor_magisterpai' => $nomormagisterpai->paginate(1),
			'tutup' => $this->TutupModel->find(1),
		];

		return view('admin/panitia/tambah-calon-mahasiswa-magister', $data);
	}


	public function tambahmhs()
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'gelombang' => [
					'label' => 'Gelombang',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendaftaran' => [
					'label' => 'Status Awal',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_daftar' => [
					'label' => 'Tanggal Daftar',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tahun_akademik' => [
					'label' => 'Tahun Akademik',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalur_pendaftaran' => [
					'label' => 'Jalur Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_pendaftaran' => [
					'label' => 'Nomor Pendaftaran',
					'rules' => 'required|is_unique[mahasiswa_baru.nomor_pendaftaran]|numeric|exact_length[9]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => '{field} sudah ada, coba cari yang lain',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 9 digit angka',
					]
				],
				'nama_mahasiswa' => [
					'label' => 'Nama Lengkap Anda',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nik' => [
					'label' => 'NIK',
					'rules' => 'required|is_unique[mahasiswa_baru.nik]|numeric|exact_length[16]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => '{field} NIK anda sudah terdaftar, anda tidak bisa mengisi form ini lagi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 16 digit angka',
					]
				],
				'tempat_lahir' => [
					'label' => 'Tempat Lahir',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_lahir' => [
					'label' => 'Tanggal Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'bulan_lahir' => [
					'label' => 'Bulan Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'tahun_lahir' => [
					'label' => 'Tahun Lahir',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'jenis_kelamin' => [
					'label' => 'Jenis Kelamin',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'agama' => [
					'label' => 'Agama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'wn' => [
					'label' => 'Kewarganegaraan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'status' => [
					'label' => 'Status',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalan' => [
					'label' => 'Jalan',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'dusun' => [
					'label' => 'Dusun',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'rt' => [
					'label' => 'RT',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'rw' => [
					'label' => 'RW',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kelurahan' => [
					'label' => 'Kelurahan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kecamatan' => [
					'label' => 'Kecamatan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kabupaten' => [
					'label' => 'Kabupaten',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'no_hp' => [
					'label' => 'Nomor HP',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'asal_sekolah' => [
					'label' => 'Asal Sekolah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nisn' => [
					'label' => 'NISN',
					'rules' => 'required|numeric',
					'errors' => [
						'numeric' => '{field} harus angka',
						'required' => '{field} wajib diisi',
					]
				],
				'tahun_lulus' => [
					'label' => 'Tahun Lulus',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} tidak valid',
					]
				],
				'jurusan_1' => [
					'label' => 'Pilihan Pertama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jurusan_2' => [
					'label' => 'Pilihan Ke-dua',
					'rules' => 'required|differs[jurusan_1]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'differs' => '{field} tidak boleh sama dengan pilihan pertama',
					]
				],
				'nisn' => [
					'label' => 'NISN',
					'rules' => 'permit_empty|numeric',
					'errors' => [
						'numeric' => '{field} harus angka',
					]
				],
				'tempat_kerja' => [
					'label' => 'Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_tel_kerja' => [
					'label' => 'Nomor Telpon Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'alamat_temker' => [
					'label' => 'Alamat Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nama_ayah' => [
					'label' => 'Nama Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_ibu' => [
					'label' => 'Nama Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'penghasilan_wali' => [
					'label' => 'Penghasilan Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_hp_wali' => [
					'label' => 'Nomor HP Wali',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'alamat_wali' => [
					'label' => 'Alamat Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_rekomendasi' => [
					'label' => 'Nama Perekomendasi',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_rekomendasi' => [
					'label' => 'Nomor HP Perekomendasi',
					'rules' => 'permit_empty|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'tanggal_daftar' => $validation->getError('tanggal_daftar'),
						'pendaftaran' => $validation->getError('pendaftaran'),
						'gelombang' => $validation->getError('gelombang'),
						'tahun_akademik' => $validation->getError('tahun_akademik'),
						'jalur_pendaftaran' => $validation->getError('jalur_pendaftaran'),
						'nomor_pendaftaran' => $validation->getError('nomor_pendaftaran'),
						'nama_mahasiswa' => $validation->getError('nama_mahasiswa'),
						'nik' => $validation->getError('nik'),
						'tempat_lahir' => $validation->getError('tempat_lahir'),
						'tanggal_lahir' => $validation->getError('tanggal_lahir'),
						'bulan_lahir' => $validation->getError('bulan_lahir'),
						'tahun_lahir' => $validation->getError('tahun_lahir'),
						'jenis_kelamin' => $validation->getError('jenis_kelamin'),
						'agama' => $validation->getError('agama'),
						'wn' => $validation->getError('wn'),
						'status' => $validation->getError('status'),
						'jalan' => $validation->getError('jalan'),
						'dusun' => $validation->getError('dusun'),
						'rt' => $validation->getError('rt'),
						'rw' => $validation->getError('rw'),
						'kelurahan' => $validation->getError('kelurahan'),
						'kecamatan' => $validation->getError('kecamatan'),
						'kabupaten' => $validation->getError('kabupaten'),
						'no_hp' => $validation->getError('no_hp'),
						'asal_sekolah' => $validation->getError('asal_sekolah'),
						'nisn' => $validation->getError('nisn'),
						'tahun_lulus' => $validation->getError('tahun_lulus'),
						'jurusan_1' => $validation->getError('jurusan_1'),
						'jurusan_2' => $validation->getError('jurusan_2'),
						'tempat_kerja' => $validation->getError('tempat_kerja'),
						'nomor_tel_kerja' => $validation->getError('nomor_tel_kerja'),
						'alamat_temker' => $validation->getError('alamat_temker'),
						'nama_ayah' => $validation->getError('nama_ayah'),
						'pendidikan_ayah' => $validation->getError('pendidikan_ayah'),
						'pekerjaan_ayah' => $validation->getError('pekerjaan_ayah'),
						'nama_ibu' => $validation->getError('nama_ibu'),
						'pendidikan_ibu' => $validation->getError('pendidikan_ibu'),
						'pekerjaan_ibu' => $validation->getError('pekerjaan_ibu'),
						'penghasilan_wali' => $validation->getError('penghasilan_wali'),
						'nomor_hp_wali' => $validation->getError('nomor_hp_wali'),
						'alamat_wali' => $validation->getError('alamat_wali'),
						'nama_rekomendasi' => $validation->getError('nama_rekomendasi'),
						'nomor_rekomendasi' => $validation->getError('nomor_rekomendasi'),
					]
				];
			} else {
				$this->MahasiswaModel->save([
					'id_status_pendaftaran' => '1',
					'pendaftaran' => $this->request->getVar('pendaftaran'),
					'id_gelombang' => $this->request->getVar('gelombang'),
					'tanggal_daftar' => $this->request->getVar('tanggal_daftar'),
					'tahun_akademik' => $this->request->getVar('tahun_akademik'),
					'id_jalur_pendaftaran' => $this->request->getVar('jalur_pendaftaran'),
					'id_validasi_pendaftaran' => '1',
					'nomor_pendaftaran' => $this->request->getVar('nomor_pendaftaran'),
					'nama_mahasiswa' => $this->request->getVar('nama_mahasiswa'),
					'nik' => $this->request->getVar('nik'),
					'bukti_pembayaran' => 'default.jpg',
					'tempat_lahir' => $this->request->getVar('tempat_lahir'),
					'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
					'bulan_lahir' => $this->request->getVar('bulan_lahir'),
					'tahun_lahir' => $this->request->getVar('tahun_lahir'),
					'id_jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
					'id_agama' => $this->request->getVar('agama'),
					'id_wn' => $this->request->getVar('wn'),
					'id_status' => $this->request->getVar('status'),
					'nama_jalan' => $this->request->getVar('jalan'),
					'dusun' => $this->request->getVar('dusun'),
					'rt' => $this->request->getVar('rt'),
					'rw' => $this->request->getVar('rw'),
					'kelurahan' => $this->request->getVar('kelurahan'),
					'kecamatan' => $this->request->getVar('kecamatan'),
					'kabupaten' => $this->request->getVar('kabupaten'),
					'no_hp' => $this->request->getVar('no_hp'),
					'asal_sekolah' => $this->request->getVar('asal_sekolah'),
					'nisn' => $this->request->getVar('nisn'),
					'tahun_lulus' => $this->request->getVar('tahun_lulus'),
					'id_pilihan_1' => $this->request->getVar('jurusan_1'),
					'id_pilihan_2' => $this->request->getVar('jurusan_2'),
					'nama_tempat_kerja' => $this->request->getVar('tempat_kerja'),
					'nomor_telephone_kerja' => $this->request->getVar('nomor_tel_kerja'),
					'alamat_tempat_kerja' => $this->request->getVar('alamat_temker'),
					'nama_ayah' => $this->request->getVar('nama_ayah'),
					'id_pendidikan_ayah' => $this->request->getVar('pendidikan_ayah'),
					'id_pekerjaan_ayah' => $this->request->getVar('pekerjaan_ayah'),
					'nama_ibu' => $this->request->getVar('nama_ibu'),
					'id_pendidikan_ibu' => $this->request->getVar('pendidikan_ibu'),
					'id_pekerjaan_ibu' => $this->request->getVar('pekerjaan_ibu'),
					'id_penghasilan_wali' => $this->request->getVar('penghasilan_wali'),
					'nomor_hp_wali' => $this->request->getVar('nomor_hp_wali'),
					'alamat_wali' => $this->request->getVar('alamat_wali'),
					'nama_rekomendasi' => $this->request->getVar('nama_rekomendasi'),
					'nomor_rekomendasi' => $this->request->getVar('nomor_rekomendasi'),
				]);

				$msg = [
					'sukses' => 'Calon Mahasiswa berhasil ditambah'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/panitia');
		}
	}

	public function tambahmhsmgs()
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'gelombang' => [
					'label' => 'Gelombang',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendaftaran' => [
					'label' => 'Status Awal',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_daftar' => [
					'label' => 'Tanggal Daftar',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tahun_akademik' => [
					'label' => 'Tahun Akademik',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalur_pendaftaran' => [
					'label' => 'Jalur Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_pendaftaran' => [
					'label' => 'Nomor Pendaftaran',
					'rules' => 'required|is_unique[mahasiswa_baru.nomor_pendaftaran]|numeric',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => '{field} sudah ada, coba cari yang lain',
						'numeric' => '{field} harus angka',
					]
				],
				'nama_mahasiswa' => [
					'label' => 'Nama Lengkap Anda',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nik' => [
					'label' => 'NIK',
					'rules' => 'required|is_unique[mahasiswa_baru.nik]|numeric|exact_length[16]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => '{field} NIK anda sudah terdaftar, anda tidak bisa mengisi form ini lagi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 16 digit angka',
					]
				],
				'tempat_lahir' => [
					'label' => 'Tempat Lahir',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_lahir' => [
					'label' => 'Tanggal Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'bulan_lahir' => [
					'label' => 'Bulan Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'tahun_lahir' => [
					'label' => 'Tahun Lahir',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'jenis_kelamin' => [
					'label' => 'Jenis Kelamin',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'agama' => [
					'label' => 'Agama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'wn' => [
					'label' => 'Kewarganegaraan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'status' => [
					'label' => 'Status',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalan' => [
					'label' => 'Jalan',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'dusun' => [
					'label' => 'Dusun',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'rt' => [
					'label' => 'RT',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'rw' => [
					'label' => 'RW',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kelurahan' => [
					'label' => 'Kelurahan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kecamatan' => [
					'label' => 'Kecamatan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kabupaten' => [
					'label' => 'Kabupaten',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'no_hp' => [
					'label' => 'Nomor HP',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'jurusan_1' => [
					'label' => 'Pilihan Pertama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tempat_kerja' => [
					'label' => 'Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_tel_kerja' => [
					'label' => 'Nomor Telpon Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'alamat_temker' => [
					'label' => 'Alamat Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nama_ayah' => [
					'label' => 'Nama Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_ibu' => [
					'label' => 'Nama Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'penghasilan_wali' => [
					'label' => 'Penghasilan Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_hp_wali' => [
					'label' => 'Nomor HP Wali',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'alamat_wali' => [
					'label' => 'Alamat Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_kampus' => [
					'label' => 'Asal Kampus',
					'rules' => 'required',
					'errors' => []
				],
				'prodi_sarjana' => [
					'label' => 'Asal Prodi Sarjana',
					'rules' => 'required',
					'errors' => ['required' => '{field} wajib diisi',]
				],
				'ipk_sarjana' => [
					'label' => 'IPK Sarjana',
					'rules' => 'required',
					'errors' => ['required' => '{field} wajib diisi',]
				],
				'nama_rekomendasi' => [
					'label' => 'Nama Perekomendasi',
					'rules' => 'permit_empty',
					'errors' => ['required' => '{field} wajib diisi',]
				],
				'nomor_rekomendasi' => [
					'label' => 'Nomor HP Perekomendasi',
					'rules' => 'permit_empty|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'namsd_sar' => [
					'label' => 'Nama SD/MI',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'namsmp_sar' => [
					'label' => 'Nama SMP/MTS',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'namsma_sar' => [
					'label' => 'Nama SMA/MA',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tlulus_sd' => [
					'label' => 'Tahun Lulus SD/MI',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'tlulus_smp' => [
					'label' => 'Tahun Lulus SMP/MTS',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'tlulus_sma' => [
					'label' => 'Tahun Lulus SMA/MA',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'tlulus_kul' => [
					'label' => 'Tahun Lulus Sarjana',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'noser_ijas' => [
					'label' => 'Nomor Seri Ijasah Sarjana',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'byatung' => [
					'label' => 'Tanggungan Biaya',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'tanggal_daftar' => $validation->getError('tanggal_daftar'),
						'pendaftaran' => $validation->getError('pendaftaran'),
						'gelombang' => $validation->getError('gelombang'),
						'tahun_akademik' => $validation->getError('tahun_akademik'),
						'jalur_pendaftaran' => $validation->getError('jalur_pendaftaran'),
						'nomor_pendaftaran' => $validation->getError('nomor_pendaftaran'),
						'nama_mahasiswa' => $validation->getError('nama_mahasiswa'),
						'nik' => $validation->getError('nik'),
						'tempat_lahir' => $validation->getError('tempat_lahir'),
						'tanggal_lahir' => $validation->getError('tanggal_lahir'),
						'bulan_lahir' => $validation->getError('bulan_lahir'),
						'tahun_lahir' => $validation->getError('tahun_lahir'),
						'jenis_kelamin' => $validation->getError('jenis_kelamin'),
						'agama' => $validation->getError('agama'),
						'wn' => $validation->getError('wn'),
						'status' => $validation->getError('status'),
						'jalan' => $validation->getError('jalan'),
						'dusun' => $validation->getError('dusun'),
						'rt' => $validation->getError('rt'),
						'rw' => $validation->getError('rw'),
						'kelurahan' => $validation->getError('kelurahan'),
						'kecamatan' => $validation->getError('kecamatan'),
						'kabupaten' => $validation->getError('kabupaten'),
						'no_hp' => $validation->getError('no_hp'),
						'jurusan_1' => $validation->getError('jurusan_1'),
						'tempat_kerja' => $validation->getError('tempat_kerja'),
						'nomor_tel_kerja' => $validation->getError('nomor_tel_kerja'),
						'alamat_temker' => $validation->getError('alamat_temker'),
						'nama_ayah' => $validation->getError('nama_ayah'),
						'pendidikan_ayah' => $validation->getError('pendidikan_ayah'),
						'pekerjaan_ayah' => $validation->getError('pekerjaan_ayah'),
						'nama_ibu' => $validation->getError('nama_ibu'),
						'pendidikan_ibu' => $validation->getError('pendidikan_ibu'),
						'pekerjaan_ibu' => $validation->getError('pekerjaan_ibu'),
						'penghasilan_wali' => $validation->getError('penghasilan_wali'),
						'nomor_hp_wali' => $validation->getError('nomor_hp_wali'),
						'alamat_wali' => $validation->getError('alamat_wali'),
						'nama_rekomendasi' => $validation->getError('nama_rekomendasi'),
						'nomor_rekomendasi' => $validation->getError('nomor_rekomendasi'),
						'nama_kampus' => $validation->getError('nama_kampus'),
						'prodi_sarjana' => $validation->getError('prodi_sarjana'),
						'ipk_sarjana' => $validation->getError('ipk_sarjana'),
						'namsd_sar' => $validation->getError('namsd_sar'),
						'namsmp_sar' => $validation->getError('namsmp_sar'),
						'namsma_sar' => $validation->getError('namsma_sar'),
						'tlulus_sd' => $validation->getError('tlulus_sd'),
						'tlulus_smp' => $validation->getError('tlulus_smp'),
						'tlulus_sma' => $validation->getError('tlulus_sma'),
						'tlulus_kul' => $validation->getError('tlulus_kul'),
						'noser_ijas' => $validation->getError('noser_ijas'),
						'byatung' => $validation->getError('byatung'),
					]
				];
			} else {
				$this->MahasiswaModel->save([
					'id_status_pendaftaran' => '1',
					'pendaftaran' => $this->request->getVar('pendaftaran'),
					'id_gelombang' => $this->request->getVar('gelombang'),
					'tanggal_daftar' => $this->request->getVar('tanggal_daftar'),
					'tahun_akademik' => $this->request->getVar('tahun_akademik'),
					'id_jalur_pendaftaran' => $this->request->getVar('jalur_pendaftaran'),
					'id_validasi_pendaftaran' => '1',
					'nomor_pendaftaran' => $this->request->getVar('nomor_pendaftaran'),
					'nama_mahasiswa' => $this->request->getVar('nama_mahasiswa'),
					'nik' => $this->request->getVar('nik'),
					'bukti_pembayaran' => 'default.jpg',
					'tempat_lahir' => $this->request->getVar('tempat_lahir'),
					'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
					'bulan_lahir' => $this->request->getVar('bulan_lahir'),
					'tahun_lahir' => $this->request->getVar('tahun_lahir'),
					'id_jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
					'id_agama' => $this->request->getVar('agama'),
					'id_wn' => $this->request->getVar('wn'),
					'id_status' => $this->request->getVar('status'),
					'nama_jalan' => $this->request->getVar('jalan'),
					'dusun' => $this->request->getVar('dusun'),
					'rt' => $this->request->getVar('rt'),
					'rw' => $this->request->getVar('rw'),
					'kelurahan' => $this->request->getVar('kelurahan'),
					'kecamatan' => $this->request->getVar('kecamatan'),
					'kabupaten' => $this->request->getVar('kabupaten'),
					'no_hp' => $this->request->getVar('no_hp'),
					'id_pilihan_1' => $this->request->getVar('jurusan_1'),
					'id_pilihan_2' => '9',
					'nama_tempat_kerja' => $this->request->getVar('tempat_kerja'),
					'nomor_telephone_kerja' => $this->request->getVar('nomor_tel_kerja'),
					'alamat_tempat_kerja' => $this->request->getVar('alamat_temker'),
					'nama_ayah' => $this->request->getVar('nama_ayah'),
					'id_pendidikan_ayah' => $this->request->getVar('pendidikan_ayah'),
					'id_pekerjaan_ayah' => $this->request->getVar('pekerjaan_ayah'),
					'nama_ibu' => $this->request->getVar('nama_ibu'),
					'id_pendidikan_ibu' => $this->request->getVar('pendidikan_ibu'),
					'id_pekerjaan_ibu' => $this->request->getVar('pekerjaan_ibu'),
					'id_penghasilan_wali' => $this->request->getVar('penghasilan_wali'),
					'nomor_hp_wali' => $this->request->getVar('nomor_hp_wali'),
					'alamat_wali' => $this->request->getVar('alamat_wali'),
					'nama_rekomendasi' => $this->request->getVar('nama_rekomendasi'),
					'nomor_rekomendasi' => $this->request->getVar('nomor_rekomendasi'),
					'nama_kampus' => $this->request->getVar('nama_kampus'),
					'prodi_sarjana' => $this->request->getVar('prodi_sarjana'),
					'ipk_sarjana' => $this->request->getVar('ipk_sarjana'),
					'namsd_sar' => $this->request->getVar('namsd_sar'),
					'namsmp_sar' => $this->request->getVar('namsmp_sar'),
					'namsma_sar' => $this->request->getVar('namsma_sar'),
					'tlulus_sd' => $this->request->getVar('tlulus_sd'),
					'tlulus_smp' => $this->request->getVar('tlulus_smp'),
					'tlulus_sma' => $this->request->getVar('tlulus_sma'),
					'tlulus_kul' => $this->request->getVar('tlulus_kul'),
					'noser_ijas' => $this->request->getVar('noser_ijas'),
					'byatung' => $this->request->getVar('byatung'),
				]);

				$msg = [
					'sukses' => 'Calon Mahasiswa berhasil ditambah'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/panitia');
		}
	}

	public function editmhss($id_mahasiswa)
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'id_mahasiswa' => [
					'label' => 'ID Mahasiswa',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalur_pendaftaran' => [
					'label' => 'Jalur Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendaftaran' => [
					'label' => 'Status Awal Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_mahasiswa' => [
					'label' => 'Nama Lengkap Anda',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nik' => [
					'label' => 'NIK',
					'rules' => 'required|numeric|exact_length[16]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 16 digit angka',
					]
				],
				'tempat_lahir' => [
					'label' => 'Tempat Lahir',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_lahir' => [
					'label' => 'Tanggal Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'bulan_lahir' => [
					'label' => 'Bulan Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'tahun_lahir' => [
					'label' => 'Tahun Lahir',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'jenis_kelamin' => [
					'label' => 'Jenis Kelamin',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'agama' => [
					'label' => 'Agama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'wn' => [
					'label' => 'Kewarganegaraan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'status' => [
					'label' => 'Status',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalan' => [
					'label' => 'Jalan',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'dusun' => [
					'label' => 'Dusun',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'rt' => [
					'label' => 'RT',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'rw' => [
					'label' => 'RW',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kelurahan' => [
					'label' => 'Kelurahan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kecamatan' => [
					'label' => 'Kecamatan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kabupaten' => [
					'label' => 'Kabupaten',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'no_hp' => [
					'label' => 'Nomor HP',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'asal_sekolah' => [
					'label' => 'Asal Sekolah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nisn' => [
					'label' => 'NISN',
					'rules' => 'permit_empty|numeric',
					'errors' => [
						'numeric' => '{field} harus angka',
					]
				],
				'tahun_lulus' => [
					'label' => 'Tahun Lulus',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} tidak valid',
					]
				],
				'nisn' => [
					'label' => 'NISN',
					'rules' => 'permit_empty|numeric',
					'errors' => [
						'numeric' => '{field} harus angka',
					]
				],
				'tempat_kerja' => [
					'label' => 'Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_tel_kerja' => [
					'label' => 'Nomor Telpon Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'alamat_temker' => [
					'label' => 'Alamat Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nama_ayah' => [
					'label' => 'Nama Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_ibu' => [
					'label' => 'Nama Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'penghasilan_wali' => [
					'label' => 'Penghasilan Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_hp_wali' => [
					'label' => 'Nomor HP Wali',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'alamat_wali' => [
					'label' => 'Alamat Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_rekomendasi' => [
					'label' => 'Nama Perekomendasi',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_rekomendasi' => [
					'label' => 'Nomor HP Perekomendasi',
					'rules' => 'permit_empty|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'id_mahasiswa' => $validation->getError('id_mahasiswa'),
						'jalur_pendaftaran' => $validation->getError('jalur_pendaftaran'),
						'pendaftaran' => $validation->getError('pendaftaran'),
						'nama_mahasiswa' => $validation->getError('nama_mahasiswa'),
						'nik' => $validation->getError('nik'),
						'tempat_lahir' => $validation->getError('tempat_lahir'),
						'tanggal_lahir' => $validation->getError('tanggal_lahir'),
						'bulan_lahir' => $validation->getError('bulan_lahir'),
						'tahun_lahir' => $validation->getError('tahun_lahir'),
						'jenis_kelamin' => $validation->getError('jenis_kelamin'),
						'agama' => $validation->getError('agama'),
						'wn' => $validation->getError('wn'),
						'status' => $validation->getError('status'),
						'jalan' => $validation->getError('jalan'),
						'dusun' => $validation->getError('dusun'),
						'rt' => $validation->getError('rt'),
						'rw' => $validation->getError('rw'),
						'kelurahan' => $validation->getError('kelurahan'),
						'kecamatan' => $validation->getError('kecamatan'),
						'kabupaten' => $validation->getError('kabupaten'),
						'no_hp' => $validation->getError('no_hp'),
						'asal_sekolah' => $validation->getError('asal_sekolah'),
						'nisn' => $validation->getError('nisn'),
						'tahun_lulus' => $validation->getError('tahun_lulus'),
						'tempat_kerja' => $validation->getError('tempat_kerja'),
						'nomor_tel_kerja' => $validation->getError('nomor_tel_kerja'),
						'alamat_temker' => $validation->getError('alamat_temker'),
						'nama_ayah' => $validation->getError('nama_ayah'),
						'pendidikan_ayah' => $validation->getError('pendidikan_ayah'),
						'pekerjaan_ayah' => $validation->getError('pekerjaan_ayah'),
						'nama_ibu' => $validation->getError('nama_ibu'),
						'pendidikan_ibu' => $validation->getError('pendidikan_ibu'),
						'pekerjaan_ibu' => $validation->getError('pekerjaan_ibu'),
						'penghasilan_wali' => $validation->getError('penghasilan_wali'),
						'nomor_hp_wali' => $validation->getError('nomor_hp_wali'),
						'alamat_wali' => $validation->getError('alamat_wali'),
						'nama_rekomendasi' => $validation->getError('nama_rekomendasi'),
						'nomor_rekomendasi' => $validation->getError('nomor_rekomendasi'),
					]
				];
			} else {
				$this->MahasiswaModel->save([
					'id_mahasiswa' => $id_mahasiswa,
					'id_jalur_pendaftaran' => $this->request->getVar('jalur_pendaftaran'),
					'nama_mahasiswa' => $this->request->getVar('nama_mahasiswa'),
					'pendaftaran' => $this->request->getVar('pendaftaran'),
					'nik' => $this->request->getVar('nik'),
					'tempat_lahir' => $this->request->getVar('tempat_lahir'),
					'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
					'bulan_lahir' => $this->request->getVar('bulan_lahir'),
					'tahun_lahir' => $this->request->getVar('tahun_lahir'),
					'id_jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
					'id_agama' => $this->request->getVar('agama'),
					'id_wn' => $this->request->getVar('wn'),
					'id_status' => $this->request->getVar('status'),
					'nama_jalan' => $this->request->getVar('jalan'),
					'dusun' => $this->request->getVar('dusun'),
					'rt' => $this->request->getVar('rt'),
					'rw' => $this->request->getVar('rw'),
					'kelurahan' => $this->request->getVar('kelurahan'),
					'kecamatan' => $this->request->getVar('kecamatan'),
					'kabupaten' => $this->request->getVar('kabupaten'),
					'no_hp' => $this->request->getVar('no_hp'),
					'asal_sekolah' => $this->request->getVar('asal_sekolah'),
					'nisn' => $this->request->getVar('nisn'),
					'tahun_lulus' => $this->request->getVar('tahun_lulus'),
					'nama_tempat_kerja' => $this->request->getVar('tempat_kerja'),
					'nomor_telephone_kerja' => $this->request->getVar('nomor_tel_kerja'),
					'alamat_tempat_kerja' => $this->request->getVar('alamat_temker'),
					'nama_ayah' => $this->request->getVar('nama_ayah'),
					'id_pendidikan_ayah' => $this->request->getVar('pendidikan_ayah'),
					'id_pekerjaan_ayah' => $this->request->getVar('pekerjaan_ayah'),
					'nama_ibu' => $this->request->getVar('nama_ibu'),
					'id_pendidikan_ibu' => $this->request->getVar('pendidikan_ibu'),
					'id_pekerjaan_ibu' => $this->request->getVar('pekerjaan_ibu'),
					'id_penghasilan_wali' => $this->request->getVar('penghasilan_wali'),
					'nomor_hp_wali' => $this->request->getVar('nomor_hp_wali'),
					'alamat_wali' => $this->request->getVar('alamat_wali'),
					'nama_rekomendasi' => $this->request->getVar('nama_rekomendasi'),
					'nomor_rekomendasi' => $this->request->getVar('nomor_rekomendasi'),
				]);

				$msg = [
					'sukses' => 'Calon Mahasiswa berhasil diupdate'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/panitia');
		}
	}

	public function editmhssmgs($id_mahasiswa)
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'id_mahasiswa' => [
					'label' => 'ID Mahasiswa',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalur_pendaftaran' => [
					'label' => 'Jalur Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendaftaran' => [
					'label' => 'Status Awal Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_mahasiswa' => [
					'label' => 'Nama Lengkap Anda',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nik' => [
					'label' => 'NIK',
					'rules' => 'required|numeric|exact_length[16]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 16 digit angka',
					]
				],
				'tempat_lahir' => [
					'label' => 'Tempat Lahir',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tanggal_lahir' => [
					'label' => 'Tanggal Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'bulan_lahir' => [
					'label' => 'Bulan Lahir',
					'rules' => 'required|numeric|exact_length[2]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 2 digit angka',
					]
				],
				'tahun_lahir' => [
					'label' => 'Tahun Lahir',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'jenis_kelamin' => [
					'label' => 'Jenis Kelamin',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'agama' => [
					'label' => 'Agama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'wn' => [
					'label' => 'Kewarganegaraan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'status' => [
					'label' => 'Status',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jalan' => [
					'label' => 'Jalan',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'dusun' => [
					'label' => 'Dusun',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'rt' => [
					'label' => 'RT',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'rw' => [
					'label' => 'RW',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kelurahan' => [
					'label' => 'Kelurahan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kecamatan' => [
					'label' => 'Kecamatan',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'kabupaten' => [
					'label' => 'Kabupaten',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'no_hp' => [
					'label' => 'Nomor HP',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'tempat_kerja' => [
					'label' => 'Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_tel_kerja' => [
					'label' => 'Nomor Telpon Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'alamat_temker' => [
					'label' => 'Alamat Tempat Kerja',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nama_ayah' => [
					'label' => 'Nama Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ayah' => [
					'label' => 'Pendidikan Ayah',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_ibu' => [
					'label' => 'Nama Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pendidikan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'pekerjaan_ibu' => [
					'label' => 'Pendidikan Ibu',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'penghasilan_wali' => [
					'label' => 'Penghasilan Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_hp_wali' => [
					'label' => 'Nomor HP Wali',
					'rules' => 'required|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'alamat_wali' => [
					'label' => 'Alamat Wali',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nama_kampus' => [
					'label' => 'Asal Kampus',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'prodi_sarjana' => [
					'label' => 'Asal Prodi Sarjana',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'ipk_sarjana' => [
					'label' => 'IPK Sarjana',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nama_rekomendasi' => [
					'label' => 'Nama Perekomendasi',
					'rules' => 'permit_empty',
					'errors' => []
				],
				'nomor_rekomendasi' => [
					'label' => 'Nomor HP Perekomendasi',
					'rules' => 'permit_empty|numeric|min_length[10]|max_length[13]',
					'errors' => [
						'numeric' => '{field} harus angka',
						'min_length' => '{field} tidak valid',
						'max_length' => '{field} tidak valid',
					]
				],
				'namsd_sar' => [
					'label' => 'Nama SD/MI',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'namsmp_sar' => [
					'label' => 'Nama SMP/MTS',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'namsma_sar' => [
					'label' => 'Nama SMA/MA',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'tlulus_sd' => [
					'label' => 'Tahun Lulus SD/MI',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'tlulus_smp' => [
					'label' => 'Tahun Lulus SMP/MTS',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'tlulus_sma' => [
					'label' => 'Tahun Lulus SMA/MA',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 4 digit angka',
					]
				],
				'tlulus_kul' => [
					'label' => 'Tahun Lulus Sarjana',
					'rules' => 'required|numeric|exact_length[4]',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'noser_ijas' => [
					'label' => 'Nomor Seri Ijasah Sarjana',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'id_mahasiswa' => $validation->getError('id_mahasiswa'),
						'jalur_pendaftaran' => $validation->getError('jalur_pendaftaran'),
						'pendaftaran' => $validation->getError('pendaftaran'),
						'nama_mahasiswa' => $validation->getError('nama_mahasiswa'),
						'nik' => $validation->getError('nik'),
						'tempat_lahir' => $validation->getError('tempat_lahir'),
						'tanggal_lahir' => $validation->getError('tanggal_lahir'),
						'bulan_lahir' => $validation->getError('bulan_lahir'),
						'tahun_lahir' => $validation->getError('tahun_lahir'),
						'jenis_kelamin' => $validation->getError('jenis_kelamin'),
						'agama' => $validation->getError('agama'),
						'wn' => $validation->getError('wn'),
						'status' => $validation->getError('status'),
						'jalan' => $validation->getError('jalan'),
						'dusun' => $validation->getError('dusun'),
						'rt' => $validation->getError('rt'),
						'rw' => $validation->getError('rw'),
						'kelurahan' => $validation->getError('kelurahan'),
						'kecamatan' => $validation->getError('kecamatan'),
						'kabupaten' => $validation->getError('kabupaten'),
						'no_hp' => $validation->getError('no_hp'),
						'tempat_kerja' => $validation->getError('tempat_kerja'),
						'nomor_tel_kerja' => $validation->getError('nomor_tel_kerja'),
						'alamat_temker' => $validation->getError('alamat_temker'),
						'nama_ayah' => $validation->getError('nama_ayah'),
						'pendidikan_ayah' => $validation->getError('pendidikan_ayah'),
						'pekerjaan_ayah' => $validation->getError('pekerjaan_ayah'),
						'nama_ibu' => $validation->getError('nama_ibu'),
						'pendidikan_ibu' => $validation->getError('pendidikan_ibu'),
						'pekerjaan_ibu' => $validation->getError('pekerjaan_ibu'),
						'penghasilan_wali' => $validation->getError('penghasilan_wali'),
						'nomor_hp_wali' => $validation->getError('nomor_hp_wali'),
						'alamat_wali' => $validation->getError('alamat_wali'),
						'nama_rekomendasi' => $validation->getError('nama_rekomendasi'),
						'nomor_rekomendasi' => $validation->getError('nomor_rekomendasi'),
						'nama_kampus' => $validation->getError('nama_kampus'),
						'prodi_sarjana' => $validation->getError('prodi_sarjana'),
						'ipk_sarjana' => $validation->getError('ipk_sarjana'),
						'namsd_sar' => $validation->getError('namsd_sar'),
						'namsmp_sar' => $validation->getError('namsmp_sar'),
						'namsma_sar' => $validation->getError('namsma_sar'),
						'tlulus_sd' => $validation->getError('tlulus_sd'),
						'tlulus_smp' => $validation->getError('tlulus_smp'),
						'tlulus_sma' => $validation->getError('tlulus_sma'),
						'tlulus_kul' => $validation->getError('tlulus_kul'),
						'noser_ijas' => $validation->getError('noser_ijas'),
						'namsd_sar' => $this->request->getVar('namsd_sar'),
						'namsmp_sar' => $this->request->getVar('namsmp_sar'),
						'namsma_sar' => $this->request->getVar('namsma_sar'),
						'tlulus_sd' => $this->request->getVar('tlulus_sd'),
						'tlulus_smp' => $this->request->getVar('tlulus_smp'),
						'tlulus_sma' => $this->request->getVar('tlulus_sma'),
						'tlulus_kul' => $this->request->getVar('tlulus_kul'),
						'noser_ijas' => $this->request->getVar('noser_ijas'),
					]
				];
			} else {
				$this->MahasiswaModel->save([
					'id_mahasiswa' => $id_mahasiswa,
					'id_jalur_pendaftaran' => $this->request->getVar('jalur_pendaftaran'),
					'nama_mahasiswa' => $this->request->getVar('nama_mahasiswa'),
					'pendaftaran' => $this->request->getVar('pendaftaran'),
					'nik' => $this->request->getVar('nik'),
					'tempat_lahir' => $this->request->getVar('tempat_lahir'),
					'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
					'bulan_lahir' => $this->request->getVar('bulan_lahir'),
					'tahun_lahir' => $this->request->getVar('tahun_lahir'),
					'id_jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
					'id_agama' => $this->request->getVar('agama'),
					'id_wn' => $this->request->getVar('wn'),
					'id_status' => $this->request->getVar('status'),
					'nama_jalan' => $this->request->getVar('jalan'),
					'dusun' => $this->request->getVar('dusun'),
					'rt' => $this->request->getVar('rt'),
					'rw' => $this->request->getVar('rw'),
					'kelurahan' => $this->request->getVar('kelurahan'),
					'kecamatan' => $this->request->getVar('kecamatan'),
					'kabupaten' => $this->request->getVar('kabupaten'),
					'no_hp' => $this->request->getVar('no_hp'),
					'nama_tempat_kerja' => $this->request->getVar('tempat_kerja'),
					'nomor_telephone_kerja' => $this->request->getVar('nomor_tel_kerja'),
					'alamat_tempat_kerja' => $this->request->getVar('alamat_temker'),
					'nama_ayah' => $this->request->getVar('nama_ayah'),
					'id_pendidikan_ayah' => $this->request->getVar('pendidikan_ayah'),
					'id_pekerjaan_ayah' => $this->request->getVar('pekerjaan_ayah'),
					'nama_ibu' => $this->request->getVar('nama_ibu'),
					'id_pendidikan_ibu' => $this->request->getVar('pendidikan_ibu'),
					'id_pekerjaan_ibu' => $this->request->getVar('pekerjaan_ibu'),
					'id_penghasilan_wali' => $this->request->getVar('penghasilan_wali'),
					'nomor_hp_wali' => $this->request->getVar('nomor_hp_wali'),
					'alamat_wali' => $this->request->getVar('alamat_wali'),
					'nama_rekomendasi' => $this->request->getVar('nama_rekomendasi'),
					'nomor_rekomendasi' => $this->request->getVar('nomor_rekomendasi'),
					'nomor_rekomendasi' => $this->request->getVar('nomor_rekomendasi'),
					'nama_kampus' => $this->request->getVar('nama_kampus'),
					'prodi_sarjana' => $this->request->getVar('prodi_sarjana'),
					'ipk_sarjana' => $this->request->getVar('ipk_sarjana'),
				]);

				$msg = [
					'sukses' => 'Calon Mahasiswa berhasil diupdate'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/panitia');
		}
	}

	public function editjrsmhsmgs($id_mahasiswa)
	{

		$tahun_akademik = \session('cobas');
		$keyword = $this->request->getVar('keyword');
		\session()->set('panda_4', $keyword);
		if ($tahun_akademik) {
			if ($keyword) {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$nomorpai = $this->MahasiswaModel8->GetNomorPai($tahun_akademik);
				$nomorpgmi = $this->MahasiswaModel2->GetNomorPgmi($tahun_akademik);
				$nomorpiaud = $this->MahasiswaModel3->GetNomorPiaud($tahun_akademik);
				$nomorekos = $this->MahasiswaModel4->GetNomorEkos($tahun_akademik);
				$nomorps = $this->MahasiswaModel5->GetNomorPs($tahun_akademik);
				$nomorhki = $this->MahasiswaModel6->GetNomorHki($tahun_akademik);
				$nomorpmi = $this->MahasiswaModel7->GetNomorPmi($tahun_akademik);
				$nomormagisterpai = $this->MahasiswaModel10->GetNomorMagisterPai($tahun_akademik);
			} else {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$nomorpai = $this->MahasiswaModel8->GetNomorPai($tahun_akademik);
				$nomorpgmi = $this->MahasiswaModel2->GetNomorPgmi($tahun_akademik);
				$nomorpiaud = $this->MahasiswaModel3->GetNomorPiaud($tahun_akademik);
				$nomorekos = $this->MahasiswaModel4->GetNomorEkos($tahun_akademik);
				$nomorps = $this->MahasiswaModel5->GetNomorPs($tahun_akademik);
				$nomorhki = $this->MahasiswaModel6->GetNomorHki($tahun_akademik);
				$nomorpmi = $this->MahasiswaModel7->GetNomorPmi($tahun_akademik);
				$nomormagisterpai = $this->MahasiswaModel10->GetNomorMagisterPai($tahun_akademik);
			}
		} else {
			$havevalidation = "error";
			$gelombangs = "error";
			$allpendaftar = "error";
		}

		$currentPage = $this->request->getVar('page_mahasiswa_baru') ? $this->request->getVar('page_mahasiswa_baru') : 1;
		$data = [
			'title' => 'EDIT JURUSAN CALON MAHASISWA S2',
			'dashboard' => '',
			'gel' => 'active',
			'gel1' => 'active',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'mahasiswa' => $this->MahasiswaModel->GetEditMahasiswa($id_mahasiswa),
			'jurusan' => $this->MahasiswaModel->getJurusan3(),
			'jurusan2' => $this->MahasiswaModel->getJurusan4(),
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'pager' => $this->MahasiswaModel->pager,
			'currentPage' => $currentPage,
			'nomor_magisterpai' => $nomormagisterpai->paginate(1),
			'nomor_pai' => $nomorpai->paginate(1),
			'nomor_pgmi' => $nomorpgmi->paginate(1),
			'nomor_piaud' => $nomorpiaud->paginate(1),
			'nomor_ekos' => $nomorekos->paginate(1),
			'nomor_ps' => $nomorps->paginate(1),
			'nomor_hki' => $nomorhki->paginate(1),
			'nomor_pmi' => $nomorpmi->paginate(1),
		];

		return view('admin/panitia/edit-jurusan-mahasiswa-magister', $data);
	}

	public function editjrsmhssmgs($id_mahasiswa)
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'id_mahasiswa' => [
					'label' => 'ID Mahasiswa',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_pendaftaran' => [
					'label' => 'Nomor Pendaftaran',
					'rules' => 'required|is_unique[mahasiswa_baru.nomor_pendaftaran]|numeric',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => '{field} harus diperbarui menurut jurusan pertama yang dipilih',
						'numeric' => '{field} harus angka',
					]
				],
				'jurusan_1' => [
					'label' => 'Pilihan Pertama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],

			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'id_mahasiswa' => $validation->getError('id_mahasiswa'),
						'nomor_pendaftaran' => $validation->getError('nomor_pendaftaran'),
						'jurusan_1' => $validation->getError('jurusan_1'),
					]
				];
			} else {
				$this->MahasiswaModel->save([
					'id_mahasiswa' => $id_mahasiswa,
					'nomor_pendaftaran' => $this->request->getVar('nomor_pendaftaran'),
					'id_pilihan_1' => $this->request->getVar('jurusan_1'),
				]);

				$msg = [
					'sukses' => 'Jurusan Mahasiswa berhasil diupdate'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/panitia');
		}
	}

	public function editjrsmhss($id_mahasiswa)
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'id_mahasiswa' => [
					'label' => 'ID Mahasiswa',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_pendaftaran' => [
					'label' => 'Nomor Pendaftaran',
					'rules' => 'required|is_unique[mahasiswa_baru.nomor_pendaftaran]|numeric|exact_length[9]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => '{field} harus diperbarui menurut jurusan pertama yang dipilih',
						'numeric' => '{field} harus angka',
						'exact_length' => '{field} harus 9 digit angka',
					]
				],
				'jurusan_1' => [
					'label' => 'Pilihan Pertama',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'jurusan_2' => [
					'label' => 'Pilihan Ke-dua',
					'rules' => 'required|differs[jurusan_1]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'differs' => '{field} tidak boleh sama dengan pilihan pertama',
					]
				],

			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'id_mahasiswa' => $validation->getError('id_mahasiswa'),
						'nomor_pendaftaran' => $validation->getError('nomor_pendaftaran'),
						'jurusan_1' => $validation->getError('jurusan_1'),
						'jurusan_2' => $validation->getError('jurusan_2'),
					]
				];
			} else {
				$this->MahasiswaModel->save([
					'id_mahasiswa' => $id_mahasiswa,
					'nomor_pendaftaran' => $this->request->getVar('nomor_pendaftaran'),
					'id_pilihan_1' => $this->request->getVar('jurusan_1'),
					'id_pilihan_2' => $this->request->getVar('jurusan_2'),
				]);

				$msg = [
					'sukses' => 'Jurusan Mahasiswa berhasil diupdate'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/panitia');
		}
	}

	public function gel_1()
	{


		$tahun_akademik = \session('cobas');
		$keyword = $this->request->getVar('keyword');
		\session()->set('panda_4', $keyword);
		if ($tahun_akademik) {
			if ($keyword) {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik, $keyword);
			} else {
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik);
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
			}
		} else {
			$havevalidation = "error";
			$gelombangs = "error";
			$allpendaftar = "error";
		}

		$currentPage = $this->request->getVar('page_mahasiswa_baru') ? $this->request->getVar('page_mahasiswa_baru') : 1;
		$data = [
			'title' => 'DATA CALON MAHASISWA',
			'dashboard' => '',
			'gel' => 'active',
			'gel1' => 'active',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'gelombang' => $gelombangs->paginate(10, 'mahasiswa_baru'),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'pager' => $this->MahasiswaModel->pager,
			'currentPage' => $currentPage,
		];

		return view('admin/panitia/gelombang-1', $data);
	}

	public function editmhs($id_mahasiswa)
	{


		$tahun_akademik = \session('cobas');
		$keyword = $this->request->getVar('keyword');
		\session()->set('panda_4', $keyword);
		if ($tahun_akademik) {
			if ($keyword) {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik, $keyword);
			} else {
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik);
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
			}
		} else {
			$havevalidation = "error";
			$gelombangs = "error";
			$allpendaftar = "error";
		}

		$currentPage = $this->request->getVar('page_mahasiswa_baru') ? $this->request->getVar('page_mahasiswa_baru') : 1;
		$data = [
			'title' => 'EDIT DATA CALON MAHASISWA',
			'dashboard' => '',
			'gel' => 'active',
			'gel1' => 'active',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'mahasiswa' => $this->MahasiswaModel->GetEditDataMahasiswa($id_mahasiswa),
			'jalur_pendaftaran' => $this->MahasiswaModel->getJalur(),
			'jenis_kelamin' => $this->MahasiswaModel->getKelamin(),
			'agama' => $this->MahasiswaModel->getAgama(),
			'wn' => $this->MahasiswaModel->getNegara(),
			'status' => $this->MahasiswaModel->getStatus(),
			'pendidikan_ayah' => $this->MahasiswaModel->getPendidikanOrtu(),
			'pekerjaan_ayah'  => $this->MahasiswaModel->getpekerjaanOrtu(),
			'pendidikan_ibu'  => $this->MahasiswaModel->getpendidikanOrtu(),
			'pekerjaan_ibu'   => $this->MahasiswaModel->getpekerjaanOrtu(),
			'penghasilan_wali' => $this->MahasiswaModel->getpenghasilan(),
			'status_pendaftaran' => $this->MahasiswaModel->GetPendaftaran(),
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'gelombang' => $gelombangs->paginate(10, 'mahasiswa_baru'),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'pager' => $this->MahasiswaModel->pager,
			'currentPage' => $currentPage,
		];

		return view('admin/panitia/edit-mahasiswa', $data);
	}

	public function editjrsmhs($id_mahasiswa)
	{

		$tahun_akademik = \session('cobas');
		$keyword = $this->request->getVar('keyword');
		\session()->set('panda_4', $keyword);
		if ($tahun_akademik) {
			if ($keyword) {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$nomorpai = $this->MahasiswaModel8->GetNomorPai($tahun_akademik);
				$nomorpgmi = $this->MahasiswaModel2->GetNomorPgmi($tahun_akademik);
				$nomorpiaud = $this->MahasiswaModel3->GetNomorPiaud($tahun_akademik);
				$nomorekos = $this->MahasiswaModel4->GetNomorEkos($tahun_akademik);
				$nomorps = $this->MahasiswaModel5->GetNomorPs($tahun_akademik);
				$nomorhki = $this->MahasiswaModel6->GetNomorHki($tahun_akademik);
				$nomorpmi = $this->MahasiswaModel7->GetNomorPmi($tahun_akademik);
			} else {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$nomorpai = $this->MahasiswaModel8->GetNomorPai($tahun_akademik);
				$nomorpgmi = $this->MahasiswaModel2->GetNomorPgmi($tahun_akademik);
				$nomorpiaud = $this->MahasiswaModel3->GetNomorPiaud($tahun_akademik);
				$nomorekos = $this->MahasiswaModel4->GetNomorEkos($tahun_akademik);
				$nomorps = $this->MahasiswaModel5->GetNomorPs($tahun_akademik);
				$nomorhki = $this->MahasiswaModel6->GetNomorHki($tahun_akademik);
				$nomorpmi = $this->MahasiswaModel7->GetNomorPmi($tahun_akademik);
			}
		} else {
			$havevalidation = "error";
			$gelombangs = "error";
			$allpendaftar = "error";
		}

		$currentPage = $this->request->getVar('page_mahasiswa_baru') ? $this->request->getVar('page_mahasiswa_baru') : 1;
		$data = [
			'title' => 'EDIT DATA CALON MAHASISWA',
			'dashboard' => '',
			'gel' => 'active',
			'gel1' => 'active',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'mahasiswa' => $this->MahasiswaModel->GetEditMahasiswa($id_mahasiswa),
			'jurusan' => $this->MahasiswaModel->getJurusan(),
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'pager' => $this->MahasiswaModel->pager,
			'currentPage' => $currentPage,
			'nomor_pai' => $nomorpai->paginate(1),
			'nomor_pgmi' => $nomorpgmi->paginate(1),
			'nomor_piaud' => $nomorpiaud->paginate(1),
			'nomor_ekos' => $nomorekos->paginate(1),
			'nomor_ps' => $nomorps->paginate(1),
			'nomor_hki' => $nomorhki->paginate(1),
			'nomor_pmi' => $nomorpmi->paginate(1),
		];

		return view('admin/panitia/edit-jurusan-mahasiswa', $data);
	}

	public function exdata1()
	{

		$tahun_akademik = \session('cobas');
		$keyword = $this->request->getVar('keyword');
		\session()->set('panda_4', $keyword);
		if ($tahun_akademik) {
			if ($keyword) {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik, $keyword);
			} else {
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik);
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
			}
		} else {
			$havevalidation = "error";
			$gelombangs = "error";
			$allpendaftar = "error";
		}

		$data = [
			'title' => 'EXPORT DATA BENTUK PD DIKTI',
			'dashboard' => '',
			'gel' => '',
			'gel1' => '',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => 'active',
			'gelombang' => $this->MahasiswaModel->getMahasiswa2(),
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
		];

		echo view('admin/panitia/exdata-1', $data);
	}

	public function exdata2()
	{
		$tahun_akademik = \session('cobas');
		$keyword = $this->request->getVar('keyword');
		\session()->set('panda_4', $keyword);
		if ($tahun_akademik) {
			if ($keyword) {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik, $keyword);
			} else {
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik);
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
			}
		} else {
			$havevalidation = "error";
			$gelombangs = "error";
			$allpendaftar = "error";
		}

		$data = [
			'title' => 'EXPORT DATA BENTUK SIAKAD',
			'dashboard' => '',
			'gel' => '',
			'gel1' => '',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => 'active',
			'gelombang' => $this->MahasiswaModel->GetMahasiswa3(),
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
		];

		echo view('admin/panitia/exdata-2', $data);
	}

	public function deletemhs($id_mahasiswa)
	{
		$mahasiswa_baru = $this->MahasiswaModel->find($id_mahasiswa);

		if ($mahasiswa_baru['bukti_pembayaran'] != 'default.jpg') {
			unlink('homes/buktitf/' . $mahasiswa_baru['bukti_pembayaran']);
		}

		$this->MahasiswaModel->delete($id_mahasiswa);
		session()->setFlashdata('pesan', 'Data Calon Mahasiswa Baru Berhasil Dihapus');
		return redirect()->to('/data-gelombang-1');
	}

	public function validasi()
	{


		$tahun_akademik = \session('cobas');
		if ($tahun_akademik) {
			$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa2($tahun_akademik);
			$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
			$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
			$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
		} else {
			$havevalidation = "error";
			$gelombangs = "error";
			$allpendaftar = "error";
		}

		$currentPage = $this->request->getVar('page_mahasiswa_baru') ? $this->request->getVar('page_mahasiswa_baru') : 1;
		$data = [
			'title' => 'VALIDASI PENDAFTARAN CALON MAHASISWA',
			'dashboard' => '',
			'gel' => 'active',
			'gel1' => '',
			'gel2' => 'active',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'gelombang' => $gelombangs->paginate(10, 'mahasiswa_baru'),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'pager' => $this->MahasiswaModel->pager,
			'currentPage' => $currentPage,
		];

		return view('admin/panitia/validasi', $data);
	}

	public function validasimhs($id_mahasiswa)
	{

		$tahun_akademik = \session('cobas');
		$keyword = $this->request->getVar('keyword');
		\session()->set('panda_4', $keyword);
		if ($tahun_akademik) {
			if ($keyword) {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$nomorpai = $this->MahasiswaModel8->GetNomorPai($tahun_akademik);
				$nomorpgmi = $this->MahasiswaModel2->GetNomorPgmi($tahun_akademik);
				$nomorpiaud = $this->MahasiswaModel3->GetNomorPiaud($tahun_akademik);
				$nomorekos = $this->MahasiswaModel4->GetNomorEkos($tahun_akademik);
				$nomorps = $this->MahasiswaModel5->GetNomorPs($tahun_akademik);
				$nomorhki = $this->MahasiswaModel6->GetNomorHki($tahun_akademik);
				$nomorpmi = $this->MahasiswaModel7->GetNomorPmi($tahun_akademik);
				$nomormat = $this->MahasiswaModel15->GetNomorMat($tahun_akademik);
				$nomormagisterpai = $this->MahasiswaModel10->GetNomorMagisterPai($tahun_akademik);
			} else {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$nomorpai = $this->MahasiswaModel8->GetNomorPai($tahun_akademik);
				$nomorpgmi = $this->MahasiswaModel2->GetNomorPgmi($tahun_akademik);
				$nomorpiaud = $this->MahasiswaModel3->GetNomorPiaud($tahun_akademik);
				$nomorekos = $this->MahasiswaModel4->GetNomorEkos($tahun_akademik);
				$nomorps = $this->MahasiswaModel5->GetNomorPs($tahun_akademik);
				$nomorhki = $this->MahasiswaModel6->GetNomorHki($tahun_akademik);
				$nomorpmi = $this->MahasiswaModel7->GetNomorPmi($tahun_akademik);
				$nomormat = $this->MahasiswaModel15->GetNomorMat($tahun_akademik);
				$nomormagisterpai = $this->MahasiswaModel10->GetNomorMagisterPai($tahun_akademik);
			}
		} else {
			$havevalidation = "error";
			$gelombangs = "error";
			$allpendaftar = "error";
		}

		$currentPage = $this->request->getVar('page_mahasiswa_baru') ? $this->request->getVar('page_mahasiswa_baru') : 1;
		$data = [
			'title' => 'VALIDASI CALON MAHASISWA',
			'dashboard' => '',
			'gel' => 'active',
			'gel1' => 'active',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'mahasiswa' => $this->MahasiswaModel->GetEditMahasiswa($id_mahasiswa),
			'jurusan' => $this->MahasiswaModel->getJurusan(),
			'validasi' => $this->MahasiswaModel->getValidasi(),
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'pager' => $this->MahasiswaModel->pager,
			'currentPage' => $currentPage,
			'nomor_pai' => $nomorpai->paginate(1),
			'nomor_pgmi' => $nomorpgmi->paginate(1),
			'nomor_piaud' => $nomorpiaud->paginate(1),
			'nomor_ekos' => $nomorekos->paginate(1),
			'nomor_ps' => $nomorps->paginate(1),
			'nomor_hki' => $nomorhki->paginate(1),
			'nomor_pmi' => $nomorpmi->paginate(1),
			'nomor_mat' => $nomormat->paginate(1),
			'nomor_magisterpai' => $nomormagisterpai->paginate(1),
		];

		return view('admin/panitia/validasi-mahasiswa', $data);
	}

	public function validasimhss($id_mahasiswa)
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'id_mahasiswa' => [
					'label' => 'ID Mahasiswa',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
				'nomor_pendaftaran' => [
					'label' => 'Nomor Pendaftaran',
					'rules' => 'required|is_unique[mahasiswa_baru.nomor_pendaftaran]|numeric',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => '{field} sudah ada, lihat di atas sesuai pilihan pertama',
						'numeric' => '{field} harus angka',
					]
				],

			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'id_mahasiswa' => $validation->getError('id_mahasiswa'),
						'nomor_pendaftaran' => $validation->getError('nomor_pendaftaran'),
						'jurusan_1' => $validation->getError('jurusan_1'),
						'jurusan_2' => $validation->getError('jurusan_2'),
					]
				];
			} else {
				$this->MahasiswaModel->save([
					'id_mahasiswa' => $id_mahasiswa,
					'nomor_pendaftaran' => $this->request->getVar('nomor_pendaftaran'),
					'id_validasi_pendaftaran' => "1",
				]);

				$msg = [
					'sukses' => 'Validasi berhasil'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/panitia');
		}
	}
	
	public function getreward($id_mahasiswa)
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'id_mahasiswa' => [
					'label' => 'ID Mahasiswa',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],

			]);
			if (!$valid) {
				$msg = [
					'error' => [
					'id_mahasiswa' => $validation->getError('id_mahasiswa'),
					]
				];
			} else {
				$this->MahasiswaModel->save([
					'id_mahasiswa' => $id_mahasiswa,
					'reward' => "2",
				]);

				$msg = [
					'sukses' => 'Get Reward Berhasil'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/panitia');
		}
	}

	public function printkartumhs($nomor_pendaftaran)
	{
		$data = [
			'title' => 'CETAK KARTU UJIAN CALON MAHASISWA',
			'mahasiswa' => $this->MahasiswaModel->GetCetakKartu($nomor_pendaftaran),
			'kartu' => $this->KartuModel->find(1),
		];

		return view('admin/panitia/cetak-kartu-mahasiswa', $data);
	}

	public function printformulirmhs($nomor_pendaftaran)
	{
		$data = [
			'title' => 'CETAK FORMULIR PENDAFTARAN CALON MAHASISWA',
			'mahasiswa' => $this->MahasiswaModel->GetCetakFormulir($nomor_pendaftaran),
			'kartu' => $this->KartuModel->find(1),
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
		];

		return view('admin/panitia/cetak-formulir-mahasiswa', $data);
	}

	public function printformulirmhsmgs($nomor_pendaftaran)
	{
		$data = [
			'title' => 'CETAK FORMULIR PENDAFTARAN CALON MAHASISWA MAGISTER',
			'mahasiswa' => $this->MahasiswaModel->GetCetakFormulir($nomor_pendaftaran),
			'kartu' => $this->KartuModel->find(1),
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
		];

		return view('admin/panitia/cetak-formulir-mahasiswa-magister', $data);
	}

	public function editmhsmgs($id_mahasiswa)
	{


		$tahun_akademik = \session('cobas');
		$keyword = $this->request->getVar('keyword');
		\session()->set('panda_4', $keyword);
		if ($tahun_akademik) {
			if ($keyword) {
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik, $keyword);
			} else {
				$gelombangs = $this->MahasiswaModel->GetCalonMahasiswa($tahun_akademik);
				$havevalidation = $this->MahasiswaModel->GetHaveValidation($tahun_akademik);
				$allpendaftar = $this->MahasiswaModel->GetAllPendaftar($tahun_akademik);
				$notvalidation = $this->MahasiswaModel->GetNotValidation($tahun_akademik);
			}
		} else {
			$havevalidation = "error";
			$gelombangs = "error";
			$allpendaftar = "error";
		}

		$currentPage = $this->request->getVar('page_mahasiswa_baru') ? $this->request->getVar('page_mahasiswa_baru') : 1;
		$data = [
			'title' => 'EDIT DATA CALON MAHASISWA S2',
			'dashboard' => '',
			'gel' => 'active',
			'gel1' => 'active',
			'gel2' => '',
			'gel3' => '',
			'offline' => '',
			'peng' => '',
			'mahasiswa' => $this->MahasiswaModel->GetEditDataMahasiswa($id_mahasiswa),
			'jalur_pendaftaran' => $this->MahasiswaModel->getJalur(),
			'jenis_kelamin' => $this->MahasiswaModel->getKelamin(),
			'agama' => $this->MahasiswaModel->getAgama(),
			'wn' => $this->MahasiswaModel->getNegara(),
			'status' => $this->MahasiswaModel->getStatus(),
			'pendidikan_ayah' => $this->MahasiswaModel->getPendidikanOrtu(),
			'pekerjaan_ayah'  => $this->MahasiswaModel->getpekerjaanOrtu(),
			'pendidikan_ibu'  => $this->MahasiswaModel->getpendidikanOrtu(),
			'pekerjaan_ibu'   => $this->MahasiswaModel->getpekerjaanOrtu(),
			'penghasilan_wali' => $this->MahasiswaModel->getpenghasilan(),
			'status_pendaftaran' => $this->MahasiswaModel->GetPendaftaran(),
			'tahun_akademiks' => $this->TahunAkademikModel->GetStatusTahunAkademik(1),
			'gelombang' => $gelombangs->paginate(10, 'mahasiswa_baru'),
			'allpendaftar' => $allpendaftar,
			'havevalidation' => $havevalidation,
			'getoffline' => $this->DataOfflineModel->GetAllOffline(),
			'notvalidation' => $notvalidation,
			'pager' => $this->MahasiswaModel->pager,
			'currentPage' => $currentPage,
		];

		return view('admin/panitia/edit-mahasiswa-magister', $data);
	}
	
	public function printkarturekom($nomor_pendaftaran)
	{
		$data = [
			'title' => 'CETAK KARTU REKOMENDASI',
			'mahasiswa' => $this->MahasiswaModel->GetCetakKartuRekom($nomor_pendaftaran),
			'kartu' => $this->KartuModel->find(1),
		];

		return view('admin/panitia/cetak-kartu-rekomendasi', $data);
	}
	
	public function cekkoderedeem($nomor_pendaftaran)
	{
		$data = [
			'title' => 'CEK KODE REDEEM',
			'mahasiswa' => $this->MahasiswaModel->GetCetakKartuRekom($nomor_pendaftaran),
			'kartu' => $this->KartuModel->find(1),
		];

		return view('admin/panitia/cek-kode-redeem', $data);
	}
}
