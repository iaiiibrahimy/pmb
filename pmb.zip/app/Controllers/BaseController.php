<?php

namespace App\Controllers;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 *
 * @package CodeIgniter
 */

use CodeIgniter\Controller;

class BaseController extends Controller
{

	/**
	 * An array of helpers to be loaded automatically upon
	 * class instantiation. These helpers will be available
	 * to all other controllers that extend BaseController.
	 *
	 * @var array
	 */
	protected $helpers = ['form', 'url', 'text', 'array'];

	/**
	 * Constructor.
	 */
	public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
	{
		// Do Not Edit This Line
		parent::initController($request, $response, $logger);

		//--------------------------------------------------------------------
		// Preload any models, libraries, etc, here.
		//--------------------------------------------------------------------
		// E.g.:
		// $this->session = \Config\Services::session();
		session();
		$this->validation = \Config\Services::validation();
		$this->pengaturanModel = new \App\Models\PengaturanModel;
		$this->PanitiaModel = new \App\Models\PanitiaModel;
		$this->DeveloperModel = new \App\Models\DeveloperModel;
		$this->MahasiswaModel = new \App\Models\MahasiswaModel;
		$this->MahasiswaModel2 = new \App\Models\MahasiswaModel2;
		$this->MahasiswaModel3 = new \App\Models\MahasiswaModel3;
		$this->MahasiswaModel4 = new \App\Models\MahasiswaModel4;
		$this->MahasiswaModel5 = new \App\Models\MahasiswaModel5;
		$this->MahasiswaModel6 = new \App\Models\MahasiswaModel6;
		$this->MahasiswaModel7 = new \App\Models\MahasiswaModel7;
		$this->MahasiswaModel8 = new \App\Models\MahasiswaModel8;
		$this->MahasiswaModel9 = new \App\Models\MahasiswaModel9;
		$this->MahasiswaModel10 = new \App\Models\MahasiswaModel10;
		$this->MahasiswaModel15 = new \App\Models\MahasiswaModel15;
		$this->JalurModel = new \App\Models\JalurModel;
		$this->AuthModel = new \App\Models\AuthModel;
		$this->AutheModel = new \App\Models\AutheModel;
		$this->GelombangModel = new \App\Models\GelombangModel;
		$this->SliderModel = new \App\Models\SliderModel;
		$this->KartuModel = new \App\Models\KartuModel;
		$this->DataOfflineModel = new \App\Models\DataOfflineModel;
		$this->TahunAkademikModel = new \App\Models\TahunAkademikModel;
		$this->TahunAkademik2Model = new \App\Models\TahunAkademik2Model;
		$this->TutupModel = new \App\Models\TutupModel;
	}
}
