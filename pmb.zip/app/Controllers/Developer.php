<?php

namespace App\Controllers;


class Developer extends BaseController
{
	public function index()
	{
		$data = [
			'validation' => $this->validation,
			'title' => 'DEVELOPER IAI IBRAHIMY',
			'dashboard' => 'active',
			'user' => '',
			'panitia' => '',
			'developer' => '',
			'gelombangstatus' => $this->GelombangModel->find(1),
			'gelombang' => $this->GelombangModel->getGelombang(),
			'tahun_akademik' => $this->TahunAkademikModel->find(1),
			'stahun_akademik' => $this->TahunAkademikModel->getTahunAkademik(),
			'tutup_pendaftaran' => $this->TutupModel->find(1),
			'stutup_pendaftaran' => $this->TutupModel->getTutupPendaftaran(),
		];

		echo view('admin/developer/developer-pmb', $data);
	}

	public function tambahta()
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'tahun_akademik' => [
					'label' => 'Tahun Akademik',
					'rules' => 'required|is_unique[tahun_akademik.nama_tahun_akademik]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => 'Tahun Akademik yang anda masukkan sudah ada',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'tahun_akademik' => $validation->getError('tahun_akademik'),
					]
				];
			} else {

				$this->TahunAkademik2Model->save([
					'nama_tahun_akademik' => $this->request->getVar('tahun_akademik'),
				]);

				$msg = [
					'sukses' => 'Tahun Akademik baru ditambah'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/developer');
		}
	}

	public function ubahakademik()
	{
		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'tahun_akademik' => [
					'label' => 'Tahun Akademik',
					'rules' => 'required|is_unique[tahun_akademik.nama_tahun_akademik]',
					'errors' => [
						'required' => '{field} wajib diisi',
						'is_unique' => 'Tahun Akademik yang anda masukkan sudah ada',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'tahun_akademik' => $validation->getError('tahun_akademik'),
					]
				];
			} else {

				$this->TahunAkademikModel->save([
					'id_tahun_akademik_status' => '1',
					'id_tahun_akademiks' => $this->request->getVar('tahun_akademik'),
				]);

				$msg = [
					'sukses' => 'Tahun Akademik diubah'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/developer');
		}
	}

	public function ubahgelombang()
	{

		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'gelombang' => [
					'label' => 'Gelombang',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'gelombang' => $validation->getError('gelombang'),
					]
				];
			} else {

				$this->GelombangModel->save([
					'id_gelombang_status' => '1',
					'id_gelombang' => $this->request->getVar('gelombang'),
				]);

				$msg = [
					'sukses' => 'Gelombang diubah'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/developer');
		}
	}

	public function ubahtutup()
	{

		if ($this->request->isAJAX()) {

			$validation = $this->validation;
			$valid = $this->validate([
				'tutup' => [
					'label' => 'Status Pendaftaran',
					'rules' => 'required',
					'errors' => [
						'required' => '{field} wajib diisi',
					]
				],
			]);
			if (!$valid) {
				$msg = [
					'error' => [
						'tutup' => $validation->getError('tutup'),
					]
				];
			} else {

				$this->TutupModel->save([
					'id_tutup_pendaftaran_status' => '1',
					'id_tutup_pendaftaran' => $this->request->getVar('tutup'),
				]);

				$msg = [
					'sukses' => 'Status pendaftaran diubah'
				];
			}
			echo json_encode($msg);
		} else {
			return redirect()->to('/developer');
		}
	}

	public function panitiapmb()
	{
		$data = [
			'title' => 'DEVELOPER IAI IBRAHIMY',
			'dashboard' => '',
			'user' => 'active',
			'panitia' => 'active',
			'developer' => '',
			'panitial' => $this->PanitiaModel->findAll()
		];

		echo view('admin/developer/list-user-panitia', $data);
	}

	public function tambahpanitia()
	{

		if (!$this->validate([
			'username' => [
				'rules' => 'required|is_unique[panitia_pmb.username]|alpha_dash',
				'errors' => [
					'required' => '{field} wajib diisi',
					'is_unique' => '{field} sudah terdaftar',
					'alpha_dash' => '{field} tidak boleh menggunakan spasi',
				]
			],
			'nama_panitia' => [
				'rules' => 'required',
				'errors' => [
					'required' => 'Nama Panitia wajib diisi',
				]
			],
			'password' => [
				'rules' => 'required|min_length[4]',
				'errors' => [
					'required' => 'Password tidak boleh kosong',
					'min_length' => 'Password minimal 4 karakter',
				]
			]
		])) {
			return redirect()->to('/developer')->withInput();
		}

		$this->PanitiaModel->save([
			'username' => $this->request->getVar('username'),
			'nama_panitia' => $this->request->getVar('nama_panitia'),
			'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
		]);

		session()->setFlashdata('pesan', 'Panitia baru berhasil ditambahkan');

		return redirect()->to('/developer');
	}

	public function developerpmb()
	{
		$data = [
			'title' => 'DEVELOPER IAI IBRAHIMY',
			'dashboard' => '',
			'user' => 'active',
			'panitia' => '',
			'developer' => 'active',
			'developerl' => $this->DeveloperModel->findAll()
		];

		echo view('admin/developer/list-user-developer', $data);
	}

	public function tambahdeveloper()
	{
		if (!$this->validate([
			'usernamed' => [
				'rules' => 'required|is_unique[developer.username]|alpha_dash',
				'errors' => [
					'required' => 'Username wajib diisi',
					'is_unique' => 'Username sudah terdaftar',
					'alpha_dash' => 'Username tidak boleh menggunakan spasi',
				]
			],
			'nama_developer' => [
				'rules' => 'required',
				'errors' => [
					'required' => 'Nama Developer wajib diisi',
				]
			],
			'passwordd' => [
				'rules' => 'required|min_length[4]',
				'errors' => [
					'required' => 'Password tidak boleh kosong',
					'min_length' => 'Password minimal 4 karakter',
				]
			]
		])) {
			return redirect()->to('/developer')->withInput();
		}

		$this->DeveloperModel->save([
			'username' => $this->request->getVar('usernamed'),
			'nama_developer' => $this->request->getVar('nama_developer'),
			'password' => password_hash($this->request->getVar('passwordd'), PASSWORD_DEFAULT),
		]);

		session()->setFlashdata('pesan', 'Developer baru berhasil ditambahkan');

		return redirect()->to('/developer');
	}
}
