<?= $this->extend('admin/template/loginadmin'); ?>


<?= $this->section('contents'); ?>
<div class="login-box">
    <div class="login-logo">
        <a href="#">Halo <b>Developer</b></a>
    </div>


    <?php if (session()->getFlashdata('pesan')) : ?>
        <div class="alert alert-warning ml-3 mr-3 text-center" role="alert">
            <?= session()->getFlashdata('pesan'); ?>
        </div>
    <?php endif; ?>
    <!-- /.login-logo -->
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Masuk sebagai developer</p>

            <form action="/home/login_developerr" method="post">
                <div class="input-group mb-3">
                    <input type="username" name="username" id="username" class="form-control" placeholder="Username Developer">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-shield-alt"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password Developer">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- /.col -->
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary btn-block"><strong> Sign In</strong></button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

            <div class="social-auth-links text-center mb-3">
                <a href="/login" class="btn btn-block btn-danger">
                    <i class=""></i> <strong> Kembali Ke Halaman LOGIN</strong>
                </a>
            </div>
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<?= $this->endSection(); ?>