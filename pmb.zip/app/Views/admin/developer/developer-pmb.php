<?= $this->extend('admin/template/dashboard-developer'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Form Tambah Tahun Akademik</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <div class="d-md-flex">
                    <div class="p-1 flex-fill ml-2 mr-2 mb-2" style="overflow: hidden">
                        <form action="/developer/tambahta" method="post" id="formtambahta">
                            <?= csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <h2>Tambah Tahun Akademik </h2>
                                </div>
                                <div class="col-md-12 mb-2">
                                    <div class="form-group mb-2">
                                        <input type="text" class="form-control" id="tahun_akademik" name="tahun_akademik" placeholder="Tulis Tahun Akademik">
                                        <div class="invalid-feedback errorTA">
                                        </div>
                                        <div class="valid-feedback validTA">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary Simpanta">Simpan</button>
                        </form>

                    </div>
                </div><!-- /.d-md-flex -->
            </div>
            <!-- /.card-body -->
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#formtambahta').submit(function(e) {
                e.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: "post",
                    url: $(this).attr('action'),
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    beforeSend: function() {
                        $('.Simpanta').attr('disable', 'disabled');
                        $('.Simpanta').html('<i class="fa fa-spin fa-spinner"></i>');
                    },
                    complete: function() {
                        $('.Simpanta').removeAttr('disable');
                        $('.Simpanta').html('Simpan');
                    },
                    success: function(response) {
                        if (response.error) {
                            if (response.error.tahun_akademik) {
                                $('#tahun_akademik').addClass('is-invalid');
                                $('.errorTA').html(response.error.tahun_akademik);
                            } else {
                                $('#tahun_akademik').removeClass('is-invalid');
                                $('#tahun_akademik').addClass('is-valid');
                                $('.validTA').html('Good!!');
                            };
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: response.sukses,
                            })

                            setTimeout(function() {
                                window.location.replace("/developer");
                            }, 2000);
                        }
                    },
                    error: function(xhr, ajaxOption, thrownError) {
                        alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
                    }
                });
                return false
            });
        });
    </script>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Form Ubah Tahun Akademik</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <div class="d-md-flex">
                    <div class="p-1 flex-fill ml-2 mr-2 mb-2" style="overflow: hidden">
                        <form action="/developer/ubahakademik" method="post" id="formeditta">
                            <?= csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <h2>Tahun Akademik saat ini </h2>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <select name="tahun_akademik" class="form-control" id="tahun_akademik">
                                            <?php foreach ($stahun_akademik as $tahun_akademiks) : ?>
                                                <?php if ($tahun_akademiks['id_tahun_akademik'] == $tahun_akademik['id_tahun_akademiks']) : ?>
                                                    <option value="<?= $tahun_akademiks['id_tahun_akademik']; ?>" selected> <?= $tahun_akademiks['nama_tahun_akademik']; ?></option>
                                                <?php else : ?>
                                                    <option value="<?= $tahun_akademiks['id_tahun_akademik']; ?>"> <?= $tahun_akademiks['nama_tahun_akademik']; ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback errorTahunAkademik">
                                        </div>
                                        <div class="valid-feedback validTahunAkademik">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary Simpanedita">Ubah</button>
                        </form>

                    </div>
                </div><!-- /.d-md-flex -->
            </div>
            <!-- /.card-body -->
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#formeditta').submit(function(e) {
                e.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: "post",
                    url: $(this).attr('action'),
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    beforeSend: function() {
                        $('.Simpanedita').attr('disable', 'disabled');
                        $('.Simpanedita').html('<i class="fa fa-spin fa-spinner"></i>');
                    },
                    complete: function() {
                        $('.Simpanedita').removeAttr('disable');
                        $('.Simpanedita').html('Ubah');
                    },
                    success: function(response) {
                        if (response.error) {
                            if (response.error.tahun_akademik) {
                                $('#tahun_akademik').addClass('is-invalid');
                                $('.errorTahunAkademik').html(response.error.tahun_akademik);
                            } else {
                                $('#tahun_akademik').removeClass('is-invalid');
                                $('#tahun_akademik').addClass('is-valid');
                                $('.validTahunAkademik').html('Good!!');
                            };
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: response.sukses,
                            })

                            setTimeout(function() {
                                window.location.replace("/developer");
                            }, 2000);
                        }
                    },
                    error: function(xhr, ajaxOption, thrownError) {
                        alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
                    }
                });
                return false
            });
        });
    </script>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Form Ubah Gelombang Pendaftaran</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <div class="d-md-flex">
                    <div class="p-1 flex-fill ml-2 mr-2 mb-2" style="overflow: hidden">
                        <form action="/developer/ubahgelombang" method="post" id="formeditgelombang">
                            <?= csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <h2>Gelombang Saat ini </h2>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <select name="gelombang" class="form-control" id="gelombang">
                                            <?php foreach ($gelombang as $gelombangs) : ?>
                                                <?php if ($gelombangs['id_gelombang'] == $gelombangstatus['id_gelombang']) : ?>
                                                    <option value="<?= $gelombangs['id_gelombang']; ?>" selected> <?= $gelombangs['gelombang']; ?></option>
                                                <?php else : ?>
                                                    <option value="<?= $gelombangs['id_gelombang']; ?>"> <?= $gelombangs['gelombang']; ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback errorGelombang">
                                        </div>
                                        <div class="valid-feedback validGelombang">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary Simpangelombang">Ubah</button>
                        </form>

                    </div>
                </div><!-- /.d-md-flex -->
            </div>
            <!-- /.card-body -->
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#formeditgelombang').submit(function(e) {
                e.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: "post",
                    url: $(this).attr('action'),
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    beforeSend: function() {
                        $('.Simpangelombang').attr('disable', 'disabled');
                        $('.Simpangelombang').html('<i class="fa fa-spin fa-spinner"></i>');
                    },
                    complete: function() {
                        $('.Simpangelombang').removeAttr('disable');
                        $('.Simpangelombang').html('Ubah');
                    },
                    success: function(response) {
                        if (response.error) {
                            if (response.error.gelombang) {
                                $('#gelombang').addClass('is-invalid');
                                $('.errorGelombang').html(response.error.gelombang);
                            } else {
                                $('#gelombang').removeClass('is-invalid');
                                $('#gelombang').addClass('is-valid');
                                $('.validGelombang').html('Good!!');
                            };
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: response.sukses,
                            })

                            setTimeout(function() {
                                window.location.replace("/developer");
                            }, 2000);
                        }
                    },
                    error: function(xhr, ajaxOption, thrownError) {
                        alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
                    }
                });
                return false
            });
        });
    </script>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Form Tutup/buka pendaftaran</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <div class="d-md-flex">
                    <div class="p-1 flex-fill ml-2 mr-2 mb-2" style="overflow: hidden">
                        <form action="/developer/ubahtutup" method="post" id="formedittutup">
                            <?= csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <h2>Status Pendaftaran Saat ini </h2>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <select name="tutup" class="form-control" id="tutup">
                                            <?php foreach ($stutup_pendaftaran as $stutup_pen) : ?>
                                                <?php if ($stutup_pen['id_tutup_pendaftaran'] == $tutup_pendaftaran['id_tutup_pendaftaran']) : ?>
                                                    <option value="<?= $stutup_pen['id_tutup_pendaftaran']; ?>" selected> <?= $stutup_pen['status_tutup_pendaftaran']; ?></option>
                                                <?php else : ?>
                                                    <option value="<?= $stutup_pen['id_tutup_pendaftaran']; ?>"> <?= $stutup_pen['status_tutup_pendaftaran']; ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback errorTutup">
                                        </div>
                                        <div class="valid-feedback validTutup">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary Simpantutup">Ubah</button>
                        </form>

                    </div>
                </div><!-- /.d-md-flex -->
            </div>
            <!-- /.card-body -->
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#formedittutup').submit(function(e) {
                e.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: "post",
                    url: $(this).attr('action'),
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    beforeSend: function() {
                        $('.Simpantutup').attr('disable', 'disabled');
                        $('.Simpantutup').html('<i class="fa fa-spin fa-spinner"></i>');
                    },
                    complete: function() {
                        $('.Simpantutup').removeAttr('disable');
                        $('.Simpantutup').html('Ubah');
                    },
                    success: function(response) {
                        if (response.error) {
                            if (response.error.tutup) {
                                $('#tutup').addClass('is-invalid');
                                $('.errorTutup').html(response.error.tutup);
                            } else {
                                $('#tutup').removeClass('is-invalid');
                                $('#tutup').addClass('is-valid');
                                $('.validTutup').html('Good!!');
                            };
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: response.sukses,
                            })

                            setTimeout(function() {
                                window.location.replace("/developer");
                            }, 2000);
                        }
                    },
                    error: function(xhr, ajaxOption, thrownError) {
                        alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
                    }
                });
                return false
            });
        });
    </script>

</div>




<div class="row">
    <!-- Left col -->
    <div class="col-md-6">
        <!-- MAP & BOX PANE -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Form Tambah Panitia Baru</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <div class="d-md-flex">
                    <div class="p-1 flex-fill ml-2 mr-2 mb-2" style="overflow: hidden">
                        <form action="/developer/tambahpanitia" method="post">
                            <?= csrf_field(); ?>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="username">Username Panitia</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('username')) ? 'is-invalid' : ''; ?>" name="username" id="username" placeholder="Tulis Username Panitia Baru" value="<?= old('username') ?>">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('username'); ?>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="nama_panitia">Nama Panitia</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('nama_panitia')) ? 'is-invalid' : ''; ?>" name="nama_panitia" id="nama_panitia" onkeyup="this.value=this.value.toUpperCase()" placeholder="Tulis Nama Panitia Baru" value="<?= old('nama_panitia') ?>">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('nama_panitia'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="password">Password Panitia Baru</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('password')) ? 'is-invalid' : ''; ?>" name="password" id="password" placeholder="Masukkan Password Panitia Baru">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('password'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Daftar</button>
                        </form>

                    </div>
                </div><!-- /.d-md-flex -->
            </div>
            <!-- /.card-body -->
        </div>
    </div>

    <div class="col-md-6">

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Form Tambah Mahasiswa Baru</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <div class="d-md-flex">
                    <div class="p-1 flex-fill ml-2 mr-2 mb-2" style="overflow: hidden">
                        <form action="/developer/tambahdeveloper" method="post">

                            <?= csrf_field(); ?>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="usernamed">Username Developer Baru</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('usernamed')) ? 'is-invalid' : ''; ?>" id="usernamed" name="usernamed" placeholder="Tulis Username Developer Baru" value="<?= old('usernamed') ?>">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('usernamed'); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="nama_developer">Nama Developer Baru</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('nama_developer')) ? 'is-invalid' : ''; ?>" id="nama_developer" name="nama_developer" onkeyup="this.value=this.value.toUpperCase()" placeholder="Tulis Nama Developer Baru" value="<?= old('nama_developer') ?>">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('nama_developer'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="passwordd">Password Developer Baru</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('passwordd')) ? 'is-invalid' : ''; ?>" id="passwordd" name="passwordd" placeholder="Masukkan Password Developer">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('passwordd'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Daftar</button>
                        </form>

                    </div>
                </div><!-- /.d-md-flex -->
            </div>
            <!-- /.card-body -->
        </div>
    </div>
    <!-- /.card -->
</div>
<?= $this->endSection(); ?>