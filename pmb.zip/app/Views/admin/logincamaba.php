<?= $this->extend('admin/template/loginadmin'); ?>


<?= $this->section('contents'); ?>
<div class="login-box">
    <div class="login-logo">
        <a href="#">Calon <b>Mahasiswa</b></a>
    </div>
    <!-- /.login-logo -->
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Masuk sebagai calon mahasiswa</p>

            <form action="#" method="post">
                <div class="input-group mb-3">
                    <input type="email" class="form-control" placeholder="Nomor Pendaftaran">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-user-graduate"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" class="form-control" placeholder="Password Calon Mahasiswa">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- /.col -->
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary btn-block"><strong> Sign In</strong></button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

            <div class="social-auth-links text-center mb-3">
                <a href="/login" class="btn btn-block btn-danger">
                    <i class=""></i> <strong> Kembali Ke Halaman LOGIN</strong>
                </a>
            </div>
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<?= $this->endSection(); ?>