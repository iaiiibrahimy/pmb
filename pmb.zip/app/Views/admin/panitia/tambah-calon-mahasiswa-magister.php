<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah Calon Mahasiswa Magister Tahun Akademik <?= $tahun_akademiks['nama_tahun_akademik'] ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: #8B008B;"><strong>Nomor Magister PAI: <?php if (empty($nomor_magisterpai)) {
                                                                                                    ?>
                                    Nomor Masih Kosong
                                <?php } else { ?>
                                    <?php $jmpai = 1;
                                                                                                        foreach ($nomor_magisterpai as $nompai) : ?>
                                        <?= $jmpai += $nompai['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if ($tutup['id_tutup_pendaftaran'] == 1) {
    ?>


        <div class="card-body">
            <div class="card">
                <?php
                function tgl_indo($tanggal)
                {
                    $bulan = array(
                        1 =>   'JANUARI',
                        'FEBRUARI',
                        'MARET',
                        'APRIL',
                        'MEI',
                        'JUNI',
                        'JULI',
                        'AGUSTUS',
                        'SEPTEMBER',
                        'OKTOBER',
                        'NOVEMBER',
                        'DESEMBER'
                    );
                    $pecahkan = explode('-', $tanggal);

                    return $pecahkan[2] . ' ' . $bulan[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
                }
                ?>
                <div class="card-header">
                    <form action="/panitia/tambahmhsmgs" method="POST" id="formtambahmahasiswa" enctype="multipart/form-data">
                        <input type="hidden" name="gelombang" id="gelombang" value="<?= $gelombang['id_gelombang'] ?>" readonly>
                        <input type="hidden" name="tahun_akademik" id="tahun_akademik" value="<?= $tahun_akademiks['id_tahun_akademiks'] ?>" readonly>
                        <input type="hidden" name="tanggal_daftar" id="tanggal_daftar" value="<?= tgl_indo(date('Y-m-d')); ?>" readonly>
                        <div class="row">
                            <div class="col-md-12">
                                <h5 class="text-danger text-left"> Form yang bertanda * (bintang) wajib diisi</h5>
                            </div>
                            <div class="col-md-12 p-3 mb-2 bg-secondary text-white"><strong>Data Pribadi Calon Mahasiswa</strong></div>
                            <div class="col-md-4">
                                <label for="jalur_pendaftaran">Pilih jalur Pendaftaran*</label>
                                <select name="jalur_pendaftaran" class="form-control" id="jalur_pendaftaran">
                                    <option value="" selected>Pilih Jalur Pendaftaran</option>
                                    <?php
                                    foreach ($jalur_pendaftaran as $jalur_pendaftarann) {
                                        echo "<option value=" . $jalur_pendaftarann->id_jalur_pendaftaran . ">" . $jalur_pendaftarann->jalur_pendaftaran . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorJalurP">
                                </div>
                                <div class="valid-feedback validJalurP">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="nomor_pendaftaran">Nomor Pendaftaran*</label>
                                    <input type="text" class="form-control" id="nomor_pendaftaran" name="nomor_pendaftaran" placeholder="Tulis Nomor Pendaftaran" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNomorP">
                                    </div>
                                    <div class="valid-feedback validNomorP">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="nama_mahasiswa">Nama Lengkap Mahasiswa*</label>
                                    <input type="text" class="form-control" id="nama_mahasiswa" name="nama_mahasiswa" placeholder="Tulis Nama Anda" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNamaMahasiswa">
                                    </div>
                                    <div class="valid-feedback validNamaMahasiswa">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="nik">NIK (Nomor Induk kependudukan)*</label>
                                    <input type="text" class="form-control" id="nik" name="nik" placeholder="Tulis NIK Anda" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNikMahasiswa">
                                    </div>
                                    <div class="valid-feedback validNikMahasiswa">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="tempat_lahir">Kota/Kabupaten Anda Lahir*</label>
                                    <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" placeholder="Tulis Tempat Lahir Anda" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorTempatLahir">
                                    </div>
                                    <div class="valid-feedback validTempatLahir">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label for="tanggal_lahir">Tanggal Lahir*</label>
                                            <input type="text" class="form-control" id="tanggal_lahir" name="tanggal_lahir" placeholder="Contoh: 21" onkeyup="this.value=this.value.toUpperCase()">
                                            <div class="invalid-feedback errorTanggalLahir">
                                            </div>
                                            <div class="valid-feedback validTanggalLahir">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label for="bulan_lahir">Bulan Lahir*</label>
                                            <input type="text" class="form-control" id="bulan_lahir" name="bulan_lahir" placeholder="Contoh: 11" onkeyup="this.value=this.value.toUpperCase()">
                                            <div class="invalid-feedback errorBulanLahir">
                                            </div>
                                            <div class="valid-feedback validBulanLahir">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label for="tahun_lahir">Tahun Lahir*</label>
                                            <input type="text" class="form-control" id="tahun_lahir" name="tahun_lahir" placeholder="Contoh: 2003" onkeyup="this.value=this.value.toUpperCase()">
                                            <div class="invalid-feedback errorTahunLahir">
                                            </div>
                                            <div class="valid-feedback validTahunLahir">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="jenis_kelamin">Pilih Jenis Kelamin*</label>
                                <select name="jenis_kelamin" class="form-control" id="jenis_kelamin">
                                    <option value="" selected>Pilih Jenis Kelamin</option>
                                    <?php
                                    foreach ($jenis_kelamin as $jenis_kelaminn) {
                                        echo "<option value=" . $jenis_kelaminn->id_jenis_kelamin . ">" . $jenis_kelaminn->jenis_kelamin . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorJenisKelamin">
                                </div>
                                <div class="valid-feedback validJenisKelamin">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="agama">Pilih Agama Anda*</label>
                                <select name="agama" class="form-control" id="agama">
                                    <option value="" selected>Pilih Agama</option>
                                    <?php
                                    foreach ($agama as $agamaa) {
                                        echo "<option value=" . $agamaa->id_agama . ">" . $agamaa->agama . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorAgama">
                                </div>
                                <div class="valid-feedback validAgama">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="wn">Pilih Kewarganegaraan Anda*</label>
                                <select name="wn" class="form-control" id="wn">
                                    <option value="" selected>Pilih Kewarganegaraan</option>
                                    <?php
                                    foreach ($wn as $wnn) {
                                        echo "<option value=" . $wnn->id_wn . ">" . $wnn->nama_negara . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorNegara">
                                </div>
                                <div class="valid-feedback validNegara">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="status">Pilih Status Anda*</label>
                                <select name="status" class="form-control" id="status">
                                    <option value="" selected>Pilih Status</option>
                                    <?php
                                    foreach ($status as $statuss) {
                                        echo "<option value=" . $statuss->id_status . ">" . $statuss->nama_status . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorStats">
                                </div>
                                <div class="valid-feedback validStats">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="jalan">Nama Jalan (jika ada)</label>
                                    <input type="text" class="form-control" id="jalan" name="jalan" placeholder="Contoh: Jalan Kahuripan No.3" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorJalann">
                                    </div>
                                    <div class="valid-feedback validJalann">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="dusun">Nama Dusun (jika ada)</label>
                                    <input type="text" class="form-control" id="dusun" name="dusun" placeholder="Contoh: Krajan" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorDusunn">
                                    </div>
                                    <div class="valid-feedback validDusunn">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-2">
                                            <label for="rt">RT*</label>
                                            <input type="text" class="form-control" id="rt" name="rt" placeholder="Contoh: 02" onkeyup="this.value=this.value.toUpperCase()">
                                            <div class="invalid-feedback errorRtt">
                                            </div>
                                            <div class="valid-feedback validRtt">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-2">
                                            <label for="rw">RW*</label>
                                            <input type="text" class="form-control" id="rw" name="rw" placeholder="Contoh: 04" onkeyup="this.value=this.value.toUpperCase()">
                                            <div class="invalid-feedback errorRww">
                                            </div>
                                            <div class="valid-feedback validRww">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="kelurahan">Kelurahan*</label>
                                    <input type="text" class="form-control" id="kelurahan" name="kelurahan" placeholder="Contoh: Genteng Wetan" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorKelurahann">
                                    </div>
                                    <div class="valid-feedback validKelurahann">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="kecamatan">Kecamatan*</label>
                                    <input type="text" class="form-control" id="kecamatan" name="kecamatan" placeholder="Contoh: Genteng" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorKecamatann">
                                    </div>
                                    <div class="valid-feedback validKecamatann">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="kabupaten">Kabupaten*</label>
                                    <input type="text" class="form-control" id="kabupaten" name="kabupaten" placeholder="Contoh: Banyuwangi" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorKabupatenn">
                                    </div>
                                    <div class="valid-feedback validKabupatenn">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="no_hp">Nomor HP Anda*</label>
                                    <input type="text" class="form-control" id="no_hp" name="no_hp" placeholder="Contoh: 085123456789" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNomorHP">
                                    </div>
                                    <div class="valid-feedback validNomorHP">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="pendaftaran">Status Awal Pendaftaran*</label>
                                <select name="pendaftaran" class="form-control" id="pendaftaran">
                                    <option value="" selected>Pilih Status Awal</option>
                                    <?php
                                    foreach ($status_pendaftaran as $status_pen) {
                                        echo "<option value=" . $status_pen->id_status_pendaftaran . ">" . $status_pen->nama_pendaftaran . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorStatusP">
                                </div>
                                <div class="valid-feedback validStatusP">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="jurusan_1">Pilih Jurusan*</label>
                                <select name="jurusan_1" class="form-control" id="jurusan_1">
                                    <option value="" selected>Pilih Jurusan Pertama</option>
                                    <?php
                                    foreach ($jurusan as $jurusann) {
                                        echo "<option value=" . $jurusann->id_jurusan . ">" . $jurusann->nama_jurusan . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorJurusan1">
                                </div>
                                <div class="valid-feedback validJurusan1">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="byatung">Penanggung Biaya Kuliah*</label>
                                <select name="byatung" class="form-control" id="byatung">
                                    <option value="" selected>Pilih Penanggung Biaya Kuliah</option>
                                    <option value="Orang Tua">Orang Tua</option>
                                    <option value="Diri Sendiri">Diri Sendiri</option>
                                    <option value="Beasiswa">Beasiswa</option>
                                    <option value="Lainnya">Lainnya</option>
                                </select>
                                <div class="invalid-feedback errorByatungg">
                                </div>
                                <div class="valid-feedback validByatungg">
                                </div>
                            </div>

                            <div class="col-md-12 p-3 mb-2 mt-3 bg-secondary text-white"><strong>Riwayat Pendidikan </strong></div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="namsd_sar">Nama SD/MI*</label>
                                    <input type="text" class="form-control" id="namsd_sar" name="namsd_sar" placeholder="Contoh: SD Negeri 1 Banyuwangi" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNamesd">
                                    </div>
                                    <div class="valid-feedback validNamesd">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="tlulus_sd">Tahun Lulus SD/MI*</label>
                                    <input type="text" class="form-control" id="tlulus_sd" name="tlulus_sd" placeholder="Contoh: 2020" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorTulussd">
                                    </div>
                                    <div class="valid-feedback validTulussd">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="namsmp_sar">Nama SMP/MTS*</label>
                                    <input type="text" class="form-control" id="namsmp_sar" name="namsmp_sar" placeholder="Contoh: SMP Negeri 1 Banyuwangi" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNamesmp">
                                    </div>
                                    <div class="valid-feedback validNamesmp">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="tlulus_smp">Tahun Lulus SMP/MTS*</label>
                                    <input type="text" class="form-control" id="tlulus_smp" name="tlulus_smp" placeholder="Contoh: 2020" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorTulussmp">
                                    </div>
                                    <div class="valid-feedback validTulussmp">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="namsma_sar">Nama SMA/MA*</label>
                                    <input type="text" class="form-control" id="namsma_sar" name="namsma_sar" placeholder="Contoh: SMA Negeri 1 Banyuwangi" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNamesma">
                                    </div>
                                    <div class="valid-feedback validNamesma">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="tlulus_sma">Tahun Lulus SMA/MA*</label>
                                    <input type="text" class="form-control" id="tlulus_sma" name="tlulus_sma" placeholder="Contoh: 2020" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorTulussma">
                                    </div>
                                    <div class="valid-feedback validTulussma">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="nama_kampus">Nama Kampus S1*</label>
                                    <input type="text" class="form-control" id="nama_kampus" name="nama_kampus" placeholder="Contoh: IAI IBRAHIMY GENTENG" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNamaKampus">
                                    </div>
                                    <div class="valid-feedback validNamaKampus">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="tlulus_kul">Tahun Lulus S1*</label>
                                    <input type="text" class="form-control" id="tlulus_kul" name="tlulus_kul" placeholder="Contoh: 2020" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorTuluskul">
                                    </div>
                                    <div class="valid-feedback validTuluskul">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="prodi_sarjana">Prodi S1*</label>
                                    <input type="text" class="form-control" id="prodi_sarjana" name="prodi_sarjana" placeholder="Contoh: Prodi Pendidikan Agama Islam" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorProdiSarjana">
                                    </div>
                                    <div class="valid-feedback validProdiSarjana">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="ipk_sarjana">IPK S1*</label>
                                    <input type="text" class="form-control" id="ipk_sarjana" name="ipk_sarjana" placeholder="Contoh: 3.75" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorIpkSarjana">
                                    </div>
                                    <div class="valid-feedback validIpkSarjana">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="noser_ijas">Nomor Seri Ijasah S1*</label>
                                    <input type="text" class="form-control" id="noser_ijas" name="noser_ijas" placeholder="56-648-937" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNoserij">
                                    </div>
                                    <div class="valid-feedback validNoserij">
                                    </div>
                                </div>
                            </div>


                            <div class="col-md-12 p-3 mb-2 mt-3 bg-secondary text-white"><strong>Data Pekerjaan Calon Mahasiswa (Jika Ada)</strong></div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="tempat_kerja">Nama Tempat Kerja (Jika ada)</label>
                                    <input type="text" class="form-control" id="tempat_kerja" name="tempat_kerja" placeholder="Contoh: PT. Sampoerna tbk." onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorTempatKer">
                                    </div>
                                    <div class="valid-feedback validTempatKer">
                                    </div>
                                </div>
                                <div class="form-group mb-2">
                                    <label for="nomor_tel_kerja">Nomor Telepon Tempat Kerja (Jika ada)</label>
                                    <input type="text" class="form-control" id="nomor_tel_kerja" name="nomor_tel_kerja" placeholder="Contoh: 0333 958949" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorTelephoneKer">
                                    </div>
                                    <div class="valid-feedback validTelephoneKer">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="alamat_temker">Alamat Tempat Kerja (jika ada)</label>
                                    <textarea class="form-control" id="alamat_temker" name="alamat_temker" rows="4" onkeyup="this.value=this.value.toUpperCase()"></textarea>
                                    <div class="invalid-feedback errorAlamatTemker">
                                    </div>
                                    <div class="valid-feedback validAlamatTemker">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 p-3 mb-2 mt-3 bg-secondary text-white"><strong>Data Orang Tua Wali Calon Mahasiswa</strong></div>

                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="nama_ayah">Nama Ayah*</label>
                                    <input type="text" class="form-control" id="nama_ayah" name="nama_ayah" placeholder="Contoh: AGUS BUDI HARIYANTO" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNamaAy">
                                    </div>
                                    <div class="valid-feedback validNamaAy">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="pendidikan_ayah">Pilih Pendidikan Ayah*</label>
                                <select name="pendidikan_ayah" class="form-control" id="pendidikan_ayah">
                                    <option value="" selected>Pilih Pendidikan Ayah</option>
                                    <?php
                                    foreach ($pendidikan_ayah as $pendidikan_ayahh) {
                                        echo "<option value=" . $pendidikan_ayahh->id_pendidikan . ">" . $pendidikan_ayahh->pendidikan . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorPendidikanAy">
                                </div>
                                <div class="valid-feedback validPendidikanAy">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="pekerjaan_ayah">Pilih Pekerjaan Ayah*</label>
                                <select name="pekerjaan_ayah" class="form-control" id="pekerjaan_ayah">
                                    <option value="" selected>Pilih Pekerjaan Ayah</option>
                                    <?php
                                    foreach ($pekerjaan_ayah as $pekerjaan_ayahh) {
                                        echo "<option value=" . $pekerjaan_ayahh->id_pekerjaan . ">" . $pekerjaan_ayahh->pekerjaan . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorPekerjaanAy">
                                </div>
                                <div class="valid-feedback validPekerjaanAy">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-2">
                                    <label for="nama_ibu">Nama Ibu*</label>
                                    <input type="text" class="form-control" id="nama_ibu" name="nama_ibu" placeholder="Contoh: SUMIATI" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNamaIb">
                                    </div>
                                    <div class="valid-feedback validNamaIb">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="pendidikan_ibu">Pilih Pendidikan Ibu*</label>
                                <select name="pendidikan_ibu" class="form-control" id="pendidikan_ibu">
                                    <option value="" selected>Pilih Pendidikan Ibu</option>
                                    <?php
                                    foreach ($pendidikan_ayah as $pendidikan_ayahh) {
                                        echo "<option value=" . $pendidikan_ayahh->id_pendidikan . ">" . $pendidikan_ayahh->pendidikan . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorPendidikanIb">
                                </div>
                                <div class="valid-feedback validPendidikanIb">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="pekerjaan_ibu">Pilih Pekerjaan Ibu*</label>
                                <select name="pekerjaan_ibu" class="form-control" id="pekerjaan_ibu">
                                    <option value="" selected>Pilih Pekerjaan Ibu</option>
                                    <?php
                                    foreach ($pekerjaan_ayah as $pekerjaan_ayahh) {
                                        echo "<option value=" . $pekerjaan_ayahh->id_pekerjaan . ">" . $pekerjaan_ayahh->pekerjaan . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback errorPekerjaanIb">
                                </div>
                                <div class="valid-feedback validPekerjaanIb">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="penghasilan_wali">Penghasilan Wali*</label>
                                    <select name="penghasilan_wali" class="form-control" id="penghasilan_wali">
                                        <option value="" selected>Pilih Penghasilan Wali</option>
                                        <?php
                                        foreach ($penghasilan as $penghasilan_wali) {
                                            echo "<option value=" . $penghasilan_wali->id_penghasilan_wali . ">" . $penghasilan_wali->penghasilan . "</option>";
                                        }
                                        ?>
                                    </select>
                                    <div class="invalid-feedback errorPenghasilanWal">
                                    </div>
                                    <div class="valid-feedback validPenghasilanWal">
                                    </div>
                                </div>

                                <div class="form-group mb-2">
                                    <label for="nomor_hp_wali">Nomor HP Wali*</label>
                                    <input type="text" class="form-control" id="nomor_hp_wali" name="nomor_hp_wali" placeholder="Contoh: 085123456789" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNomorHPWali">
                                    </div>
                                    <div class="valid-feedback validNomorHPWali">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="alamat_wali">Alamat Lengkap Wali*</label>
                                    <textarea class="form-control" id="alamat_wali" name="alamat_wali" rows="4" onkeyup="this.value=this.value.toUpperCase()"></textarea>
                                    <div class="invalid-feedback errorAlamatWali">
                                    </div>
                                    <div class="valid-feedback validAlamatWali">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 p-3 mb-2 mt-3 bg-secondary text-white"><strong>Data Perekomendasi (Jika ada)</strong></div>

                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="nama_rekomendasi">Nama Lengkap Perekomendasi (jika ada)</label>
                                    <input type="text" class="form-control" id="nama_rekomendasi" name="nama_rekomendasi" placeholder="Tulis Nama Lengkap Perekomndasi" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNamaPerekom">
                                    </div>
                                    <div class="valid-feedback validNamaPerekom">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label for="nomor_rekomendasi">Nomor HP Perekomendasi (jika ada)</label>
                                    <input type="text" class="form-control" id="nomor_rekomendasi" name="nomor_rekomendasi" placeholder="Contoh: 085123456789" onkeyup="this.value=this.value.toUpperCase()">
                                    <div class="invalid-feedback errorNomorPerekom">
                                    </div>
                                    <div class="valid-feedback validNomorPerekom">
                                    </div>
                                </div>
                            </div>
                            <hr style="color: black;" class="col-md-12">
                            <div class="col-md-12">
                                <div class="modal-footer d-flex justify-content-center">
                                    <span class="input-group-append ">
                                        <button type="submit" class="btn btn-warning simpanMahasiswaBaru">Simpan Data</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                $('#formtambahmahasiswa').submit(function(e) {
                    e.preventDefault();

                    var formData = new FormData($(this)[0]);

                    $.ajax({
                        type: "post",
                        url: $(this).attr('action'),
                        cache: false,
                        data: formData,
                        processData: false,
                        contentType: false,
                        dataType: "json",
                        beforeSend: function() {
                            $('.simpanMahasiswaBaru').attr('disable', 'disabled');
                            $('.simpanMahasiswaBaru').html('<i class="fa fa-spin fa-spinner"></i>');
                        },
                        complete: function() {
                            $('.simpanMahasiswaBaru').removeAttr('disable');
                            $('.simpanMahasiswaBaru').html('Coba Simpan Data Lagi');
                        },
                        success: function(response) {
                            if (response.error) {
                                if (response.error.jalur_pendaftaran) {
                                    $('#jalur_pendaftaran').addClass('is-invalid');
                                    $('.errorJalurP').html(response.error.jalur_pendaftaran);
                                } else {
                                    $('#jalur_pendaftaran').removeClass('is-invalid');
                                    $('#jalur_pendaftaran').addClass('is-valid');
                                    $('.validJalurP').html('Benar!!');
                                };
                                if (response.error.pendaftaran) {
                                    $('#pendaftaran').addClass('is-invalid');
                                    $('.errorStatusP').html(response.error.pendaftaran);
                                } else {
                                    $('#pendaftaran').removeClass('is-invalid');
                                    $('#pendaftaran').addClass('is-valid');
                                    $('.validStatusP').html('Benar!!');
                                };
                                if (response.error.tanggal_daftar) {
                                    $('#tanggal_daftar').addClass('is-invalid');
                                    $('.errorJalurP').html(response.error.tanggal_daftar);
                                } else {
                                    $('#tanggal_daftar').removeClass('is-invalid');
                                    $('#tanggal_daftar').addClass('is-valid');
                                    $('.validJalurP').html('Benar!!');
                                };
                                if (response.error.nomor_pendaftaran) {
                                    $('#nomor_pendaftaran').addClass('is-invalid');
                                    $('.errorNomorP').html(response.error.nomor_pendaftaran);
                                } else {
                                    $('#nomor_pendaftaran').removeClass('is-invalid');
                                    $('#nomor_pendaftaran').addClass('is-valid');
                                    $('.validNomorP').html('Benar!!');
                                };
                                if (response.error.nama_mahasiswa) {
                                    $('#nama_mahasiswa').addClass('is-invalid');
                                    $('.errorNamaMahasiswa').html(response.error.nama_mahasiswa);
                                } else {
                                    $('#nama_mahasiswa').removeClass('is-invalid');
                                    $('#nama_mahasiswa').addClass('is-valid');
                                    $('.validNamaMahasiswa').html('Benar!!');
                                };
                                if (response.error.nik) {
                                    $('#nik').addClass('is-invalid');
                                    $('.errorNikMahasiswa').html(response.error.nik);
                                } else {
                                    $('#nik').removeClass('is-invalid');
                                    $('#nik').addClass('is-valid');
                                    $('.validNikMahasiswa').html('Benar!!');
                                };
                                if (response.error.tempat_lahir) {
                                    $('#tempat_lahir').addClass('is-invalid');
                                    $('.errorTempatLahir').html(response.error.tempat_lahir);
                                } else {
                                    $('#tempat_lahir').removeClass('is-invalid');
                                    $('#tempat_lahir').addClass('is-valid');
                                    $('.validTempatLahir').html('Benar!!');
                                };
                                if (response.error.tanggal_lahir) {
                                    $('#tanggal_lahir').addClass('is-invalid');
                                    $('.errorTanggalLahir').html(response.error.tanggal_lahir);
                                } else {
                                    $('#tanggal_lahir').removeClass('is-invalid');
                                    $('#tanggal_lahir').addClass('is-valid');
                                    $('.validTanggalLahir').html('Benar!!');
                                };
                                if (response.error.bulan_lahir) {
                                    $('#bulan_lahir').addClass('is-invalid');
                                    $('.errorBulanLahir').html(response.error.bulan_lahir);
                                } else {
                                    $('#bulan_lahir').removeClass('is-invalid');
                                    $('#bulan_lahir').addClass('is-valid');
                                    $('.validBulanLahir').html('Benar!!');
                                };
                                if (response.error.tahun_lahir) {
                                    $('#tahun_lahir').addClass('is-invalid');
                                    $('.errorTahunLahir').html(response.error.tahun_lahir);
                                } else {
                                    $('#tahun_lahir').removeClass('is-invalid');
                                    $('#tahun_lahir').addClass('is-valid');
                                    $('.validTahunLahir').html('Benar!!');
                                };
                                if (response.error.jenis_kelamin) {
                                    $('#jenis_kelamin').addClass('is-invalid');
                                    $('.errorJenisKelamin').html(response.error.jenis_kelamin);
                                } else {
                                    $('#jenis_kelamin').removeClass('is-invalid');
                                    $('#jenis_kelamin').addClass('is-valid');
                                    $('.validJenisKelamin').html('Benar!!');
                                };
                                if (response.error.agama) {
                                    $('#agama').addClass('is-invalid');
                                    $('.errorAgama').html(response.error.agama);
                                } else {
                                    $('#agama').removeClass('is-invalid');
                                    $('#agama').addClass('is-valid');
                                    $('.validAgama').html('Benar!!');
                                };
                                if (response.error.wn) {
                                    $('#wn').addClass('is-invalid');
                                    $('.errorNegara').html(response.error.wn);
                                } else {
                                    $('#wn').removeClass('is-invalid');
                                    $('#wn').addClass('is-valid');
                                    $('.validNegara').html('Benar!!');
                                };
                                if (response.error.status) {
                                    $('#status').addClass('is-invalid');
                                    $('.errorStats').html(response.error.status);
                                } else {
                                    $('#status').removeClass('is-invalid');
                                    $('#status').addClass('is-valid');
                                    $('.validStats').html('Benar!!');
                                };
                                if (response.error.jalan) {
                                    $('#jalan').addClass('is-invalid');
                                    $('.errorJalann').html(response.error.jalan);
                                } else {
                                    $('#jalan').removeClass('is-invalid');
                                    $('#jalan').addClass('is-valid');
                                    $('.validJalann').html('Benar!!');
                                };
                                if (response.error.dusun) {
                                    $('#dusun').addClass('is-invalid');
                                    $('.errorDusunn').html(response.error.dusun);
                                } else {
                                    $('#dusun').removeClass('is-invalid');
                                    $('#dusun').addClass('is-valid');
                                    $('.validDusunn').html('Benar!!');
                                };
                                if (response.error.rt) {
                                    $('#rt').addClass('is-invalid');
                                    $('.errorRtt').html(response.error.rt);
                                } else {
                                    $('#rt').removeClass('is-invalid');
                                    $('#rt').addClass('is-valid');
                                    $('.validRtt').html('Benar!!');
                                };
                                if (response.error.rw) {
                                    $('#rw').addClass('is-invalid');
                                    $('.errorRww').html(response.error.rw);
                                } else {
                                    $('#rw').removeClass('is-invalid');
                                    $('#rw').addClass('is-valid');
                                    $('.validRww').html('Benar!!');
                                };
                                if (response.error.kelurahan) {
                                    $('#kelurahan').addClass('is-invalid');
                                    $('.errorKelurahann').html(response.error.kelurahan);
                                } else {
                                    $('#kelurahan').removeClass('is-invalid');
                                    $('#kelurahan').addClass('is-valid');
                                    $('.validKelurahann').html('Benar!!');
                                };
                                if (response.error.kecamatan) {
                                    $('#kecamatan').addClass('is-invalid');
                                    $('.errorKecamatann').html(response.error.kecamatan);
                                } else {
                                    $('#kecamatan').removeClass('is-invalid');
                                    $('#kecamatan').addClass('is-valid');
                                    $('.validKecamatann').html('Benar!!');
                                };
                                if (response.error.kabupaten) {
                                    $('#kabupaten').addClass('is-invalid');
                                    $('.errorKabupatenn').html(response.error.kabupaten);
                                } else {
                                    $('#kabupaten').removeClass('is-invalid');
                                    $('#kabupaten').addClass('is-valid');
                                    $('.validKabupatenn').html('Benar!!');
                                };
                                if (response.error.no_hp) {
                                    $('#no_hp').addClass('is-invalid');
                                    $('.errorNomorHP').html(response.error.no_hp);
                                } else {
                                    $('#no_hp').removeClass('is-invalid');
                                    $('#no_hp').addClass('is-valid');
                                    $('.validNomorHP').html('Benar!!');
                                };
                                if (response.error.jurusan_1) {
                                    $('#jurusan_1').addClass('is-invalid');
                                    $('.errorJurusan1').html(response.error.jurusan_1);
                                } else {
                                    $('#jurusan_1').removeClass('is-invalid');
                                    $('#jurusan_1').addClass('is-valid');
                                    $('.validJurusan1').html('Benar!!');
                                };
                                if (response.error.tempat_kerja) {
                                    $('#tempat_kerja').addClass('is-invalid');
                                    $('.errorTempatKer').html(response.error.tempat_kerja);
                                } else {
                                    $('#tempat_kerja').removeClass('is-invalid');
                                    $('#tempat_kerja').addClass('is-valid');
                                    $('.validTempatKer').html('Benar!!');
                                };
                                if (response.error.nomor_tel_kerja) {
                                    $('#nomor_tel_kerja').addClass('is-invalid');
                                    $('.errorTelephoneKer').html(response.error.nomor_tel_kerja);
                                } else {
                                    $('#nomor_tel_kerja').removeClass('is-invalid');
                                    $('#nomor_tel_kerja').addClass('is-valid');
                                    $('.validTelephoneKer').html('Benar!!');
                                };
                                if (response.error.alamat_temker) {
                                    $('#alamat_temker').addClass('is-invalid');
                                    $('.errorAlamatTemker').html(response.error.alamat_temker);
                                } else {
                                    $('#alamat_temker').removeClass('is-invalid');
                                    $('#alamat_temker').addClass('is-valid');
                                    $('.validAlamatTemker').html('Benar!!');
                                };
                                if (response.error.nama_ayah) {
                                    $('#nama_ayah').addClass('is-invalid');
                                    $('.errorNamaAy').html(response.error.nama_ayah);
                                } else {
                                    $('#nama_ayah').removeClass('is-invalid');
                                    $('#nama_ayah').addClass('is-valid');
                                    $('.validNamaAy').html('Benar!!');
                                };
                                if (response.error.pendidikan_ayah) {
                                    $('#pendidikan_ayah').addClass('is-invalid');
                                    $('.errorPendidikanAy').html(response.error.pendidikan_ayah);
                                } else {
                                    $('#pendidikan_ayah').removeClass('is-invalid');
                                    $('#pendidikan_ayah').addClass('is-valid');
                                    $('.validPendidikanAy').html('Benar!!');
                                };
                                if (response.error.pekerjaan_ayah) {
                                    $('#pekerjaan_ayah').addClass('is-invalid');
                                    $('.errorPekerjaanAy').html(response.error.pekerjaan_ayah);
                                } else {
                                    $('#pekerjaan_ayah').removeClass('is-invalid');
                                    $('#pekerjaan_ayah').addClass('is-valid');
                                    $('.validPekerjaanAy').html('Benar!!');
                                };
                                if (response.error.nama_ibu) {
                                    $('#nama_ibu').addClass('is-invalid');
                                    $('.errorNamaIb').html(response.error.nama_ibu);
                                } else {
                                    $('#nama_ibu').removeClass('is-invalid');
                                    $('#nama_ibu').addClass('is-valid');
                                    $('.validNamaIb').html('Benar!!');
                                };
                                if (response.error.pendidikan_ibu) {
                                    $('#pendidikan_ibu').addClass('is-invalid');
                                    $('.errorPendidikanIb').html(response.error.pendidikan_ibu);
                                } else {
                                    $('#pendidikan_ibu').removeClass('is-invalid');
                                    $('#pendidikan_ibu').addClass('is-valid');
                                    $('.validPendidikanIb').html('Benar!!');
                                };
                                if (response.error.pekerjaan_ibu) {
                                    $('#pekerjaan_ibu').addClass('is-invalid');
                                    $('.errorPekerjaanIb').html(response.error.pekerjaan_ibu);
                                } else {
                                    $('#pekerjaan_ibu').removeClass('is-invalid');
                                    $('#pekerjaan_ibu').addClass('is-valid');
                                    $('.validPekerjaanIb').html('Benar!!');
                                };
                                if (response.error.penghasilan_wali) {
                                    $('#penghasilan_wali').addClass('is-invalid');
                                    $('.errorPenghasilanWal').html(response.error.penghasilan_wali);
                                } else {
                                    $('#penghasilan_wali').removeClass('is-invalid');
                                    $('#penghasilan_wali').addClass('is-valid');
                                    $('.validPenghasilanWal').html('Benar!!');
                                };
                                if (response.error.nomor_hp_wali) {
                                    $('#nomor_hp_wali').addClass('is-invalid');
                                    $('.errorNomorHPWali').html(response.error.nomor_hp_wali);
                                } else {
                                    $('#nomor_hp_wali').removeClass('is-invalid');
                                    $('#nomor_hp_wali').addClass('is-valid');
                                    $('.validNomorHPWali').html('Benar!!');
                                };
                                if (response.error.alamat_wali) {
                                    $('#alamat_wali').addClass('is-invalid');
                                    $('.errorAlamatWali').html(response.error.alamat_wali);
                                } else {
                                    $('#alamat_wali').removeClass('is-invalid');
                                    $('#alamat_wali').addClass('is-valid');
                                    $('.validAlamatWali').html('Benar!!');
                                };
                                if (response.error.nama_rekomendasi) {
                                    $('#nama_rekomendasi').addClass('is-invalid');
                                    $('.errorNamaPerekom').html(response.error.nama_rekomendasi);
                                } else {
                                    $('#nama_rekomendasi').removeClass('is-invalid');
                                    $('#nama_rekomendasi').addClass('is-valid');
                                    $('.validNamaPerekom').html('Benar!!');
                                };
                                if (response.error.nomor_rekomendasi) {
                                    $('#nomor_rekomendasi').addClass('is-invalid');
                                    $('.errorNomorPerekom').html(response.error.nomor_rekomendasi);
                                } else {
                                    $('#nomor_rekomendasi').removeClass('is-invalid');
                                    $('#nomor_rekomendasi').addClass('is-valid');
                                    $('.validNomorPerekom').html('Benar!!');
                                };
                                if (response.error.nama_kampus) {
                                    $('#nama_kampus').addClass('is-invalid');
                                    $('.errorNamaKampus').html(response.error.nama_kampus);
                                } else {
                                    $('#nama_kampus').removeClass('is-invalid');
                                    $('#nama_kampus').addClass('is-valid');
                                    $('.validNamaKampus').html('Benar!!');
                                };
                                if (response.error.prodi_sarjana) {
                                    $('#prodi_sarjana').addClass('is-invalid');
                                    $('.errorProdiSarjana').html(response.error.prodi_sarjana);
                                } else {
                                    $('#prodi_sarjana').removeClass('is-invalid');
                                    $('#prodi_sarjana').addClass('is-valid');
                                    $('.validProdiSarjana').html('Benar!!');
                                };
                                if (response.error.ipk_sarjana) {
                                    $('#ipk_sarjana').addClass('is-invalid');
                                    $('.errorIpkSarjana').html(response.error.ipk_sarjana);
                                } else {
                                    $('#ipk_sarjana').removeClass('is-invalid');
                                    $('#ipk_sarjana').addClass('is-valid');
                                    $('.validIpkSarjana').html('Benar!!');
                                };
                                if (response.error.byatung) {
                                    $('#byatung').addClass('is-invalid');
                                    $('.errorByatungg').html(response.error.byatung);
                                } else {
                                    $('#byatung').removeClass('is-invalid');
                                    $('#byatung').addClass('is-valid');
                                    $('.validByatungg').html('Benar!!');
                                };
                                if (response.error.namsd_sar) {
                                    $('#namsd_sar').addClass('is-invalid');
                                    $('.errorNamesd').html(response.error.namsd_sar);
                                } else {
                                    $('#namsd_sar').removeClass('is-invalid');
                                    $('#namsd_sar').addClass('is-valid');
                                    $('.validNamesd').html('Benar!!');
                                };
                                if (response.error.tlulus_sd) {
                                    $('#tlulus_sd').addClass('is-invalid');
                                    $('.errorTulussd').html(response.error.tlulus_sd);
                                } else {
                                    $('#tlulus_sd').removeClass('is-invalid');
                                    $('#tlulus_sd').addClass('is-valid');
                                    $('.validTulussd').html('Benar!!');
                                };
                                if (response.error.namsmp_sar) {
                                    $('#namsmp_sar').addClass('is-invalid');
                                    $('.errorNamesmp').html(response.error.namsmp_sar);
                                } else {
                                    $('#namsmp_sar').removeClass('is-invalid');
                                    $('#namsmp_sar').addClass('is-valid');
                                    $('.validNamesmp').html('Benar!!');
                                };
                                if (response.error.tlulus_smp) {
                                    $('#tlulus_smp').addClass('is-invalid');
                                    $('.errorTulussmp').html(response.error.tlulus_smp);
                                } else {
                                    $('#tlulus_smp').removeClass('is-invalid');
                                    $('#tlulus_smp').addClass('is-valid');
                                    $('.validTulussmp').html('Benar!!');
                                };
                                if (response.error.namsma_sar) {
                                    $('#namsma_sar').addClass('is-invalid');
                                    $('.errorNamesma').html(response.error.namsma_sar);
                                } else {
                                    $('#namsma_sar').removeClass('is-invalid');
                                    $('#namsma_sar').addClass('is-valid');
                                    $('.validNamesma').html('Benar!!');
                                };
                                if (response.error.tlulus_sma) {
                                    $('#tlulus_sma').addClass('is-invalid');
                                    $('.errorTulussma').html(response.error.tlulus_sma);
                                } else {
                                    $('#tlulus_sma').removeClass('is-invalid');
                                    $('#tlulus_sma').addClass('is-valid');
                                    $('.validTulussma').html('Benar!!');
                                };
                                if (response.error.tlulus_kul) {
                                    $('#tlulus_kul').addClass('is-invalid');
                                    $('.errorTuluskul').html(response.error.tlulus_kul);
                                } else {
                                    $('#tlulus_kul').removeClass('is-invalid');
                                    $('#tlulus_kul').addClass('is-valid');
                                    $('.validTuluskul').html('Benar!!');
                                };
                                if (response.error.noser_ijas) {
                                    $('#noser_ijas').addClass('is-invalid');
                                    $('.errorNoserij').html(response.error.noser_ijas);
                                } else {
                                    $('#noser_ijas').removeClass('is-invalid');
                                    $('#noser_ijas').addClass('is-valid');
                                    $('.validNoserij').html('Benar!!');
                                };

                                Swal.fire({
                                    icon: 'error',
                                    title: 'Oops... Pendaftaran gagal',
                                    text: 'Yuk, Cek kembali isian anda',
                                })

                            } else {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: response.sukses,
                                })

                                setTimeout(function() {
                                    window.location.replace("/data-gelombang-1");
                                }, 1500);
                            }
                        },
                        error: function(xhr, ajaxOption, thrownError) {
                            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
                        }
                    });
                    return false
                });
            });
        </script>


    <?php } else { ?>


        <?php if ($tutup['id_tutup_pendaftaran'] == 3) {
        ?>
            <br>
            <br>
            <br>
            <br>
            <br>
            <H3 class="text-center text-danger"><strong> MOHON MAAF PENDAFTARAN MAHASISWA BARU TAHUN AKADEMIK <?= $tahun_akademiks['nama_tahun_akademik']; ?> BELUM DIBUKA</strong></H3>
            <br>
            <br>
            <br>
            <br>
        <?php } else { ?>
            <br>
            <br>
            <br>
            <br>
            <br>
            <H3 class="text-center text-danger"><strong> MOHON MAAF PENDAFTARAN MAHASISWA BARU TAHUN AKADEMIK <?= $tahun_akademiks['nama_tahun_akademik']; ?> TELAH DITUTUP</strong></H3>
            <br>
            <br>
            <br>
            <br>
        <?php } ?>




    <?php } ?>


    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>