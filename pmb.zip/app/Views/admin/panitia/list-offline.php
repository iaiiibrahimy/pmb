<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">List Pendaftar Offline</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Gelombang</th>
                    <th>Nomor Tes</th>
                    <th>Program Studi</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Tanggal Lahir</th>
                    <th>Tempat Lahir</th>
                    <th>Agama</th>
                    <th>Nama Kelurahan</th>
                    <th>Nama Kecamatan</th>
                    <th>Nama Ibu</th>
                    <th>Kewarganegaraan</th>
                    <th>NISN</th>
                    <th>NIK</th>
                    <th>Nama Jalan</th>
                    <th>RT</th>
                    <th>RW</th>
                    <th>Nama Dusun</th>
                    <th>Nomor HP</th>
                    <th>E-Mail</th>
                    <th>Nama Ayah</th>
                    <th>Hapus</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($data_offline as $detof) : ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td><?= $detof['gelombang']; ?></td>
                        <td><?= $detof['nomor_test']; ?></td>
                        <td><?= $detof['nama_jurusan']; ?></td>
                        <td><?= $detof['nama']; ?></td>
                        <td><?= $detof['jenis_kelamin']; ?></td>
                        <td><?= $detof['ttl']; ?></td>
                        <td><?= $detof['tempat_lahir']; ?></td>
                        <td><?= $detof['agama']; ?></td>
                        <td><?= $detof['nama_kelurahan']; ?></td>
                        <td><?= $detof['nama_kecamatan']; ?></td>
                        <td><?= $detof['nama_ibu']; ?></td>
                        <td><?= $detof['nama_negara']; ?></td>
                        <td><?= $detof['nisn']; ?></td>
                        <td><?= $detof['nik']; ?></td>
                        <td><?= $detof['nama_jalan']; ?></td>
                        <td><?= $detof['rt']; ?></td>
                        <td><?= $detof['rw']; ?></td>
                        <td><?= $detof['dusun']; ?></td>
                        <td><?= $detof['hp']; ?></td>
                        <td><?= $detof['email']; ?></td>
                        <td><?= $detof['nama_ayah']; ?></td>
                        <td><a href="/panitia/delete_data_offline/<?= $detof['id_data_offline']; ?>" class="badge badge-danger d-inline">Delete</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>