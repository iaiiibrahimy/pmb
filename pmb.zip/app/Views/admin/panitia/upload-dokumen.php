<div class="p-3 mb-2 bg-dark text-white">Kolom Upload Sertifikat Calon Mahasiswa Jalur Beasiswa (jangan diisi jika mengikuti jalur Reguler)</div>

<div class="row">
    <div class="col-md-6">
        <div>
            <label for="sertifikat_1">Upload Sertifikat 1 (tidak wajib)</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input <?= ($validation->hasError('sertifikat_1')) ? 'is-invalid' : ''; ?>" id="sertifikat_1" name="sertifikat_1">
                <label class="custom-file-label <?= ($validation->hasError('sertifikat_1')) ? 'is-invalid' : ''; ?>" for="sertifikat_1"><?= $gelombangs['sertifikat_1']; ?></label>
                <small id="sertifikat_1" class="form-text text-muted">Format File Harus Berbentuk PDF dan tidak boleh lebi dari 1,2 MB.</small>
            </div>
            <div class="invalid-feedback">
                <?= $validation->getError('sertifikat_1'); ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div>
            <label for="sertifikat_2">Upload Sertifikat 2 (tidak wajib)</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input <?= ($validation->hasError('sertifikat_2')) ? 'is-invalid' : ''; ?>" id="sertifikat_2" name="sertifikat_2">
                <label class="custom-file-label <?= ($validation->hasError('sertifikat_2')) ? 'is-invalid' : ''; ?>" for="sertifikat_2"><?= $gelombangs['sertifikat_2']; ?></label>
                <small id="sertifikat_2" class="form-text text-muted">Format File Harus Berbentuk PDF dan tidak boleh lebi dari 1,2 MB.</small>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div>
            <label for="foto_mhs">Foto Anda (tidak wajib)</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input <?= ($validation->hasError('foto_mhs')) ? 'is-invalid' : ''; ?>" id="foto_mhs" name="foto_mhs">
                <label class="custom-file-label <?= ($validation->hasError('foto_mhs')) ? 'is-invalid' : ''; ?>" for="foto_mhs"><?= $gelombangs['foto_mhs']; ?></label>
                <small id="foto_mhs" class="form-text text-muted">Foto harus berekstensi JPG, JPEG, atau PNG dan Ukuran Foto tidak boleh lebih dari 1 MB.</small>
            </div>
            <div class="invalid-feedback">
                <?= $validation->getError('foto_mhs'); ?>
            </div>
        </div>
    </div>
</div>