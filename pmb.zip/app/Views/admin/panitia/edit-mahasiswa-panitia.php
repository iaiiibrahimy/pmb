<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="row">
    <!-- Left col -->
    <div class="col-md-12">
        <!-- MAP & BOX PANE -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Form Validasi Mahasiswa Baru
                </h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <div class="d-md-flex">
                    <div class="p-1 flex-fill ml-2 mr-2 mb-2" style="overflow: hidden">
                        <p class="text-danger"> Ket: <strong>*</strong> : Kolom wajib diisi</p>
                        <form action="/panitia/update/<?= $gelombangs['id_mahasiswa']; ?>" method="post">
                            <?= csrf_field(); ?>
                            <input type="hidden" name="id_mahasiswa" value="<?= $gelombangs['id_mahasiswa']; ?>">

                            <div class="p-3 mt-2 mb-2 bg-danger text-white"><STrong>HARAP ISI KOLOM DENGAN BENAR, APABILA TIDAK SESUAI MAKA DATA TIDAK AKAN TERSIMPAN!!!</STrong></div>
                            <div class="p-3 mb-2 bg-dark text-white">Kolom Validasi Calon Mahasiswa</div>

                            <div class="col-md-11 mt-3 mb-3 d-flex justify-content-center">
                                <img src="/homes/buktitf/<?= $gelombangs['bukti_pembayaran']; ?>" style="height:700px; width:1000px;" class="img-fluid" alt="Responsive image">
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="nomo_pendaftaran">Nomor Pendaftaran</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('nomor_pendaftaran')) ? 'is-invalid' : ''; ?>" name="nomor_pendaftaran" id="nomor_pendaftaran" value="<?= $gelombangs['nomor_pendaftaran']; ?>">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('nomor_pendaftaran'); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="id_validasi">Validasi</label>
                                        <select name="id_validasi" class="form-control <?= ($validation->hasError('id_validasi')) ? 'is-invalid' : ''; ?>" id="id_validasi">
                                            <?php foreach ($validasi as $valid) : ?>
                                                <?php if ($valid['id_validasi'] == $gelombangs['id_validasi']) : ?>
                                                    <option value="<?= $valid['id_validasi']; ?>" selected> <?= $valid['nama_validasi']; ?></option>
                                                <?php else : ?>
                                                    <option value="<?= $valid['id_validasi']; ?>"> <?= $valid['nama_validasi']; ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('id_validasi'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div class="mt-2 d-flex justify-content-center">
                                <button type="submit" class="btn btn-primary">Validasi</button>
                            </div>

                            <div class="p-3 mt-2 mb-2 bg-danger text-white"><STrong>HARAP ISI KOLOM DENGAN BENAR, APABILA TIDAK SESUAI MAKA DATA TIDAK AKAN TERSIMPAN!!!</STrong></div>

                        </form>

                    </div>
                </div><!-- /.d-md-flex -->
            </div>
            <!-- /.card-body -->
        </div>
    </div>
    <!-- /.card -->
</div>
<?= $this->endSection(); ?>