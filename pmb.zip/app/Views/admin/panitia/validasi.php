<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Validasi Pendaftaran Calon Mahasiswa Tahun Akademik <?= $tahun_akademiks['nama_tahun_akademik'] ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <?php if (empty($gelombang)) {
        ?>
            <h5 class="text-center">Tidak ada mahasiswa yang harus divalidasi</h5>

        <?php } else { ?>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Bordered Table</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 10px">NO</th>
                                    <th>Gelombang</th>
                                    <th>Status Pendaftaran</th>
                                    <th>Nomor Pendaftaran</th>
                                    <th>Nama Mahasiswa</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Jurusan 1</th>
                                    <th>Jurusan 2</th>
                                    <th>Perekom</th>
                                    <th>No. HP Perekom</th>
                                    <th style="width: 160px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1 + (10 * ($currentPage - 1)); ?>
                                <?php foreach ($gelombang as $gelo) : ?>
                                    <tr>
                                        <td class="text-center"><?= $i++; ?></td>
                                        <td><?= $gelo['gelombang']; ?></td>
                                        <td><?= $gelo['nama_status_pendaftaran']; ?></td>
                                        <td>Belum divalidasi</td>
                                        <td><?= $gelo['nama_mahasiswa']; ?></td>
                                        <td><?= $gelo['tanggal_lahir']; ?>-<?= $gelo['bulan_lahir']; ?>-<?= $gelo['tahun_lahir']; ?></td>
                                        <td><?= $gelo['nama_jurusan']; ?></td>
                                        <td><?= $gelo['nama_jurusan_2']; ?></td>
                                        <td><?= $gelo['nama_rekomendasi']; ?></td>
                                        <td><?= $gelo['nomor_rekomendasi']; ?></td>
                                        <td> <a href="/panitia/validasimhs/<?= $gelo['id_mahasiswa']; ?>" class="badge badge-primary d-inline">Validasi</a> | <a href="/panitia/deletemhs/<?= $gelo['id_mahasiswa']; ?>" class="badge badge-danger d-inline tombol-hapus">Delete</a></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?= $pager->links('mahasiswa_baru', 'halaman_pagination'); ?>
        <?php } ?>
    </div>
    <script>
        setTimeout(function() {
            window.location.reload(1);
        }, 20000);
    </script>
    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>