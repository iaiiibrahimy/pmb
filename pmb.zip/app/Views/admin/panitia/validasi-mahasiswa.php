<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah Calon Mahasiswa Tahun Akademik <?= $tahun_akademiks['nama_tahun_akademik'] ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: green;"> <strong> Nomor PAI:
                                <?php if (empty($nomor_pai)) {
                                ?>
                                    Belum ada nomor
                                <?php } else { ?>
                                    <?php $jpai = 1;
                                    foreach ($nomor_pai as $nopai) : ?>
                                        <?= $jpai += $nopai['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?>
                            </strong>
                        </h3>
                    </div>
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: #5F9EA0;"><strong>Nomor PGMI: <?php if (empty($nomor_pgmi)) {
                                                                                            ?>
                                    Belum ada nomor
                                <?php } else { ?>
                                    <?php $jpgmi = 1;
                                                                                                foreach ($nomor_pgmi as $nopgmi) : ?>
                                        <?= $jpgmi += $nopgmi['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: indigo;"><strong>Nomor PIAUD: <?php if (empty($nomor_piaud)) {
                                                                                            ?>
                                    Belum ada nomor
                                <?php } else { ?>
                                    <?php $jpiaud = 1;
                                                                                                foreach ($nomor_piaud as $nopiaud) : ?>
                                        <?= $jpiaud += $nopiaud['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: indigo;"><strong>Nomor Tadris Matematika: <?php if (empty($nomor_mat)) {
                                                                                            ?>
                                    Belum ada nomor
                                <?php } else { ?>
                                    <?php $jmat = 1;
                                                                                                foreach ($nomor_mat as $nomat) : ?>
                                        <?= $jmat += $nomat['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: #FFA500;"><strong>Nomor EKOS: <?php if (empty($nomor_ekos)) {
                                                                                            ?>
                                    Nomor Masih Kosong
                                <?php } else { ?>
                                    <?php $jekos = 1;
                                                                                                foreach ($nomor_ekos as $noekos) : ?>
                                        <?= $jekos += $noekos['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: #8B4513;"><strong>Nomor PSY: <?php if (empty($nomor_ps)) {
                                                                                            ?>
                                    Nomor Masih Kosong
                                <?php } else { ?>
                                    <?php $jps = 1;
                                                                                                foreach ($nomor_ps as $nops) : ?>
                                        <?= $jps += $nops['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: #808000;"><strong>Nomor HKI: <?php if (empty($nomor_hki)) {
                                                                                            ?>
                                    Nomor Masih Kosong
                                <?php } else { ?>
                                    <?php $jhki = 1;
                                                                                                foreach ($nomor_hki as $nohki) : ?>
                                        <?= $jhki += $nohki['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: #6495ED;"><strong>Nomor PMI: <?php if (empty($nomor_pmi)) {
                                                                                            ?>
                                    Nomor Masih Kosong
                                <?php } else { ?>
                                    <?php $jpmi = 1;
                                                                                                foreach ($nomor_pmi as $nopmi) : ?>
                                        <?= $jpmi += $nopmi['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: #8B008B;"><strong>Nomor Magister PAI: <?php if (empty($nomor_magisterpai)) {
                                                                                                    ?>
                                    Nomor Masih Kosong
                                <?php } else { ?>
                                    <?php $jmpai = 1;
                                                                                                        foreach ($nomor_magisterpai as $nompai) : ?>
                                        <?= $jmpai += $nompai['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="card">
            <div class="card-header">
                <form action="/panitia/validasimhss/<?= $mahasiswa['id_mahasiswa'] ?>" method="POST" id="formtambahmahasiswa" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-12">
                            <h5 class="text-danger text-left"> Form yang bertanda * (bintang) wajib diisi</h5>
                        </div>
                        <div class="col-md-12 p-3 mb-2 bg-secondary text-white"><strong>Jurusan Calon Mahasiswa</strong></div>
                        <input type="hidden" name="id_mahasiswa" id="id_mahasiswa" value="<?= $mahasiswa['id_mahasiswa'] ?>">

                        <div class="col-md-6">
                            <img src="/homes/buktitf/<?= $mahasiswa['bukti_pembayaran']; ?>" style="width:100%;" class="img-fluid" alt="Responsive image">
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-2">
                                <label for="nomor_pendaftaran">Nomor Pendaftaran*</label>
                                <input type="text" class="form-control" id="nomor_pendaftaran" name="nomor_pendaftaran" value="<?= $mahasiswa['nomor_pendaftaran'] ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback errorNomorP">
                                </div>
                                <div class="valid-feedback validNomorP">
                                </div>
                            </div>
                            <div class="form-group mb-2">
                                <label for="nama_mahasiswa">Nama Lengkap Mahasiswa (tidak bisa diubah)</label>
                                <input type="text" class="form-control" id="nama_mahasiswa" name="nama_mahasiswa" value="<?= $mahasiswa['nama_mahasiswa'] ?>" onkeyup="this.value=this.value.toUpperCase()" readonly>
                                <div class="invalid-feedback errorNamaMahasiswa">
                                </div>
                                <div class="valid-feedback validNamaMahasiswa">
                                </div>
                            </div>
                            <div class="form-group mb-2">
                                <label for="jurusan_1">Jurusan Pertama</label>
                                <input type="text" class="form-control" id="jurusan_1" name="jurusan_1" value="<?= $mahasiswa['nama_jurusan'] ?>" onkeyup="this.value=this.value.toUpperCase()" readonly>
                                <div class="invalid-feedback errorJurusan1">
                                </div>
                                <div class="valid-feedback validJurusan1">
                                </div>
                            </div>
                            <div class="form-group mb-2">
                                <label for="jurusan_2">Jurusan Ke-dua</label>
                                <input type="text" class="form-control" id="jurusan_2" name="jurusan_2" value="<?= $mahasiswa['nama_jurusan_2'] ?>" onkeyup="this.value=this.value.toUpperCase()" readonly>
                                <div class="invalid-feedback errorJurusan2">
                                </div>
                                <div class="valid-feedback validJurusan2">
                                </div>
                            </div>
                             <?php if (empty($mahasiswa['nama_rekomendasi'])) {
                                ?>
                                    
                                <?php } else { ?>
                                    <div class="form-group mb-2">
                                <label for="smt1">Nama Perekomendasi</label>
                                <input type="text" class="form-control" id="smt1" name="smt1" value="<?= $mahasiswa['nama_rekomendasi'] ?>" onkeyup="this.value=this.value.toUpperCase()" readonly>
                                <div class="invalid-feedback errorSMT1">
                                </div>
                                <div class="valid-feedback validSMT1">
                                </div>
                            </div>
                            <div class="form-group mb-2">
                                <label for="smt1">Nomor Perekomendasi</label>
                                <input type="text" class="form-control" id="smt1" name="smt1" value="<?= $mahasiswa['nomor_rekomendasi'] ?>" onkeyup="this.value=this.value.toUpperCase()" readonly>
                                <div class="invalid-feedback errorSMT1">
                                </div>
                                <div class="valid-feedback validSMT1">
                                </div>
                            </div>
                            <div class="form-group mb-2">
                                <label for="smt1">Kode Perekom</label>
                                <input type="text" class="form-control" id="smt1" name="smt1" value="<?= $mahasiswa['code_recom'] ?>" onkeyup="this.value=this.value.toUpperCase()" readonly>
                                <div class="invalid-feedback errorSMT1">
                                </div>
                                <div class="valid-feedback validSMT1">
                                </div>
                            </div>
                                <?php } ?>
                            
                            <div class="form-group mb-2">
                                <label for="smt1">Nilai Rata-rata Semester 1</label>
                                <input type="text" class="form-control" id="smt1" name="smt1" value="<?= $mahasiswa['rerata_smt1'] ?>" onkeyup="this.value=this.value.toUpperCase()" readonly>
                                <div class="invalid-feedback errorSMT1">
                                </div>
                                <div class="valid-feedback validSMT1">
                                </div>
                            </div>
                            <div class="form-group mb-2">
                                <label for="smt2">Nilai Rata-rata Semester 2</label>
                                <input type="text" class="form-control" id="smt2" name="smt2" value="<?= $mahasiswa['rerata_smt2'] ?>" onkeyup="this.value=this.value.toUpperCase()" readonly>
                                <div class="invalid-feedback errorSMT2">
                                </div>
                                <div class="valid-feedback validSMT2">
                                </div>
                            </div>
                            <div class="col-md-12 mt-3">
                                <div class="row d-flex justify-content-center">
                                    <div class="col-md-6">
                                        <a class="btn btn-outline-primary" href="/homes/smt1/<?= $mahasiswa['smt_1'] ?>" target="_blank" role="button">LIHAT DOKUMEN RAPORT SEMESTER 1</a>
                                    </div>
                                    <div class="col-md-6">
                                        <a class="btn btn-outline-primary" href="/homes/smt2/<?= $mahasiswa['smt_2'] ?>" target="_blank" role="button">LIHAT DOKUMEN RAPORT SEMESTER 2</a>
                                    </div>
                                </div>
                            </div>
                            <hr style="color: black;" class="col-md-12">
                            <div class="col-md-12">
                                <div class="modal-footer d-flex justify-content-center">
                                    <span class="input-group-append ">
                                        <button type="submit" class="btn btn-warning simpanMahasiswaEdit">Confirm Validasi</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#formtambahmahasiswa').submit(function(e) {
                e.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: "post",
                    url: $(this).attr('action'),
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    beforeSend: function() {
                        $('.simpanMahasiswaEdit').attr('disable', 'disabled');
                        $('.simpanMahasiswaEdit').html('<i class="fa fa-spin fa-spinner"></i>');
                    },
                    complete: function() {
                        $('.simpanMahasiswaEdit').removeAttr('disable');
                        $('.simpanMahasiswaEdit').html('Coba Validasi Lagi');
                    },
                    success: function(response) {
                        if (response.error) {
                            if (response.error.id_mahasiswa) {
                                $('#id_mahasiswa').addClass('is-invalid');
                                $('.errorIdMhs').html(response.error.id_mahasiswa);
                            } else {
                                $('#id_mahasiswa').removeClass('is-invalid');
                                $('#id_mahasiswa').addClass('is-valid');
                                $('.validIdMhs').html('Benar!!');
                            };
                            if (response.error.nomor_pendaftaran) {
                                $('#nomor_pendaftaran').addClass('is-invalid');
                                $('.errorNomorP').html(response.error.nomor_pendaftaran);
                            } else {
                                $('#nomor_pendaftaran').removeClass('is-invalid');
                                $('#nomor_pendaftaran').addClass('is-valid');
                                $('.validNomorP').html('Benar!!');
                            };
                            if (response.error.validasi) {
                                $('#validasi').addClass('is-invalid');
                                $('.errorValidasiPen').html(response.error.validasi);
                            } else {
                                $('#validasi').removeClass('is-invalid');
                                $('#validasi').addClass('is-valid');
                                $('.validValidasiPen').html('Benar!!');
                            };

                            Swal.fire({
                                icon: 'error',
                                title: 'Oops... Validasi gagal',
                                text: 'Yuk, Cek kembali isian anda',
                            })

                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: response.sukses,
                            })

                            setTimeout(function() {
                                window.location.replace("/validasi");
                            }, 1500);
                        }
                    },
                    error: function(xhr, ajaxOption, thrownError) {
                        alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
                    }
                });
                return false
            });
        });
    </script>
    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>