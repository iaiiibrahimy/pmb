<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title><?= $title ?></title>
</head>

<body>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2">
                <div>
                    <img src="/homes/jadwal/logo-ibrahimy.png" style="width:100px;" class="img-fluid" alt="Responsive image">
                </div>
            </div>
            <div class="col-md-10">
                <div>
                    <h6 class="text-center">PANITIA PENERIMAAN MAHASISWA BARU</h6>
                    <h5 class="text-center">INSTITUT AGAMA ISLAM IBRAHIMY</h5>
                    <h6 class="text-center"> GENTENG - BANYUWANGI</h6>
                    <P class="text-center">Alamat: Jl. KH. Hasyim Asy'ari No. 1 Genteng Banyuwangi. Telp: (0333)845654 Email:admin@iaiibrahimy.ac.id</P>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="row justify-content-center">
        <div class="mb-4 text-center">
            <h6> KARTU REKOMENDASI PENDAFTARAN MAHASISWA BARU <?= $mahasiswa['nama_status_pendaftaran'] ?></h6>
        </div>
        <div class="col-md-11 ml-3 mb-4">
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <td>NOMOR PENDAFTARAN : <strong><?= $mahasiswa['nomor_pendaftaran'] ?></strong></td>
                        <td>GELOMBANG : <strong> <?php if ($mahasiswa['id_pilihan_1'] == 8) {
                                                    ?>
                                    GELOMBANG 1

                                <?php } else { ?>
                                    <?= $mahasiswa['gelombang']; ?>
                                <?php } ?> </strong></td></strong></td>
                    </tr>
                    <tr>
                        <td>NAMA CALON MAHASISWA : <strong><?= $mahasiswa['nama_mahasiswa'] ?></strong></td>
                        <td>TANGGAL LAHIR : <strong><?= $mahasiswa['tanggal_lahir'] ?>-<?= $mahasiswa['bulan_lahir'] ?>-<?= $mahasiswa['tahun_lahir'] ?></strong></td>
                    </tr>
                    <tr>
                        <td>JALUR PENDAFTARAN : <strong><?= $mahasiswa['jalur_pendaftaran'] ?></strong></td>
                        <td>STATUS PENDAFTARAN : <strong><?= $mahasiswa['nama_status_pendaftaran'] ?></strong></td>
                    </tr>
                    <tr>
                        <td <?php if ($mahasiswa['id_pilihan_1'] == 8) {
                            ?> colspan="2" <?php } else { ?> <?php } ?>> PILIHAN JURUSAN KE-1 : <strong><?= $mahasiswa['nama_jurusan']; ?></strong></td>
                        <?php if ($mahasiswa['id_pilihan_1'] == 8) {
                        ?>


                        <?php } else { ?>
                            <td> PILIHAN JURUSAN KE-2 : <strong><?= $mahasiswa['nama_jurusan_2']; ?></strong></td>
                        <?php } ?>
                    </tr>
                    <tr>
                        <td colspan="2" class="text-center">DATA PEREKOMENDASI</strong></td>
                    </tr>
                    <tr>
                        <td>NAMA PEREKOMENDASI : <strong><?= $mahasiswa['nama_rekomendasi'] ?></strong></td>
                        <td>NOMOR HP PEREKOMENDASI : <strong><?= $mahasiswa['nomor_rekomendasi'] ?></strong></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="text-center">KODE REDEEM PEREKOMENDASI : <strong> <?= $mahasiswa['code_recom'] ?></strong></td>
                    </tr>
                </tbody>
            </table>
        </div>



 <?php if ($$mahasiswa['id_gelombang'] == 1) {
            ?>
                <div class="col-md-12 text-center mt-3">BANYUWANGI, <?= $mahasiswa['tanggal_daftar']; ?></div><br>
                <div class="col-md-12 text-center mt-3">KETUA PANITIA PMB IAI IBRAHIMY GENTENG BANYUWANGI</div><br>
                <div class="col-md-2">
                    <img src="/homes/jadwal/<?= $kartu['ttd']; ?>" style="width:100%;" class="img-fluid" alt="Responsive image">
                </div>
                <div class="col-md-12 text-center"><strong><u> <?= $kartu['nama_ketua']; ?></u></strong></div>

            <?php } else { ?>
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="row justify-content-center">
                            <div class="col-md-12 text-center mt-3">BANYUWANGI, <?= $mahasiswa['tanggal_daftar']; ?></div><br>
                            <div class="col-md-12 text-center mt-3">KETUA PANITIA PMB IAI IBRAHIMY GENTENG BANYUWANGI</div><br>
                            <div class="col-md-6">
                                <img src="/homes/jadwal/<?= $kartu['ttd']; ?>" style="width:100%;" class="img-fluid" alt="Responsive image">
                            </div>
                            <div class="col-md-12 text-center"><strong><u> <?= $kartu['nama_ketua']; ?></u></strong></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row justify-content-center">
                            <br>
                            <br>
                            <br>
                            <div class="col-md-12 text-center mt-3">TTD PEREKOMENDASI</div><br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <div class="col-md-12 text-center"><strong><u> <?= $mahasiswa['nama_rekomendasi'] ?></u></strong></div>
                        </div>
                    </div>
                </div>
                    <br>
                    <br>
                    <br>
            <?php } ?>
                    <br>
                    <br>
                    <br>
                <?php if (empty($mahasiswa['code_recom'])) {
                                ?>
                                    
                                <?php } else { ?>
                                    <p style="font-size: 1.5rem;" class="text-danger" >HARAP TUKARKAN KARTU REKOMENDASI INI KEPADA KETUA PANITIA PMB IAI IBRAHIMY</strong></p> 
                                <?php } ?>
    </div>


    <!-- Optional JavaScript -->
    <script type="text/javascript">
        window.print();
    </script>
    <script>
        setTimeout(function() {
            window.close(1);
        }, 15000);
    </script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>