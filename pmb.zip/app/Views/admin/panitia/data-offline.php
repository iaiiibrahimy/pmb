<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<section class="content">
    <div class="container-fluid">
        <div class="card card-danger">
            <div class="card-header">
                <h3 class="card-title">TAMBAH PENDAFTAR OFFLINE</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <!-- Date dd/mm/yyyy -->
                <form action="/panitia/tambahoffline" method="post">
                    <?= csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="gelombang">Gelombang</label>
                                <select class="form-control <?= ($validation->hasError('gelombang')) ? 'is-invalid' : ''; ?>" id="gelombang" name="gelombang">
                                    <option value="">Pilih Gelombang</option>
                                    <option value="Gelombang 1">Gelombang 1</option>
                                    <option value="Gelombang 2">Gelombang 2</option>
                                    <option value="Gelombang 3">Gelombang 3</option>
                                </select>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('gelombang'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama">Nama Lengkap</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nama')) ? 'is-invalid' : ''; ?>" id="nama" name="nama" placeholder="Tulis Nama Lengkap" value="<?= old('nama') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nama'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="tempat_lahir">Tempat Lahir</label>
                                <input type="text" class="form-control <?= ($validation->hasError('tempat_lahir')) ? 'is-invalid' : ''; ?>" id="tempat_lahir" name="tempat_lahir" placeholder="Kab/Kota Tempat Lahir" value="<?= old('tempat_lahir') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('tempat_lahir'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama_kecamatan">Nama Kecamatan</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nama_kecamatan')) ? 'is-invalid' : ''; ?>" id="nama_kecamatan" name="nama_kecamatan" placeholder="Tulis Nama Kecamatan" value="<?= old('nama_kecamatan') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nama_kecamatan'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nisn">NISN</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nisn')) ? 'is-invalid' : ''; ?>" id="nisn" name="nisn" placeholder="Tulis NISN" value="<?= old('nisn') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nisn'); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="rt">RT</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('rt')) ? 'is-invalid' : ''; ?>" id="rt" name="rt" placeholder="Tulis RT" value="<?= old('rt') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('rt'); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="rw">RW</label>
                                        <input type="text" class="form-control <?= ($validation->hasError('rw')) ? 'is-invalid' : ''; ?>" id="rw" name="rw" placeholder="Tulis RW" value="<?= old('rw') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                        <div class="invalid-feedback">
                                            <?= $validation->getError('rw'); ?>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="form-group">
                                <label for="email">E-Mail</label>
                                <input type="text" class="form-control <?= ($validation->hasError('email')) ? 'is-invalid' : ''; ?>" id="email" name="email" placeholder="Tulis E-mail" value="<?= old('email') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('email'); ?>
                                </div>
                            </div>

                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="nomor_test">Nomor Tes</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nomor_test')) ? 'is-invalid' : ''; ?>" id="nomor_test" name="nomor_test" placeholder="Tulis Nomor Tes" value="<?= old('nomor_test') ?>">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nomor_test'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="jenis_kelamin">Jenis Kelamin</label>
                                <select name="jenis_kelamin" class="form-control <?= ($validation->hasError('jenis_kelamin')) ? 'is-invalid' : ''; ?>" id="">
                                    <option value="" selected>Pilih Jenis Kelamin Anda</option>
                                    <?php
                                    foreach ($jenis_kelamin as $jeniskel) {
                                        echo "<option value=" . $jeniskel->id_jenis_kelamin . ">" . $jeniskel->jenis_kelamin . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('jenis_kelamin'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="agama">Agama</label>
                                <select name="agama" class="form-control <?= ($validation->hasError('agama')) ? 'is-invalid' : ''; ?>" id="">
                                    <option value="" selected>Pilih Agama Anda</option>
                                    <?php
                                    foreach ($agama as $agam) {
                                        echo "<option value=" . $agam->id_agama . ">" . $agam->agama . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('agama'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama_ibu">Nama Ibu</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nama_ibu')) ? 'is-invalid' : ''; ?>" id="nama_ibu" name="nama_ibu" placeholder="Tulis Nama Ibu" value="<?= old('nama_ibu') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nama_ibu'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nik">NIK</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nik')) ? 'is-invalid' : ''; ?>" id="nik" name="nik" placeholder="Tulis NIK" value="<?= old('nik') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nik'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="dusun">Nama Dusun</label>
                                <input type="text" class="form-control <?= ($validation->hasError('dusun')) ? 'is-invalid' : ''; ?>" id="dusun" name="dusun" placeholder="Tulis Nama Dusun" value="<?= old('dusun') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('dusun'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama_ayah">Nama Ayah</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nama_ayah')) ? 'is-invalid' : ''; ?>" id="nama_ayah" name="nama_ayah" placeholder="Tulis Nama Ayah" value="<?= old('nama_ayah') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nama_ayah'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div>
                                <div class="form-group">
                                    <label for="program_studi">Pilih Program Studi</label>
                                    <select name="program_studi" class="form-control <?= ($validation->hasError('program_studi')) ? 'is-invalid' : ''; ?>" id="">
                                        <option value="" selected>Pilih Program Studi</option>
                                        <?php
                                        foreach ($jurusan as $jurusa) {
                                            echo "<option value=" . $jurusa->id_jurusan . ">" . $jurusa->nama_jurusan . "</option>";
                                        }
                                        ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        <?= $validation->getError('program_studi'); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="ttl">Tanggal Lahir</label>
                                <input type="text" class="form-control <?= ($validation->hasError('ttl')) ? 'is-invalid' : ''; ?>" id="ttl" name="ttl" placeholder="Tanggal-Bulan-Tahun" value="<?= old('ttl') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('ttl'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama_kelurahan">Nama Kelurahan</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nama_kelurahan')) ? 'is-invalid' : ''; ?>" id="nama_kelurahan" name="nama_kelurahan" placeholder="Nama Desa/Kelurahan" value="<?= old('nama_kelurahan') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nama_kelurahan'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="kewarganegaraan">Kewarganegaraan</label>
                                <select name="kewarganegaraan" class="form-control <?= ($validation->hasError('kewarganegaraan')) ? 'is-invalid' : ''; ?>" id="">
                                    <option value="" selected>Pilih Negara Anda</option>
                                    <?php
                                    foreach ($negara as $negar) {
                                        echo "<option value=" . $negar->id_wn . ">" . $negar->nama_negara . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('kewarganegaraan'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama_jalan">Nama Jalan</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nama_jalan')) ? 'is-invalid' : ''; ?>" id="nama_jalan" name="nama_jalan" placeholder="Tulis Nama Jalan" value="<?= old('nama_jalan') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nama_jalan'); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="hp">Nomor HP</label>
                                <input type="text" class="form-control <?= ($validation->hasError('hp')) ? 'is-invalid' : ''; ?>" id="hp" name="hp" placeholder="Tulis Nomor HP" value="<?= old('hp') ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('hp'); ?>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- /.form group -->

                    <div class="d-flex justify-content-center">
                        <button type="submit" class="btn btn-primary">Tambah Mahasiswa</button>
                    </div>
                </form>

            </div>
            <!-- /.card-body -->
        </div>
    </div>
</section>
<?= $this->endSection(); ?>