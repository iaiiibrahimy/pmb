<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Export Data Mahasiswa Bentuk SIAKAD</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Gelombang</th>
                    <th>Status Awal</th>
                    <th>Nomor Pendaftaran</th>
                    <th>Jalur Pendaftaran</th>
                    <th>NIM</th>
                    <th>NIRM</th>
                    <th>NISN</th>
                    <th>NIRL</th>
                    <th>NIK</th>
                    <th>NAMA</th>
                    <th>Fakultas</th>
                    <th>Program Studi</th>
                    <th>Dosen Wali</th>
                    <th>Status</th>
                    <th>Tempat Lahir</th>
                    <th>Tanggal Lahir</th>
                    <th>Jenis Kelamin</th>
                    <th>Agama</th>
                    <th>Alamat</th>
                    <th>No Hp</th>
                    <th>Kota</th>
                    <th>Kewarganegaraan</th>
                    <th>Status Kawin</th>
                    <th>Ayah</th>
                    <th>Pendidikan Ayah</th>
                    <th>Pekerjaan Ayah</th>
                    <th>Ibu</th>
                    <th>Alamat Orang Tua</th>
                    <th>Nama Wali</th>
                    <th>Pekerjaan</th>
                    <th>Sumber Biaya</th>
                    <th>Bea siswa</th>
                    <th>Status Awal</th>
                    <th>Angkatan</th>
                    <th>Tanggal Aktif</th>
                    <th>Dispensasi</th>
                    <th>Kelas</th>
                    <th>Asal Sekolah</th>
                    <th>Perekomendasi</th>
                    <th>No. Perekomendasi</th>
                    <th>Status Fee</th>


                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($gelombang as $gelo) : ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td>Gelombang <?= $gelo['id_gelombang']; ?></td>
                        <td><?= $gelo['nama_pendaftaran'] ?></td>
                        <td><?= $gelo['nomor_pendaftaran'] ?></td>
                        <td><?= $gelo['jalur_pendaftaran'] ?></td>
                        <td></td>
                        <td></td>
                        <td><?= $gelo['nisn'] ?></td>
                        <td></td>
                        <td>`<?= $gelo['nik'] ?></td>
                        <td><?= $gelo['nama_mahasiswa'] ?></td>
                        <td></td>
                        <td><?= $gelo['nama_jurusan'] ?></td>
                        <td></td>
                        <td></td>
                        <td><?= $gelo['tempat_lahir'] ?></td>
                        <td><?= $gelo['tanggal_lahir'] ?>/<?= $gelo['bulan_lahir'] ?>/<?= $gelo['tahun_lahir'] ?></td>
                        <td><?= $gelo['jenis_kelamin'] ?></td>
                        <td><?= $gelo['agama'] ?></td>
                        <td>DUSUN <?= $gelo['dusun'] ?>, RT: <?= $gelo['rt'] ?>/RW: <?= $gelo['rw'] ?>, DESA <?= $gelo['kelurahan'] ?>, KECAMATAN <?= $gelo['kecamatan'] ?>, KABUPATEN <?= $gelo['kabupaten'] ?></td>
                        <td><?= $gelo['no_hp'] ?></td>
                        <td><?= $gelo['kabupaten'] ?></td>
                        <td><?= $gelo['nama_negara'] ?></td>
                        <td><?= $gelo['nama_status'] ?></td>
                        <td><?= $gelo['nama_ayah'] ?></td>
                        <td><?= $gelo['pendidikan'] ?></td>
                        <td><?= $gelo['pekerjaan'] ?></td>
                        <td><?= $gelo['nama_ibu'] ?></td>
                        <td><?= $gelo['alamat_wali'] ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><?= $gelo['asal_sekolah'] ?></td>
                        <td><?= $gelo['nama_rekomendasi'] ?></td>
                        <td><?= $gelo['nomor_rekomendasi'] ?></td>
                        <td><?php if (empty($gelo['nama_rekomendasi'])) {
                                ?>
                                    
                                <?php } else { ?>
                                
                                <?php if ($gelo['reward'] == 2) {
                                ?>
                                
                                SUDAH DITERIMA
                                    
                                <?php } else { ?>
                                
                                BELUM DITERIMA
                                <?php } ?>
                                
                                <?php } ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>