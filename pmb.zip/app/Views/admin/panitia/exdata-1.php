<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Export Data Mahasiswa Bentuk PD DIKTI</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Status Awal</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Tanggal lahir</th>
                    <th>Tempat Lahir</th>
                    <th>Agama</th>
                    <th>Nama Kelurahan</th>
                    <th>Nama Kecamatan</th>
                    <th>Nama Ibu Kandung</th>
                    <th>Kebutuhan Khusus</th>
                    <th>Terima KPS</th>
                    <th>Status Pendidikan</th>
                    <th>Kebutuhan Khusus Ayah</th>
                    <th>Kebutuhan Khusus Ibu</th>
                    <th>Kewarganegaraan</th>
                    <th>Nomor KPS</th>
                    <th>NISN</th>
                    <th>NIK</th>
                    <th>Nama Jalan</th>
                    <th>Nomor RT</th>
                    <th>Nomor RW</th>
                    <th>Nama Dusun</th>
                    <th>Kode Pos</th>
                    <th>Jenis Tinggal</th>
                    <th>Alat Transportasi</th>
                    <th>Telephone Rumah</th>
                    <th>Telephone Seluler</th>
                    <th>E-mail</th>
                    <th>Nama Ayah</th>
                    <th>Tanggal Lahir Ayah</th>
                    <th>Jenjang Pendidikan Ayah</th>
                    <th>Pekerjaan Ayah</th>
                    <th>Penghasilan Ayah</th>
                    <th>Tanggal Lahir Ibu</th>
                    <th>Jenjang Pendidikan Ibu</th>
                    <th>Pekerjaan Ibu</th>
                    <th>Penghasilan Ibu</th>
                    <th>Nama Wali</th>
                    <th>Tanggal Lahir Wali</th>
                    <th>Jenjang Pendidikan Wali</th>
                    <th>Pekerjaan Wali</th>
                    <th>Penghasilan Wali</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($gelombang as $gelo) : ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td><?= $gelo['nama_pendaftaran'] ?></td>
                        <td><?= $gelo['nama_mahasiswa'] ?></td>
                        <td><?= $gelo['jenis_kelamin'] ?></td>
                        <td><?= $gelo['tanggal_lahir'] ?>-<?= $gelo['bulan_lahir'] ?>-<?= $gelo['tahun_lahir'] ?></td>
                        <td><?= $gelo['tempat_lahir'] ?></td>
                        <td><?= $gelo['agama'] ?></td>
                        <td><?= $gelo['kelurahan'] ?></td>
                        <td><?= $gelo['kecamatan'] ?></td>
                        <td><?= $gelo['nama_ibu'] ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><?= $gelo['nama_negara'] ?></td>
                        <td></td>
                        <td><?= $gelo['nisn'] ?></td>
                        <td>`<?= $gelo['nik'] ?></td>
                        <td><?= $gelo['nama_jalan'] ?></td>
                        <td><?= $gelo['rt'] ?></td>
                        <td><?= $gelo['rw'] ?></td>
                        <td><?= $gelo['dusun'] ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><?= $gelo['no_hp'] ?></td>
                        <td></td>
                        <td><?= $gelo['nama_ayah'] ?></td>
                        <td></td>
                        <td><?= $gelo['pendidikan'] ?></td>
                        <td><?= $gelo['pekerjaan'] ?></td>
                        <td></td>
                        <td></td>
                        <td><?= $gelo['pendidikan_2'] ?></td>
                        <td><?= $gelo['pekerjaan_2'] ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><?= $gelo['penghasilan'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>