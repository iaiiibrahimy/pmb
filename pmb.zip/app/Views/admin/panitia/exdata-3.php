<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Export Data Mahasiswa Gelombang 3</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Validasi</th>
                    <th>Nomor Pendaftaran</th>
                    <th>Jalur Pendaftaran</th>
                    <th>Nama Mahasiswa</th>
                    <th>Jenis Kelamin</th>
                    <th>Jenis Pendaftaran</th>
                    <th>NIK</th>
                    <th>Tempat Lahir</th>
                    <th>Tanggal Lahir</th>
                    <th>Umur</th>
                    <th>Agama</th>
                    <th>Kewarganegaraan</th>
                    <th>Status Perkawinan</th>
                    <th>Alamat Lengkap Mahasiswa</th>
                    <th>Nomor HP Mahasiswa</th>
                    <th>Asal Sekolah/ Tahun Lulus</th>
                    <th>Jurusan Sekolah</th>
                    <th>Nama Ayah</th>
                    <th>Pendidikan Ayah</th>
                    <th>Pekerjaan Ayah</th>
                    <th>Nama Ibu</th>
                    <th>Pendidikan Ibu</th>
                    <th>Pekerjaan Ibu</th>
                    <th>Penghasilan Wali</th>
                    <th>Alamat Lengkap Wali</th>
                    <th>Nomor HP Wali</th>
                    <th>Jurusan Ke-1</th>
                    <th>Jurusan Ke-2</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($gelombang as $gelo) : ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td><?= $gelo['nama_validasi']; ?></td>
                        <td><?= $gelo['nomor_pendaftaran']; ?></td>
                        <td><?= $gelo['jalur_pendaftaran']; ?></td>
                        <td><?= $gelo['nama_mahasiswa']; ?></td>
                        <td><?= $gelo['jenis_kelamin']; ?></td>
                        <td><?= $gelo['nama_pendaftaran']; ?></td>
                        <td><?= $gelo['nik']; ?></td>
                        <td><?= $gelo['tempat_lahir']; ?></td>
                        <td><?= $gelo['tanggal_lahir']; ?>-<?= $gelo['bulan_lahir']; ?>-<?= $gelo['tahun_lahir']; ?></td>
                        <td><?= $gelo['umur']; ?></td>
                        <td><?= $gelo['agama']; ?></td>
                        <td><?= $gelo['nama_negara']; ?></td>
                        <td><?= $gelo['status']; ?></td>
                        <td><?= $gelo['alamat_mahasiswa']; ?></td>
                        <td><?= $gelo['nomor_hp']; ?></td>
                        <td><?= $gelo['asal_sekolah']; ?>/<?= $gelo['tahun_lulus']; ?></td>
                        <td><?= $gelo['jurusan_sekolah']; ?></td>
                        <td><?= $gelo['nama_ayah']; ?></td>
                        <td><?= $gelo['id_pendidikan_ayah']; ?></td>
                        <td><?= $gelo['id_pekerjaan_ayah']; ?></td>
                        <td><?= $gelo['nama_ibu']; ?></td>
                        <td><?= $gelo['id_pendidikan_ibu']; ?></td>
                        <td><?= $gelo['id_pekerjaan_ibu']; ?></td>
                        <td><?= $gelo['penghasilan']; ?></td>
                        <td><?= $gelo['alamat_wali']; ?></td>
                        <td><?= $gelo['nomor_hp_wali']; ?></td>
                        <td><?= $gelo['nama_jurusan']; ?></td>
                        <td><?= $gelo['nama_jurusan_2']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>