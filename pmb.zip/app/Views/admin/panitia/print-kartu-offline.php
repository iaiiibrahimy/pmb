<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Cetak Kartu Peserta Ujian</title>
</head>

<body>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-2">
                <div>
                    <img src="/homes/jadwal/logo-ibrahimy.png" style="width:100px;" class="img-fluid" alt="Responsive image">
                </div>
            </div>
            <div class="col-md-10">
                <div>
                    <h6 class="text-center">PANITIA PENERIMAAN MAHASISWA BARU</h6>
                    <h5 class="text-center">INSTITUT AGAMA ISLAM IBRAHIMY</h5>
                    <h6 class="text-center"> GENTENG - BANYUWANGI</h6>
                    <P class="text-center">Alamat: Jl. KH. Hasyim Asy'ari No. 1 Genteng Banyuwangi. Telp: (0333)845654 Email:admin@iaiibrahimy.ac.id</P>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="mb-4 text-center">
        <h6> Kartu Peserta Ujian Jalur Online</h6>
    </div>





    <!-- Optional JavaScript -->
    <script type="text/javascript">
        window.print();
    </script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>