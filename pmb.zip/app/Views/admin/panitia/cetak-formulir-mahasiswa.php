<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title><?= $title ?></title>
</head>

<body>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2">
                <div>
                    <img src="/homes/jadwal/logo-ibrahimy.png" style="width:100px;" class="img-fluid" alt="Responsive image">
                </div>
            </div>
            <div class="col-md-10">
                <div>
                    <h6 class="text-center">PANITIA PENERIMAAN MAHASISWA BARU</h6>
                    <h5 class="text-center">INSTITUT AGAMA ISLAM IBRAHIMY</h5>
                    <h6 class="text-center"> GENTENG - BANYUWANGI</h6>
                    <P class="text-center">Alamat: Jl. KH. Hasyim Asy'ari No. 1 Genteng Banyuwangi. Telp: (0333)845654 Email:admin@iaiibrahimy.ac.id</P>
                </div>
            </div>
        </div>
    </div>
    <hr>

    <div class="row justify-content-center">
        <div class="mb-1 text-center">
            <h6> FORMULIR PENDAFTARAN MAHASISWA BARU TAHUN AKADEMIK <?= $tahun_akademiks['nama_tahun_akademik']; ?>
                <br>
                INSTITUT AGAMA ISLAM IBRAHIMY GENTENG BANYUWANGI <br>
            </h6>
        </div>
        <br>
        <div class="col-md-11">
            <div class="row justify-content-center">
                <table class="table table-borderless">
                    <tbody>
                        <tr>
                            <td colspan="4" class="bg-secondary text-white"><strong> IDENTITAS CALON MAHASISWA</strong></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">NOMOR PENDAFTARAN</td>
                            <td>: <?= $mahasiswa['nomor_pendaftaran'] ?></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">NAMA LENGKAP MAHASISWA</td>
                            <td>: <?= $mahasiswa['nama_mahasiswa'] ?></td>
                            <td style="width: 150px;">NIK</td>
                            <td>: <?= $mahasiswa['nik'] ?></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">JENIS KELAMIN</td>
                            <td>: <?= $mahasiswa['jenis_kelamin'] ?></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">TEMPAT, TANGGAL LAHIR</td>
                            <td>: <?= $mahasiswa['tempat_lahir'] ?>, <?= $mahasiswa['tanggal_lahir'] ?> - <?= $mahasiswa['bulan_lahir'] ?> - <?= $mahasiswa['tahun_lahir'] ?></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">AGAMA</td>
                            <td>: <?= $mahasiswa['agama'] ?></td>
                            <td style="width: 150px;">NOMOR HP</td>
                            <td>: <?= $mahasiswa['no_hp'] ?></td>
                        </tr>
                        <tr>
                            <td>STATUS PERKAWINAN</td>
                            <td>: <?= $mahasiswa['nama_status'] ?></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">ALAMAT LENGKAP MAHASISWA</td>
                            <td colspan="3">: <?php if (empty($mahasiswa['nama_jalan'])) {
                                                ?>

                                <?php } else { ?>
                                    JALAN <?= $mahasiswa['nama_jalan'] ?>,
                                <?php } ?> <?php if (empty($mahasiswa['dusun'])) {
                                            ?>

                                <?php } else { ?>
                                    DUSUN <?= $mahasiswa['dusun'] ?>,
                                <?php } ?> RT: <?= $mahasiswa['rt'] ?>/RW: <?= $mahasiswa['rw'] ?>, DESA/KELURAHAN <?= $mahasiswa['kelurahan'] ?>, KECAMATAN <?= $mahasiswa['kecamatan'] ?>, KABUPATEN <?= $mahasiswa['kabupaten'] ?></td>
                        </tr>

                        <tr>
                            <td style="width: 250px;">ASAL SEKOLAH</td>
                            <td>: <?= $mahasiswa['asal_sekolah'] ?></td>
                            <td style="width: 150px;">NISN</td>
                            <td>: <?= $mahasiswa['nisn'] ?></td>
                        </tr>

                        <tr>
                            <td colspan="4" class="bg-secondary text-white"><strong> PILIHAN PROGRAM STUDI</strong></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">PILIHAN PERTAMA</td>
                            <td>: <?= $mahasiswa['nama_jurusan'] ?></td>
                            <td style="width: 150px;">PILIHAN KE-DUA</td>
                            <td>: <?= $mahasiswa['nama_jurusan_2'] ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="bg-secondary text-white"><strong> DATA ORANG TUA WALI CALON MAHASISWA</strong></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">NAMA AYAH</td>
                            <td>: <?= $mahasiswa['nama_ayah'] ?></td>
                            <td style="width: 150px;">PEKERJAAN AYAH</td>
                            <td>: <?= $mahasiswa['pekerjaan'] ?></td>
                        </tr>
                        <tr>
                            <td>PENDIDIKAN TERAKHIR AYAH</td>
                            <td>: <?= $mahasiswa['pendidikan'] ?></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">NAMA IBU</td>
                            <td>: <?= $mahasiswa['nama_ibu'] ?></td>
                            <td style="width: 150px;">PEKERJAAN IBU</td>
                            <td>: <?= $mahasiswa['pekerjaan_2'] ?></td>
                        </tr>
                        <tr>
                            <td>PENDIDIKAN TERAKHIR IBU</td>
                            <td>: <?= $mahasiswa['pendidikan_2'] ?></td>
                        </tr>
                        <tr>
                            <td style="width: 250px;">ALAMAT LENGKAP ORANG TUA CALON MAHASISWA</td>
                            <td colspan="3">: <?= $mahasiswa['alamat_wali'] ?></td>
                        </tr>
                        <tr>
                            <td>PENGHASILAN ORANG TUA</td>
                            <td>: <?= $mahasiswa['penghasilan'] ?></td>
                        </tr>
                        <?php if (empty($mahasiswa['nama_rekomendasi'])) {
                        ?>

                        <?php } else { ?>
                            <tr>
                                <td style="width: 250px;">NAMA PEREKOMENDASI</td>
                                <td>: <?= $mahasiswa['nama_rekomendasi'] ?></td>
                            </tr>
                        <?php } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-6"></div>
        <div class="col-md-6">
            <div class="col-md-12 text-center mt-3">BANYUWANGI, <?= $mahasiswa['tanggal_daftar']; ?></div>
            <div class="col-md-12 text-center mt-3">CALON MAHASISWA</div><br>
            <br><br><br><br>
            <div class="col-md-12 text-center"><strong><u> <?= $mahasiswa['nama_mahasiswa']; ?></u></strong></div>
        </div>
    </div>

<!-- Optional JavaScript -->
    <script type="text/javascript">
        window.print();
    </script>
    <script>
        setTimeout(function() {
            window.close(1);
        }, 15000);
    </script>
    <!-- Optional JavaScript -->

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>

</body>

</html>