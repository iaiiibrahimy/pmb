<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Form Edit Jurusan Calon Mahasiswa Tahun Akademik <?= $tahun_akademiks['nama_tahun_akademik'] ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-4">
                        <h3 class="card-title" style="color: #8B008B;"><strong>Nomor Magister PAI: <?php if (empty($nomor_magisterpai)) {
                                                                                                    ?>
                                    Nomor Masih Kosong
                                <?php } else { ?>
                                    <?php $jmpai = 1;
                                                                                                        foreach ($nomor_magisterpai as $nompai) : ?>
                                        <?= $jmpai += $nompai['nomor_pendaftaran']; ?>
                                    <?php endforeach; ?>
                                <?php } ?></strong></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="card">
            <div class="card-header">
                <form action="/panitia/editjrsmhssmgs/<?= $mahasiswa['id_mahasiswa'] ?>" method="POST" id="formtambahmahasiswa" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-12">
                            <h5 class="text-danger text-left"> Form yang bertanda * (bintang) wajib diisi</h5>
                        </div>
                        <div class="col-md-12 p-3 mb-2 bg-secondary text-white"><strong>Jurusan Calon Mahasiswa</strong></div>
                        <input type="hidden" name="id_mahasiswa" id="id_mahasiswa" value="<?= $mahasiswa['id_mahasiswa'] ?>">

                        <div class="col-md-6">
                            <div class="form-group mb-2">
                                <label for="nomor_pendaftaran">Nomor Pendaftaran*</label>
                                <input type="text" class="form-control" id="nomor_pendaftaran" name="nomor_pendaftaran" value="<?= $mahasiswa['nomor_pendaftaran'] ?>" onkeyup="this.value=this.value.toUpperCase()">
                                <div class="invalid-feedback errorNomorP">
                                </div>
                                <div class="valid-feedback validNomorP">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-2">
                                <label for="nama_mahasiswa">Nama Lengkap Mahasiswa (tidak bisa diubah)</label>
                                <input type="text" class="form-control" id="nama_mahasiswa" name="nama_mahasiswa" value="<?= $mahasiswa['nama_mahasiswa'] ?>" onkeyup="this.value=this.value.toUpperCase()" readonly>
                                <div class="invalid-feedback errorNamaMahasiswa">
                                </div>
                                <div class="valid-feedback validNamaMahasiswa">
                                </div>
                            </div>
                        </div>


                        <div class="col-md-6">
                            <label for="jurusan_1">Pilih Jurusan Pertama*</label>
                            <select name="jurusan_1" class="form-control" id="jurusan_1">
                                <?php foreach ($jurusan as $jurusann) : ?>
                                    <?php if ($jurusann['id_jurusan'] == $mahasiswa['id_pilihan_1']) : ?>
                                        <option value="<?= $jurusann['id_jurusan']; ?>" selected> <?= $jurusann['nama_jurusan']; ?></option>
                                    <?php else : ?>
                                        <option value="<?= $jurusann['id_jurusan']; ?>"> <?= $jurusann['nama_jurusan']; ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback errorJurusan1">
                            </div>
                            <div class="valid-feedback validJurusan1">
                            </div>
                        </div>

                        <hr style="color: black;" class="col-md-12">
                        <div class="col-md-12">
                            <div class="modal-footer d-flex justify-content-center">
                                <span class="input-group-append ">
                                    <button type="submit" class="btn btn-warning simpanMahasiswaEdit">Simpan Data</button>
                                </span>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#formtambahmahasiswa').submit(function(e) {
                e.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: "post",
                    url: $(this).attr('action'),
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    beforeSend: function() {
                        $('.simpanMahasiswaEdit').attr('disable', 'disabled');
                        $('.simpanMahasiswaEdit').html('<i class="fa fa-spin fa-spinner"></i>');
                    },
                    complete: function() {
                        $('.simpanMahasiswaEdit').removeAttr('disable');
                        $('.simpanMahasiswaEdit').html('Coba Simpan Data Lagi');
                    },
                    success: function(response) {
                        if (response.error) {
                            if (response.error.id_mahasiswa) {
                                $('#id_mahasiswa').addClass('is-invalid');
                                $('.errorIdMhs').html(response.error.id_mahasiswa);
                            } else {
                                $('#id_mahasiswa').removeClass('is-invalid');
                                $('#id_mahasiswa').addClass('is-valid');
                                $('.validIdMhs').html('Benar!!');
                            };
                            if (response.error.nomor_pendaftaran) {
                                $('#nomor_pendaftaran').addClass('is-invalid');
                                $('.errorNomorP').html(response.error.nomor_pendaftaran);
                            } else {
                                $('#nomor_pendaftaran').removeClass('is-invalid');
                                $('#nomor_pendaftaran').addClass('is-valid');
                                $('.validNomorP').html('Benar!!');
                            };
                            if (response.error.jurusan_1) {
                                $('#jurusan_1').addClass('is-invalid');
                                $('.errorJurusan1').html(response.error.jurusan_1);
                            } else {
                                $('#jurusan_1').removeClass('is-invalid');
                                $('#jurusan_1').addClass('is-valid');
                                $('.validJurusan1').html('Benar!!');
                            };
                            if (response.error.jurusan_2) {
                                $('#jurusan_2').addClass('is-invalid');
                                $('.errorJurusan2').html(response.error.jurusan_2);
                            } else {
                                $('#jurusan_2').removeClass('is-invalid');
                                $('#jurusan_2').addClass('is-valid');
                                $('.validJurusan2').html('Benar!!');
                            };

                            Swal.fire({
                                icon: 'error',
                                title: 'Oops... Update jurusan gagal',
                                text: 'Yuk, Cek kembali isian anda',
                            })

                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: response.sukses,
                            })

                            setTimeout(function() {
                                window.location.replace("/data-gelombang-1");
                            }, 1500);
                        }
                    },
                    error: function(xhr, ajaxOption, thrownError) {
                        alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
                    }
                });
                return false
            });
        });
    </script>
    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>