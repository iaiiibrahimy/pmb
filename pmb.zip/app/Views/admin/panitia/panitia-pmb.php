<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<form action="" method="POST">
    <div class="input-group mb-3">
        <input type="hidden" class="form-control" name="keyword" placeholder="Tulis Nama mahasiswa" value="<?= $tahun_akademiks['id_tahun_akademiks']; ?>" onchange="this.form.submit();">
    </div>
</form>
<!-- Main row -->
<div class="row">
    <!-- Left col -->
    <div class="col-md-8">
        <!-- MAP & BOX PANE -->
        <div class="row">
            <div class="col-12 col-sm-6 col-md-6">
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-success elevation-1"><i class="fas fa-user-graduate"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Pendidikan Agama Islam</span>
                        <span class="info-box-number"><small>Piihan Ke-1: </small> <?= $pai1; ?>
                            <small>Orang</small>
                        </span>
                        <span class="info-box-number"><small>Pilihan Ke-2: </small> <?= $pai2; ?>
                            <small>Orang</small>
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>

                <div class="info-box mb-3">
                    <span class="info-box-icon bg-success elevation-1"><i class="fas fa-user-graduate"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Pendidikan Guru Madrasah Ibtidaiyah</span>
                        <span class="info-box-number"><small>Pilihan Ke-1: </small> <?= $pgmi1; ?>
                            <small>Orang</small>
                        </span>
                        <span class="info-box-number"><small>Pilihan Ke-2: </small> <?= $pgmi2; ?>
                            <small>Orang</small>
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>

                <div class="info-box mb-3">
                    <span class="info-box-icon bg-success elevation-1"><i class="fas fa-user-graduate"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Pendidikan Islam Anak Usia Dini</span>
                        <span class="info-box-number"><small>Pilihan Ke-1: </small> <?= $piaud1; ?>
                            <small>Orang</small>
                        </span>
                        <span class="info-box-number"><small>Pilihan Ke-2: </small> <?= $piaud2; ?>
                            <small>Orang</small>
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-success elevation-1"><i class="fas fa-user-graduate"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Tadris Matematika</span>
                        <span class="info-box-number"><small>Pilihan Ke-1: </small> <?= $mat1; ?>
                            <small>Orang</small>
                        </span>
                        <span class="info-box-number"><small>Pilihan Ke-2: </small> <?= $mat2; ?>
                            <small>Orang</small>
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                
                
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-info elevation-1"><i class="fas fa-user-graduate"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Pengembangan Masyarakat Islam</span>
                        <span class="info-box-number"><small>Pilihan Ke-1: </small> <?= $pmi1; ?>
                            <small>Orang</small>
                        </span>
                        <span class="info-box-number"><small>Pilihan Ke-2: </small> <?= $pmi2; ?>
                            <small>Orang</small>
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
            <div class="col-12 col-sm-6 col-md-6">
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-user-graduate"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Ekonomi Syariah</span>
                        <span class="info-box-number"><small>Pilihan Ke-1: </small> <?= $ekos1; ?>
                            <small>Orang</small>
                        </span>
                        <span class="info-box-number"><small>Pilihan Ke-2: </small> <?= $ekos2; ?>
                            <small>Orang</small>
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>

                <div class="info-box mb-3">
                    <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-user-graduate"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Perbankan Syariah</span>
                        <span class="info-box-number"><small>Pilihan Ke-1: </small> <?= $ps1; ?>
                            <small>Orang</small>
                        </span>
                        <span class="info-box-number"><small>Pilihan Ke-2: </small> <?= $ps2; ?>
                            <small>Orang</small>
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>

                <div class="info-box mb-3">
                    <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-user-graduate"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Hukum Keluarga Islam</span>
                        <span class="info-box-number"><small>Pilihan Ke-1: </small> <?= $hki1; ?>
                            <small>Orang</small>
                        </span>
                        <span class="info-box-number"><small>Pilihan Ke-2: </small> <?= $hki2; ?>
                            <small>Orang</small>
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                
                
                <div class="info-box mb-3">
                    <span class="info-box-icon elevation-1" style="background-color: #8B008B; color: white;"><i class="fas fa-user-graduate"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Pascasarjana PAI</span>
                        <span class="info-box-number"><small>Pilihan Ke-1: </small> <?= $pasca; ?>
                            <small>Orang</small>
                        </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
            </div>


        </div>

    </div>

    <div class="col-md-4">
        <!-- Info Boxes Style 2 -->
        <div class="info-box mb-3 bg-warning">
            <span class="info-box-icon"><i class="fas fa-male"></i></span>

            <div class="info-box-content">
                <span class="info-box-text">Laki-Laki</span>
                <span class="info-box-number"><?= $laki; ?> Orang</span>
            </div>
            <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
        <div class="info-box mb-3 bg-success">
            <span class="info-box-icon"><i class="fas fa-female"></i></span>

            <div class="info-box-content">
                <span class="info-box-text">Perempuan</span>
                <span class="info-box-number"><?= $cewek; ?> Orang</span>
            </div>
            <!-- /.info-box-content -->
        </div>
         <div class="info-box mb-3 bg-primary">
            <span class="info-box-icon"><i class="fas fa-users"></i></span>

            <div class="info-box-content">
                <span class="info-box-text">Gelombang 1</span>
                <span class="info-box-number"><?= $gel1; ?> Orang</span>
            </div>
            <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
        <div class="info-box mb-3 bg-secondary">
            <span class="info-box-icon"><i class="fas fa-users"></i></span>

            <div class="info-box-content">
                <span class="info-box-text">Gelombang 2</span>
                <span class="info-box-number"><?= $gel2; ?> Orang</span>
            </div>
            <!-- /.info-box-content -->
        </div>
    </div>

    <script>
        setTimeout(function() {
            window.location.reload(1);
        }, 20000);
    </script>
    <!-- /.card -->
</div>
<?= $this->endSection(); ?>