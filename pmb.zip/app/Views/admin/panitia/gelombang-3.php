<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Calon Mahasiswa Gelombang 3</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Validasi</th>
                    <th>Nomor Pendaftaran</th>
                    <th>Nama Mahasiswa</th>
                    <th>Asal Sekolah/ Tahun Lulus</th>
                    <th>Jurusan Sekolah</th>
                    <th>Alamat Lengkap</th>
                    <th>Hapus</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($gelombang as $gelo) : ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td>
                            <a href="/panitia/edit_mahasiswa/<?= $gelo['id_mahasiswa']; ?>" class="badge badge-warning">Validasi</a>
                        </td>
                        <td><?= $gelo['nomor_pendaftaran']; ?></td>
                        <td><?= $gelo['nama_mahasiswa']; ?></td>
                        <td><?= $gelo['asal_sekolah']; ?>/<?= $gelo['tahun_lulus']; ?></td>
                        <td><?= $gelo['jurusan_sekolah']; ?></td>
                        <td><?= $gelo['alamat_mahasiswa']; ?></td>
                        <td><a href="/panitia/deletemhs/<?= $gelo['id_mahasiswa']; ?>" class="badge badge-danger d-inline">Delete</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>