<?= $this->extend('admin/template/dashboard-panitia'); ?>


<?= $this->section('contentss'); ?>
<!-- Main content -->


<!-- Main row -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Calon Mahasiswa Tahun Akademik <?= $tahun_akademiks['nama_tahun_akademik'] ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="container mb-3">
            <div class="row justify-content-center">
                <div class="col-2">
                    <a href="/panitia/tammhs" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Tambah Calon Mahasiswa S1
                    </a>
                </div>
                <div class="col-2">
                    <a href="/panitia/tammhsmgs" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Tambah Calon Mahasiswa S2
                    </a>
                </div>
                <div class="col-8">
                    <form action="" method="POST">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" name="keyword" placeholder="Tulis Nama Mahasiswa di sini untuk mencari" value="<?= session('panda_4') ?>">
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="submit" name="submit"><i class="fas fa-search"></i>Cari Mahasiswa</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php if (empty($gelombang)) {
        ?>
            <h5 class="text-center">Data Mahasiswa yang anda cari tidak ada atau belum ada data</h5>

        <?php } else { ?>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Bordered Table</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 10px">NO</th>
                                    <th>Gelombang</th>
                                    <th>Status Awal</th>
                                    <th>Status Pendaftaran</th>
                                    <th>Nomor Pendaftaran</th>
                                    <th>Nama Mahasiswa</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Jurusan 1</th>
                                    <th>Jurusan 2</th>
                                    <th>Perekom</th>
                                    <th>No. HP Perekom</th>
                                    <th style="width: 160px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1 + (10 * ($currentPage - 1)); ?>
                                <?php foreach ($gelombang as $gelo) : ?>
                                    <tr>
                                        <td class="text-center"><?= $i++; ?></td>
                                        <td><?= $gelo['gelombang']; ?></td>
                                        <td><?= $gelo['nama_pendaftaran']; ?></td>
                                        <td><?= $gelo['nama_status_pendaftaran']; ?></td>
                                        <td><?= $gelo['nomor_pendaftaran']; ?></td>
                                        <td><?= $gelo['nama_mahasiswa']; ?></td>
                                        <td><?= $gelo['tanggal_lahir']; ?>-<?= $gelo['bulan_lahir']; ?>-<?= $gelo['tahun_lahir']; ?></td>
                                        <td><?= $gelo['nama_jurusan']; ?></td>
                                        <td><?= $gelo['nama_jurusan_2']; ?></td>
                                        <td><?= $gelo['nama_rekomendasi']; ?> <?php if (empty($gelo['nama_rekomendasi'])) {
                                ?>
                                    
                                <?php } else { ?>
                                
                                <?php if ($gelo['reward'] == 0) {
                                                ?>
                                                <form action="/panitia/getreward/<?= $gelo['id_mahasiswa'] ?>" method="POST" id="formgetreward<?= $gelo['id_mahasiswa'] ?>" enctype="multipart/form-data">
                         <input type="hidden" name="id_mahasiswa" id="id_mahasiswa" value="<?= $gelo['id_mahasiswa'] ?>">
                                    <span class="input-group-append ">
                                        <button type="submit" class="btn btn-warning simpanGetReward<?= $gelo['id_mahasiswa'] ?>">Serahkan Reward Dong</button>
                                    </span>
                </form> 
                                            <?php } else { ?>
                                                
                                                <?php if ($gelo['reward'] == 2) {
                                                ?>
                                                
                                                 (SUDAH DITERIMA)
                                                
                                                <?php } ?>
                                                
                                                
                                                
                                            <?php } ?>
                                
                                
                                <?php } ?> </td>
                                        <td><?= $gelo['nomor_rekomendasi']; ?></td>
                                        <td>
                                            <?php if (empty($gelo['nama_rekomendasi'])) {
                                ?>
                                    
                                <?php } else { ?>
                                
                                <?php if ($gelo['reward'] == 2) {
                                ?>
                                    
                                <?php } else { ?>
                                
                                    <a href="/panitia/printkarturekom/<?= $gelo['nomor_pendaftaran']; ?>" target="_blank" class="badge badge-warning d-inline">Print Kartu Rekomendasi</a> | 
                                <?php } ?>
                                
                                <?php } ?> <a href="/panitia/printkartumhs/<?= $gelo['nomor_pendaftaran']; ?>" target="_blank" class="badge badge-success d-inline">Print Kartu</a>
                                            | <?php if ($gelo['id_pilihan_1'] == 8) {
                                                ?>
                                                <a href="/panitia/printformulirmhsmgs/<?= $gelo['nomor_pendaftaran']; ?>" target="_blank" class="badge badge-primary d-inline">Print Formulir</a>

                                            <?php } else { ?>
                                                <a href="/panitia/printformulirmhs/<?= $gelo['nomor_pendaftaran']; ?>" target="_blank" class="badge badge-primary d-inline">Print Formulir</a>
                                            <?php } ?> | <?php if ($gelo['id_pilihan_1'] == 8) {
                                                            ?>
                                                <a href="/panitia/editmhsmgs/<?= $gelo['id_mahasiswa']; ?>" class="badge badge-warning d-inline tombol-edit">Edit</a>

                                            <?php } else { ?>
                                                <a href="/panitia/editmhs/<?= $gelo['id_mahasiswa']; ?>" class="badge badge-warning d-inline tombol-edit">Edit</a>
                                            <?php } ?> | <?php if ($gelo['id_pilihan_1'] == 8) {
                                                            ?>
                                                <a href="/panitia/editjrsmhsmgs/<?= $gelo['id_mahasiswa']; ?>" class="badge badge-secondary d-inline tombol-edit">Edit Jurusan</a>

                                            <?php } else { ?>
                                                <a href="/panitia/editjrsmhs/<?= $gelo['id_mahasiswa']; ?>" class="badge badge-secondary d-inline tombol-edit">Edit Jurusan</a>
                                            <?php } ?> | <a href="/panitia/deletemhs/<?= $gelo['id_mahasiswa']; ?>" class="badge badge-danger d-inline tombol-hapus">Delete</a>
                                        </td>
                                    </tr>
                                    
                                    
                                    <script>
        $(document).ready(function() {
            $('#formgetreward<?= $gelo['id_mahasiswa'] ?>').submit(function(e) {
                e.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: "post",
                    url: $(this).attr('action'),
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    beforeSend: function() {
                        $('.simpanGetReward<?= $gelo['id_mahasiswa'] ?>').attr('disable', 'disabled');
                        $('.simpanGetReward<?= $gelo['id_mahasiswa'] ?>').html('<i class="fa fa-spin fa-spinner"></i>');
                    },
                    complete: function() {
                        $('.simpanGetReward<?= $gelo['id_mahasiswa'] ?>').removeAttr('disable');
                        $('.simpanGetReward<?= $gelo['id_mahasiswa'] ?>').html('Coba Lagi');
                    },
                    success: function(response) {
                        if (response.error) {
                            if (response.error.id_mahasiswa) {
                                $('#id_mahasiswa').addClass('is-invalid');
                                $('.errorIdMhs').html(response.error.id_mahasiswa);
                            } else {
                                $('#id_mahasiswa').removeClass('is-invalid');
                                $('#id_mahasiswa').addClass('is-valid');
                                $('.validIdMhs').html('Benar!!');
                            };

                            Swal.fire({
                                icon: 'error',
                                title: 'Oops... Penyerahan Gagal gagal',
                                text: 'Yuk, Cek kembali isian anda',
                            })

                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: response.sukses,
                            })

                            setTimeout(function() {
                                window.location.reload(1);
                            }, 1500);
                        }
                    },
                    error: function(xhr, ajaxOption, thrownError) {
                        alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
                    }
                });
                return false
            });
        });
    </script>
                                    
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?= $pager->links('mahasiswa_baru', 'halaman_pagination'); ?>
        <?php } ?>
    </div>
    
    <script>
        setTimeout(function() {
            window.location.reload(1);
        }, 20000);
    </script>
    <!-- /.card-body -->
</div>
<?= $this->endSection(); ?>