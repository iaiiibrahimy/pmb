<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
        <img src="/admins/dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">Panitia PMB</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="/admins/dist/img/default.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block">IAI IBRAHIMY</a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
                <li class="nav-item">
                    <a href="/dashboard-panitia" class="nav-link <?= $dashboard; ?>">
                        <i class="nav-icon fas fa-home"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link <?= $gel; ?>">
                        <i class="nav-icon fas fa-user-graduate"></i>
                        <p>
                            Data Mahasiswa
                            <i class="right fas fa-angle-left"></i>
                            <?php if ($notvalidation == 0) {
                            ?>


                            <?php } else { ?>
                                <span class="badge badge-danger right"><?= $notvalidation ?></span>
                            <?php } ?>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="/validasi" class="nav-link <?= $gel2; ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Validasi</p>
                                <i class="right fas fa-angle-left"></i>
                                <?php if ($notvalidation == 0) {
                                ?>


                                <?php } else { ?>
                                    <span class="badge badge-danger right"><?= $notvalidation ?></span>
                                <?php } ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/data-gelombang-1" class="nav-link <?= $gel1; ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Data Calon Mahasiswa</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link <?= $peng; ?>">
                        <i class="nav-icon fas fa-file-export"></i>
                        <p>
                            Export Data
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="/panitia/exdata1" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Export Format PD DIKTI</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/panitia/exdata2" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Export Format SIAKAD</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="/home/logoutpanitia" class="nav-link">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>
                            Log Out
                        </p>
                    </a>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-8">
                    <h1 class="m-0"><?= $title ?> TAHUN AKADEMIK <?= $tahun_akademiks['nama_tahun_akademik']; ?></h1>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <?php if (session()->getFlashdata('pesan')) : ?>
        <div class="alert alert-success ml-3 mr-3" role="alert">
            <?= session()->getFlashdata('pesan'); ?>
        </div>
    <?php endif; ?>



    <section class="content">
        <div class="container-fluid">
            <!-- Info boxes -->
            <div class="row">
                <div class="col-12 col-sm-6 col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-success elevation-1"><i class="fas fa-users"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Total Pendaftar</span>
                            <span class="info-box-number">
                                <?= $allpendaftar; ?>
                                <small>Orang</small>
                            </span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class="col-12 col-sm-6 col-md-4">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-unlock-alt"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Sudah Validasi</span>
                            <span class="info-box-number"><?= $havevalidation; ?>
                                <small>Orang</small>
                            </span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->

                <!-- fix for small devices only -->
                <div class="clearfix hidden-md-up"></div>

                <div class="col-12 col-sm-6 col-md-4">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-lock"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Belum Divalidasi </span>
                            <span class="info-box-number"><?= $notvalidation; ?>
                                <small>Orang</small>
                            </span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <!-- /.col -->
            </div>
            <hr>