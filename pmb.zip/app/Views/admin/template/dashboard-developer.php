<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title; ?></title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="/admins/plugins/fontawesome-free/css/all.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="/admins/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="/admins/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="/admins/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="/admins/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

    <!-- Theme style -->
    <link rel="stylesheet" href="/admins/dist/css/adminlte.min.css">
    <!-- jQuery -->
    <script src="/admins/plugins/jquery/jquery.min.js"></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->

        <?= $this->include('admin/template/navbar-developer'); ?>

        <?= $this->renderSection('contentss'); ?>

    </div>
    <!-- /.row -->
    </section>
    </div>

    </div>
    <!-- /.content-wrapper -->


    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->

    <!-- Main Footer -->
    <footer class="main-footer">
        <strong>Copyright &copy; <script>
                document.write(new Date().getFullYear());
            </script> <a href="#">TI Institut Agama Islam Ibarhimy Genteng Banyuwangi</a>.</strong>
        All rights reserved.
        <div class="float-right d-none d-sm-inline-block">
            <b>Version</b> 3.1.0-rc
        </div>
    </footer>
    </div>
    <!-- ./wrapper -->

    <!-- REQUIRED SCRIPTS -->

    <!-- Bootstrap -->
    <script src="/admins/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="/admins/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <!-- AdminLTE App -->
    <script src="/admins/dist/js/adminlte.js"></script>

    <!-- PAGE PLUGINS -->
    <!-- jQuery Mapael -->
    <script src="/admins/plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
    <script src="/admins/plugins/raphael/raphael.min.js"></script>
    <script src="/admins/plugins/jquery-mapael/jquery.mapael.min.js"></script>
    <script src="/admins/plugins/jquery-mapael/maps/usa_states.min.js"></script>
    <!-- ChartJS -->
    <script src="/admins/plugins/chart.js/Chart.min.js"></script>

    <!-- AdminLTE for demo purposes -->
    <script src="/admins/dist/js/demo.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="/admins/dist/js/pages/dashboard2.js"></script>
    <!-- DataTables  & Plugins -->
    <script src="/admins/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="/admins/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="/admins/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="/admins/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="/admins/plugins/jszip/jszip.min.js"></script>
    <script src="/admins/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="/admins/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <script src="/admins/sweet/sweetalert2.all.min.js"></script>
    <script src="/admins/sweet/scriptku.js"></script>
    <!-- Page specific script -->
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>
</body>

</html>