<?= $this->extend('admin/template/loginadmin'); ?>


<?= $this->section('contents'); ?>
<div class="login-box">

    <div class="login-logo">
        <a href="#">Panitia <b>PMB</b></a>
    </div>


    <?php if (session()->getFlashdata('pesan')) : ?>
        <div class="alert alert-warning ml-3 mr-3 text-center" role="alert">
            <?= session()->getFlashdata('pesan'); ?>
        </div>
    <?php endif; ?>

    <!-- /.login-logo -->
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Masuk sebagai panitia PMB</p>

            <form action="/home/login_panitiaa" method="post">
                <?= csrf_field(); ?>
                <input type="hidden" class="form-control" name="tahun_akademik" value="<?= $tahun_akademiks['id_tahun_akademiks'] ?>">
                <div class="input-group mb-3">
                    <input type="username" class="form-control" name="username" id="username" placeholder="Username Panitia">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-user-shield"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" class="form-control" name="password" id="password" placeholder="Password Panitia">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- /.col -->
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary btn-block"><strong> Sign In</strong></button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

            <div class="social-auth-links text-center mb-3">
                <a href="/home/login" class="btn btn-block btn-danger">
                    <i class=""></i> <strong> Kembali Ke Halaman LOGIN</strong>
                </a>
            </div>
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<?= $this->endSection(); ?>