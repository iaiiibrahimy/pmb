<?= $this->extend('template/home'); ?>


<?= $this->section('content'); ?>
<!-- ======= Logins Section ======= -->
<section id="services" class="services">
    <div class="container">

        <div class="row d-flex justify-content-center">
            <div class="col-lg-4 col-md-6">
                <div class="icon-box" data-aos="fade-up">
                    <div class="icon"><i class="icofont-live-support"></i></div>
                    <h4 class="title"><a href="#">PANITIA PMB</a></h4>
                    <a class="btn btn-outline-success" href="/login-panitia" role="button">LOGIN DI SINI</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
                    <div class="icon"><i class="icofont-shield-alt"></i></div>
                    <h4 class="title"><a href="#">DEVELOPER</a></h4>
                    <a class="btn btn-outline-success" href="/home/login_developer" role="button">LOGIN DI SINI</a>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- End Logins Section -->




<?= $this->endSection(); ?>