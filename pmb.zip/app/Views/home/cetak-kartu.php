<?= $this->extend('template/home'); ?>


<?= $this->section('content'); ?>
<!-- ======= Logins Section ======= -->
<section id="contact" class="contact">
    <div class="container">

        <div class="row justify-content-center" data-aos="fade-up">
            <H3 class="text-center text-success"><strong> PENDAFTARAN MAHASISWA BARU TAHUN AKADEMIK <?= $tahun_akademiks['nama_tahun_akademik']; ?></strong></H3>
        </div>
        <?php if (session()->getFlashdata('pesan')) : ?>
            <div class="alert alert-success ml-3 mr-3 float-center" role="alert">
                <?= session()->getFlashdata('pesan'); ?>
            </div>
        <?php endif; ?>

        <div class="row justify-content-center mt-3">
            <div class="col-8">
                <form action="" method="POST">
                    <div class="input-group mb-3">
                        <input type="hidden" class="form-control" name="tahun_akademik" value="<?= $tahun_akademiks['id_tahun_akademiks']; ?>">
                        <input type="text" class="form-control" name="keyword" placeholder="Tulis Nama Anda/ Keyword di sini" value="<?= session('panda_3') ?>" onkeyup="this.value=this.value.toUpperCase()">
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="submit" name="submit"><i class="fas fa-search"></i>Cari</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-md-11">
                <?php if (empty(session('panda_4'))) {
                ?>
                    <h5 class="text-center">Cari nama anda sesuai dengan nama pendaftaran untuk mencetak kartu pendaftaran, jika nama anda belum ada setelah mendaftar online harap hubungi panitia.</h5>

                <?php } else { ?>

                    <?php if (empty(session('panda_3'))) {
                    ?>
                        <h5 class="text-center">Keyword tidak boleh kosong</h5>

                    <?php } else { ?>

                        <?php if (empty($cetaks)) {
                        ?>
                            <h5 class="text-center">Data anda tidak ada atau belum divalidasi</h5>

                        <?php } else { ?>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example2" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th class="text-center">NO</th>
                                                <th class="text-center">NOMOR PENDAFTARAN</th>
                                                <th class="text-center">NAMA CALON MAHASISWA</th>
                                                <th class="text-center">DOWNLOAD</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1 + (10 * ($currentPage - 1)); ?>
                                            <?php foreach ($cetaks as $ceta) : ?>
                                                <tr>
                                                    <td class="text-center"><?= $i++; ?></td>
                                                    <td><?= $ceta['nomor_pendaftaran']; ?></td>
                                                    <td><?= $ceta['nama_mahasiswa']; ?></td>
                                                    <td class="d-flex justify-content-center"><a href="/home/simpankartu/<?= $ceta['nomor_pendaftaran']; ?>" target="_blank" class="btn btn-outline-info d-inline"> Cetak Kartu Pendaftaran</a></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php } ?>
                    <?php } ?>
                <?php } ?>
            </div>
        </div>
    </div>


</section><!-- End Contact Section -->

<!-- End Logins Section -->




<?= $this->endSection(); ?>