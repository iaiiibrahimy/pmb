<?= $this->extend('template/home'); ?>


<?= $this->section('content'); ?>
<!-- ======= Hero Section ======= -->
<div id="carouselExampleIndicators" class="carousel slide mt-2 mb-2" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php
        $i = 0;
        foreach ($slider as $sliders) {
            $actives = '';
            if ($i == 0) {
                $actives = 'active';
            }
        ?>
            <li data-target="#carouselExampleIndicators" data-slide-to="<?= $sliders['id_slider']; ?>" class="<?= $actives; ?>"></li>
        <?php $i++;
        } ?>
    </ol>
    <div class="carousel-inner">

        <?php
        $i = 0;
        foreach ($slider as $sliders) {
            $actives = '';
            if ($i == 0) {
                $actives = 'active';
            }
        ?>
            <div class="carousel-item <?= $actives; ?>">
                <img class="d-block w-100" src="/homes/assets/img/slide/<?= $sliders['nama_slider']; ?>">
            </div>
        <?php $i++;
        } ?>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<main id="main">

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
        <div class="container">

            <div class="row">
                <div class="col-lg-7 text-center text-lg-left">
                    <h3>Informasi Penerimaan Mahasiswa Baru!</h3>
                    <p> Untuk mengetahui informasi jadwal penerimaan mahasiswa baru, biaya kuliah dan beasiswa silahkan klik tombol di samping.</p>
                </div>
                <div class="col-lg-5 cta-btn-container text-center">
                    <a class="cta-btn align-middle" href="/informasi">Klik Di sini</a>
                    <a class="cta-btn align-middle" href="/homes/lain/brosur2023.jpg" target="_blank"> Download Brosur</a>
                </div>
            </div>

        </div>
    </section><!-- End Cta Section -->

</main><!-- End #main -->

<?= $this->endSection(); ?>