<?= $this->extend('template/home'); ?>


<?= $this->section('content'); ?>
<!-- ======= Logins Section ======= -->
<section id="contact" class="contact">
    <div class="container">

        <div class="row justify-content-center" data-aos="fade-up">
            <H3 class="text-center text-success"><strong> ISI DATA DIRI ANDA DI SINI</strong></H3>
        </div>
        <?php if (session()->getFlashdata('pesan')) : ?>
            <div class="alert alert-success ml-3 mr-3 float-center" role="alert">
                <?= session()->getFlashdata('pesan'); ?>
            </div>
        <?php endif; ?>

        <div class="row mt-5 justify-content-center" data-aos="fade-up">
            <div class="col-lg-12">
                <form action="/home/save2" method="post" enctype="multipart/form-data">
                    <div class="p-3 mt-2 mb-2 bg-danger text-white"><STrong>HARAP ISI KOLOM DENGAN BENAR, APABILA TIDAK SESUAI MAKA DATA TIDAK AKAN TERSIMPAN DAN BACA PEDOMAN PENDAFTARAN TERLEBIH DAHULU SEBELUM MENGISI FORM!!!</STrong></div>
                    <div class="p-3 mb-4 bg-dark text-white">Kolom Data Pribadi Calon Mahasiswa</div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="jalur_pendaftaran">Pilih Jalur (wajib)</label>
                                <select name="jalur_pendaftaran" class="form-control <?= ($validation->hasError('jalur_pendaftaran')) ? 'is-invalid' : ''; ?>" id="">
                                    <option value="" selected>Pilih Jalur Pendaftaran</option>
                                    <?php
                                    foreach ($jalur_pendaftaran as $jalur) {
                                        echo "<option value=" . $jalur->id_jalur_pendaftaran . ">" . $jalur->jalur_pendaftaran . "</option>";
                                    }
                                    ?>
                                </select>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('jalur_pendaftaran'); ?>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="mt-2 mb-3 d-flex justify-content-center">
                        <button type="submit" class="btn btn-primary">Daftar</button>
                    </div>

                    <div class="p-3 mt-4 mb-2 bg-danger text-white"><STrong>HARAP ISI KOLOM DENGAN BENAR, APABILA TIDAK SESUAI MAKA DATA TIDAK AKAN TERSIMPAN!!!</STrong></div>


                </form>
            </div>

        </div>

    </div>
</section><!-- End Contact Section -->

<!-- End Logins Section -->




<?= $this->endSection(); ?>