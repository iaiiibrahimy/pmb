<?= $this->extend('template/home'); ?>


<?= $this->section('content'); ?>
<!-- ======= Logins Section ======= -->
<section id="services" class="services">
    <div class="container mb-5">

        <div class="alert alert-success" role="alert">
            <h4 class="text-center">PEDOMAN PENDAFTARAN ONLINE</h4><br>
            <p><strong>1. Pendaftaran online hanya tersedia di website resmi kampus Institut Agama Islam Ibrahimy Genteng Banyuwangi yaitu di pmb.iaiibrahimy.ac.id</strong></p>
            <p><strong>2. sebelum mengisi formulir online, calon mahasiswa diharuskan membayar biaya pendaftaran: <br> <br> - Sarjana (S1) : Rp. 300.000,- ke rekening Kampus (Lihat list di bawah) <br> - Magister (S2) : Rp. 500.000,- ke nomor rekening Kampus (Lihat list di bawah)</strong></p>
            <p><strong>3. Setelah transfer, silahkan mengisi formulir di menu "DAFTAR ONLINE". </strong></p>
            <p><strong>4. Setelah sukses mengisi formulir online, tunggu validasi dari panitia PMB (Penerimaan Mahasiswa Baru) untuk mencetak kartu pendaftaran. </strong></p>
            <p><strong>5. Setelah divalidasi, cari nama anda di kolom pencarian pada menu "CETAK KARTU" untuk mencetak bukti kartu pendaftaran </strong></p>
            <p><strong>6. Pendaftaran selesai </strong></p>
            </div>
            <br>
             <div class="alert alert-success" role="alert">
            <p class="text-danger"><strong>Untuk Informasi Lebih Banyak tentang Penerimaan Mahasiswa Baru bisa kirim pesan dengan Klik Tombol ini <a  target="_blank" href="https://wa.me/6287816511550" role="button"><img class="mr-3" src="/homes/lain/chatwa.png" style="width: 20%;"></a> </strong></p>
        </div>
        

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th colspan="3" class="text-center"><strong>DAFTAR NOMOR REKENING IAI IBRAHIMY GENTENG BANYUWANGI</strong></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center"><strong>NAMA BANK</strong></td>
                    <td class="text-center"><strong>NOMOR REKENING</strong></td>
                    <td class="text-center"><strong>KETERANGAN</strong></td>
                </tr>
                <tr>
                    <td>BRI</td>
                    <td>0577-01-000812-30-5</td>
                    <td>a.n IAI IBRAHIMY GENTENG</td>
                </tr>
                <tr>
                    <td>BANK MANDIRI</td>
                    <td>143-00-9203576-3</td>
                    <td>a.n IAI IBRAHIMY GENTENG</td>
                </tr>
            </tbody>
        </table>


        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th colspan="2" class="text-center">JAM PELAYANAN PENERIMAAN MAHASISWA BARU</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>HARI</td>
                    <td>JAM</td>
                </tr>
                <tr>
                    <td class="text-warning">SENIN - SABTU</td>
                    <td class="text-warning">9.00 - 16.00</td>
                </tr>
                <tr>
                    <td colspan="2" class="text-danger text-center"><strong>NB: HARI BESAR ATAU TANGGAL MERAH PELAYANAN PMB LIBUR</strong></td>
                </tr>
            </tbody>
        </table>

    </div>
</section>

<!-- End Logins Section -->




<?= $this->endSection(); ?>