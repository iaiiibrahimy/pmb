<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title><?= $title; ?></title>
    <meta name="author" content="Muhammad Toha">
    <meta name="descriptison" content="">
    <meta name="keywords" content="">
    <meta property="og:url" content=" ">
    <meta property="og:type" content="website">
    <meta property="og:title" content=" ">
    <meta property="og:image" content=" ">
    <meta property="og:image:secure_url" content="">
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:description" content=" ">
    <meta property="og:updated_time" content=" " />

    <!-- Favicons -->

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="/homes/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/homes/assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="/homes/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="/homes/assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="/homes/assets/vendor/venobox/venobox.css" rel="stylesheet">
    <link href="/homes/assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="/homes/assets/vendor/aos/aos.css" rel="stylesheet">
    <!-- Template Main CSS File -->
    <link href="/homes/assets/css/style.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="/admins/plugins/jquery/jquery.min.js"></script>

</head>

<body>

    <!-- ======= Top Bar ======= -->
    <section id="topbar" class="d-none d-lg-block">
        <div class="container d-flex">
            <div class="contact-info mr-auto">
                <i class="icofont-envelope"></i><a href="mailto:<?= $pengatur['email_sekolah']; ?>"><?= $pengatur['email_sekolah']; ?></a>
                <i class="icofont-phone"></i> <?= $pengatur['telephone']; ?>
            </div>
            <div class="social-links">
                <a href="<?= $pengatur['twitter_sekolah']; ?>" class="twitter"><i class="icofont-twitter"></i></a>
                <a href="<?= $pengatur['facebook_sekolah']; ?>" class="facebook"><i class="icofont-facebook"></i></a>
                <a href="<?= $pengatur['instagram_sekolah']; ?>" class="instagram"><i class="icofont-instagram"></i></a>
            </div>
        </div>
    </section>

    <?= $this->include('template/navbar'); ?>

    <?= $this->renderSection('content'); ?>

    <!-- ======= Footer ======= -->
    <footer id="footer">

        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-md-6 footer-contact">
                        <h3>Kontak Kami</h3>
                        <p>
                            <?= $pengatur['alamat_jalan']; ?><br>
                            <?= $pengatur['alamat_desa']; ?><br>
                            <?= $pengatur['alamat_provinsi']; ?> <br><br>
                            <strong>Phone:</strong> <?= $pengatur['telephone']; ?><br>
                            <strong>Email:</strong> <?= $pengatur['email_sekolah']; ?><br>
                        </p>
                    </div>

                    <div class="col-lg-6 col-md-6 footer-links">
                        <h4>Link Penting</h4>
                        <ul>
                            <li><i class="bx bx-chevron-right"></i> <a href="/informasi">Pedoman dan Informasi PMB Online</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="/daftar-online">Pendaftaran PMB Online</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>

        <div class="container d-md-flex py-4">

            <div class="mr-md-auto text-center text-md-left">
                <div class="copyright">
                    <script>
                        document.write(new Date().getFullYear());
                    </script> &copy; Copyright <strong><span>IT Institut Agama Islam Ibrahimy Genteng Banyuwangi</span></strong>. All Rights Reserved
                </div>
            </div>
            <div class="social-links text-center text-md-right pt-3 pt-md-0">
                <a href="<?= $pengatur['twitter_sekolah']; ?>" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="<?= $pengatur['facebook_sekolah']; ?>" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="<?= $pengatur['instagram_sekolah']; ?>" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="tel:<?= $pengatur['telephone']; ?>" class="telephone"><i class="bx bx-phone-call"></i></a>
            </div>
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

    <!-- Vendor JS Files -->


    <script src="/homes/assets/vendor/jquery/jquery.min.js"></script>
    <script src="/homes/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/homes/assets/vendor/jquery.easing/jquery.easing.min.js"></script>
    <script src="/homes/assets/vendor/php-email-form/validate.js"></script>
    <script src="/homes/assets/vendor/jquery-sticky/jquery.sticky.js"></script>
    <script src="/homes/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="/homes/assets/vendor/venobox/venobox.min.js"></script>
    <script src="/homes/assets/vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="/homes/assets/vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="/homes/assets/vendor/aos/aos.js"></script>
    <script>
        $('.custom-file-input').on('change', function() {
            let fileName = $(this).val().split('\\').pop();
            $(this).next('.custom-file-label').addClass("selected").html(fileName);
        });
    </script>

    <!-- Template Main JS File -->
    <script src="/homes/assets/js/main.js"></script>

    <!-- DataTables  & Plugins -->
    <script src="/admins/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="/admins/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="/admins/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="/admins/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="/admins/plugins/jszip/jszip.min.js"></script>
    <script src="/admins/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="/admins/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="/admins/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <script src="/admins/sweet/sweetalert2.all.min.js"></script>
    <script src="/admins/sweet/scriptku.js"></script>
    <!-- Page specific script -->
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>
    <script src="/admins/plugins/inputmask/jquery.inputmask.min.js"></script>

</body>

</html>