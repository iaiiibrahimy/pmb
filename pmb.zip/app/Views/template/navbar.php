<!-- ======= Header ======= -->
<header id="header">
    <div class="container d-flex">

        <div class="logo mr-auto">
            <!-- Uncomment below if you prefer to use an image logo -->
            <a href="/"><img src="/homes/assets/img/logo/logo.png" alt="" class="img-fluid"></a>
        </div>

        <nav class="nav-menu d-none d-lg-block">
            <ul>
                <li class="<?= $home; ?>"><a href="/"><strong>Home</strong></a></li>
                <li class="<?= $informasi; ?>"><a href="/informasi"><strong>Pedoman dan Informasi</strong></a></li>
                <li class="<?= $listmaba; ?>"><a href="/cetak-kartu"><strong>Cetak Kartu Pendaftaran</strong></a></li>
                <li class="drop-down <?= $online; ?>"><a href="#"><strong>Daftar Online</strong> <i class="bi bi-chevron-down"></i></a>
                    <ul>
                        <li><a href="/daftar-online"><strong>Form Pendaftaran S1</strong></a></li>
                        <li><a href="/daftar-online-magister"><strong>Form Pendaftaran S2</strong></a></li>
                    </ul>
                </li>
                <li class="<?= $login; ?>"><a href="/home/login"><strong>Login</strong></a></li>

            </ul>
        </nav><!-- .nav-menu -->

    </div>
</header><!-- End Header -->