<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Filters extends BaseConfig
{
	// Makes reading things below nicer,
	// and simpler to change out script that's used.
	public $aliases = [
		'csrf'     => \CodeIgniter\Filters\CSRF::class,
		'toolbar'  => \CodeIgniter\Filters\DebugToolbar::class,
		'honeypot' => \CodeIgniter\Filters\Honeypot::class,
		'authFilter' => \App\Filters\AuthFilter::class,
		'devFilter' => \App\Filters\DevFilter::class,
	];

	// Always applied before every request
	public $globals = [
		'before' => [
			// 'honeypot',
			// 'login'
			// 'devFilter' => ['except' => ['home/login_developer', 'login-developer', '/home/login', '/login']],
			// 'authFilter' => ['except' => ['/', 'home', '/home/informasi']],
			// 'devFilter' => ['except' => ['developer', 'developer/*']],
			// 'csrf',
		],
		'after'  => [
			// 'authFilter' => ['except' => ['panitia', 'panitia/*']],
			// 'devFilter' => ['except' => ['/', 'home/*']],
			// 'devFilter' => ['after' => ['developer', 'developer/*', 'list-developer-pmb', 'list-panitia-pmb', 'dashboard-developer']],
			'toolbar',
			//'honeypot'
		],
	];

	// Works on all of a particular HTTP method
	// (GET, POST, etc) as BEFORE filters only
	//     like: 'post' => ['CSRF', 'throttle'],
	public $methods = [];

	// List filter aliases and any before/after uri patterns
	// that they should run on, like:
	//    'isLoggedIn' => ['before' => ['account/*', 'profiles/*']],
	public $filters = [
		// 'authFilter' => ['before' => ['panitia']],
		// 'devFilter' => ['before' => ['home/login_developer', 'login-developer', '/home/login', '/login']],
		'authFilter' => ['after' => ['panitia', 'panitia/*', 'data-gelombang-1', 'data-gelombang-2', 'data-gelombang-3', 'edit-mahasiswa']],
		'devFilter' => ['after' => ['developer', 'developer/*', 'list-developer-pmb', 'list-panitia-pmb', 'dashboard-developer']],
	];
}
