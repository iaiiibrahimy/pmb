<?php

namespace App\Models;

use CodeIgniter\Model;

class JalurModel extends Model
{
    protected $table      = 'jalur_pendaftaran';
    protected $primaryKey = 'id_jalur_pendaftaran';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_jalur_pendaftaran', 'jalur_pendaftaran'];

    public function GetAllJalur()
    {
    }
}
