<?php

namespace App\Models;

use CodeIgniter\Model;

class DataOfflineModel extends Model
{
    protected $table      = 'data_offline';
    protected $primaryKey = 'id_data_offline';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_data_offline', 'gelombang', 'nomor_test', 'program_studi', 'nama', 'jenis_kelamin', 'ttl', 'tempat_lahir', 'agama', 'nama_kelurahan', 'nama_kecamatan', 'nama_ibu', 'kewarganegaraan', 'nisn', 'nik', 'nama_jalan', 'rt', 'rw', 'dusun', 'hp', 'email', 'nama_ayah'];

    public function getDataOffline($id_data_offline = false)
    {
        if ($id_data_offline == false) {
            return $this->db->table('data_offline')
                ->join('jenis_kelamin', 'jenis_kelamin.id_jenis_kelamin=data_offline.jenis_kelamin')
                ->join('jurusan', 'jurusan.id_jurusan=data_offline.program_studi')
                ->join('agama', 'agama.id_agama=data_offline.agama')
                ->join('negara', 'negara.id_wn=data_offline.kewarganegaraan')
                ->orderBy('created_at DESC')
                ->get()->getResultArray();
        }
        return $this->where(['id_data_offline' => $id_data_offline])
            ->first();
    }

    public function getJenisKelamin()
    {
        return $this->db->table('jenis_kelamin')
            ->get()->getResult();
    }

    public function getJurusann()
    {
        return $this->db->table('jurusan')
            ->get()->getResult();
    }

    public function getAgama()
    {
        return $this->db->table('agama')
            ->get()->getResult();
    }

    public function getNegara()
    {
        return $this->db->table('negara')
            ->get()->getResult();
    }

    public function GetAllOffline()
    {
        return $this->db->table('data_offline')
            ->countAll();
    }
}
