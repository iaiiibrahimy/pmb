<?php

namespace App\Models;

use CodeIgniter\Model;

class TahunAkademikModel extends Model
{
    protected $table      = 'tahun_akademik_status';
    protected $primaryKey = 'id_tahun_akademik_status';
    protected $useTimestamps = false;
    protected $allowedFields = ['id_tahun_akademik_status', 'id_tahun_akademiks'];

    public function getStatusTahunAkademik($id_tahun_akademik_status = false)
    {
        if ($id_tahun_akademik_status == false) {
            return $this->db->table('tahun_akademik_status')
                ->join('tahun_akademik', 'tahun_akademik.id_tahun_akademik=tahun_akademik_status.id_tahun_akademiks')
                ->get()->getResultArray();
        }
        return $this->where(['id_tahun_akademik_status' => $id_tahun_akademik_status])
            ->join('tahun_akademik', 'tahun_akademik.id_tahun_akademik=tahun_akademik_status.id_tahun_akademiks')
            ->first();
    }

    public function getTahunAkademik()
    {
        return $this->db->table('tahun_akademik')
            ->get()->getResultArray();
    }
}
