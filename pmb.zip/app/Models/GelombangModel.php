<?php

namespace App\Models;

use CodeIgniter\Model;

class GelombangModel extends Model
{
    protected $table      = 'gelombang_status';
    protected $primaryKey = 'id_gelombang_status';
    protected $useTimestamps = false;
    protected $allowedFields = ['id_gelombang'];


    public function getStatusGelombang($id_gelombang_status = false)
    {
        if ($id_gelombang_status == false) {
            return $this->db->table('gelombang_status')
                ->join('gelombang', 'gelombang.id_gelombang=gelombang_status.id_gelombang')
                ->get()->getResultArray();
        }
        return $this->where(['id_gelombang_status' => $id_gelombang_status])
            ->first();
    }

    public function getGelombang()
    {
        return $this->db->table('gelombang')
            ->get()->getResultArray();
    }
}
