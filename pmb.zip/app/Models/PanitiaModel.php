<?php

namespace App\Models;

use CodeIgniter\Model;

class PanitiaModel extends Model
{
    protected $table      = 'panitia_pmb';
    protected $primaryKey = 'id_panitia';
    protected $useTimestamps = true;
    protected $allowedFields = ['username', 'nama_panitia', 'password'];
}
