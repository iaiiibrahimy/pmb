<?php

namespace App\Models;

use CodeIgniter\Model;

class KartuModel extends Model
{
    protected $table      = 'kartu';
    protected $primaryKey = 'id_kartu';
    protected $useTimestamps = false;
    protected $allowedFields = ['kartu'];
}
