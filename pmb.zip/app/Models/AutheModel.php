<?php

namespace App\Models;

use CodeIgniter\Model;

class AutheModel extends Model
{
    function get_developer_login($username, $tbl)
    {
        $builder = $this->db->table($tbl);
        $builder->where('username', $username);
        $log2 = $builder->get()->getRow();
        return $log2;
    }
}
