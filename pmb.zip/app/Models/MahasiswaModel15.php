<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel15 extends Model
{
    protected $table      = 'mahasiswa_baru';
    protected $primaryKey = 'id_mahasiswa';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_mahasiswa', 'id_status_pendaftaran', 'id_gelombang', 'id_jalur_pendaftaran', 'id_validasi_pendaftaran', 'nomor_pendaftaran', 'bukti_pembayaran', 'nama_mahasiswa', 'nik', 'tempat_lahir', 'tanggal_lahir', 'bulan_lahir', 'tahun_lahir', 'id_jenis_kelamin', 'id_agama', 'id_wn', 'id_status', 'nama_jalan', 'rt', 'rw', 'dusun', 'kelurahan', 'kecamatan', 'kabupaten', 'no_hp', 'asal_sekolah', 'nisn', 'tahun_lulus', 'nama_tempat_kerja', 'alamat_tempat_kerja', 'nomor_telephone_kerja', 'nama_ayah', 'id_pendidikan_ayah', 'id_pekerjaan_ayah', 'nama_ibu', 'id_pendidkan_ibu', 'id_pekerjaan_ibu', 'id_penghasilan_wali', 'alamat_wali', 'nomor_hp_wali', 'id_pilihan_1', 'id_pilihan_2', 'tahun_akademik', 'tanggal_daftar', 'pendaftaran'];




    public function GetNomorPs($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '2')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorPmi($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '3')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorHki($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '4')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorPai($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '5')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorPiaud($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '7')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorPgmi($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '6')
                ->orderBy('id_mahasiswa DESC');
        }
    }
    
    public function GetNomorMat($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '11')
                ->orderBy('id_mahasiswa DESC');
        }
    }
}
