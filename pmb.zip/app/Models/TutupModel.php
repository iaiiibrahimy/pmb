<?php

namespace App\Models;

use CodeIgniter\Model;

class TutupModel extends Model
{
    protected $table      = 'tutup_pendaftaran_status';
    protected $primaryKey = 'id_tutup_pendaftaran_status';
    protected $useTimestamps = false;
    protected $allowedFields = ['id_tutup_pendaftaran_status', 'id_tutup_pendaftaran'];

    public function getStatusTutupPendaftaran($id_tutup_pendaftaran_status = false)
    {
        if ($id_tutup_pendaftaran_status == false) {
            return $this->db->table('tutup_pendaftaran_status')
                ->join('tutup_pendaftaran', 'tutup_pendaftaran.id_tutup_pendaftaran=tutup_pendaftaran_status.id_tutup_pendaftaran')
                ->get()->getResultArray();
        }
        return $this->where(['id_tutup_pendaftaran_status' => $id_tutup_pendaftaran_status])
            ->first();
    }

    public function getTutupPendaftaran()
    {
        return $this->db->table('tutup_pendaftaran')
            ->get()->getResultArray();
    }
}
