<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $table      = 'mahasiswa_baru';
    protected $primaryKey = 'id_mahasiswa';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_mahasiswa', 'id_status_pendaftaran', 'id_gelombang', 'id_jalur_pendaftaran', 'id_validasi_pendaftaran', 'nomor_pendaftaran', 'bukti_pembayaran', 'nama_mahasiswa', 'nik', 'tempat_lahir', 'tanggal_lahir', 'bulan_lahir', 'tahun_lahir', 'id_jenis_kelamin', 'id_agama', 'id_wn', 'id_status', 'nama_jalan', 'rt', 'rw', 'dusun', 'kelurahan', 'kecamatan', 'kabupaten', 'no_hp', 'asal_sekolah', 'nisn', 'tahun_lulus', 'nama_tempat_kerja', 'alamat_tempat_kerja', 'nomor_telephone_kerja', 'nama_ayah', 'id_pendidikan_ayah', 'id_pekerjaan_ayah', 'nama_ibu', 'id_pendidikan_ibu', 'id_pekerjaan_ibu', 'id_penghasilan_wali', 'alamat_wali', 'nomor_hp_wali', 'id_pilihan_1', 'id_pilihan_2', 'tahun_akademik', 'nama_rekomendasi', 'nomor_rekomendasi', 'tanggal_daftar', 'pendaftaran', 'nama_kampus', 'prodi_sarjana', 'ipk_sarjana', 'namsd_sar', 'namsmp_sar', 'namsma_sar', 'tlulus_sd', 'tlulus_smp', 'tlulus_sma', 'tlulus_kul', 'noser_ijas', 'byatung', 'smt_1', 'smt_2', 'rerata_smt1', 'rerata_smt2', 'code_recom', 'reward'];


    public function GetCalonMahasiswa($tahun_akademik = false, $keyword = false)
    {
        if ($tahun_akademik == false) {
            return $this->table('mahasiswa_baru')
                ->join('pendaftaran', 'pendaftaran.id_status_pendaftaran=mahasiswa_baru.pendaftaran')
                ->join('gelombang', 'gelombang.id_gelombang=mahasiswa_baru.id_gelombang')
                ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
                ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
                ->join('status_pendaftaran', 'status_pendaftaran.id_status_pendaftarans=mahasiswa_baru.id_status_pendaftaran')
                ->orderBy('id_mahasiswa DESC');
        } else {
            if ($keyword == false) {
                return $this->table('mahasiswa_baru')
                    ->join('pendaftaran', 'pendaftaran.id_status_pendaftaran=mahasiswa_baru.pendaftaran')
                    ->join('gelombang', 'gelombang.id_gelombang=mahasiswa_baru.id_gelombang')
                    ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
                    ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
                    ->join('status_pendaftaran', 'status_pendaftaran.id_status_pendaftarans=mahasiswa_baru.id_status_pendaftaran')
                    ->like('id_validasi_pendaftaran', '1')
                    ->like('tahun_akademik', $tahun_akademik)
                    ->orderBy('id_mahasiswa DESC');
            } else {
                return $this->table('mahasiswa_baru')
                    ->join('pendaftaran', 'pendaftaran.id_status_pendaftaran=mahasiswa_baru.pendaftaran')
                    ->join('gelombang', 'gelombang.id_gelombang=mahasiswa_baru.id_gelombang')
                    ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
                    ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
                    ->join('status_pendaftaran', 'status_pendaftaran.id_status_pendaftarans=mahasiswa_baru.id_status_pendaftaran')
                    ->like('id_validasi_pendaftaran', '1')
                    ->like('tahun_akademik', $tahun_akademik)
                    ->like('nama_mahasiswa', $keyword)
                    ->orderBy('id_mahasiswa DESC');
            }
        }
    }

    public function GetCalonMahasiswa2($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            return $this->table('mahasiswa_baru')
                ->join('gelombang', 'gelombang.id_gelombang=mahasiswa_baru.id_gelombang')
                ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
                ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
                ->join('status_pendaftaran', 'status_pendaftaran.id_status_pendaftarans=mahasiswa_baru.id_status_pendaftaran')
                ->orderBy('id_mahasiswa DESC');
        } else {
            return $this->table('mahasiswa_baru')
                ->join('gelombang', 'gelombang.id_gelombang=mahasiswa_baru.id_gelombang')
                ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
                ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
                ->join('status_pendaftaran', 'status_pendaftaran.id_status_pendaftarans=mahasiswa_baru.id_status_pendaftaran')
                ->like('id_validasi_pendaftaran', '0')
                ->like('tahun_akademik', $tahun_akademik)
                ->orderBy('id_mahasiswa DESC');
        }
    }


    public function GetEditMahasiswa($id_mahasiswa = false)
    {
        if ($id_mahasiswa == false) {
            echo "Mohon maaf data tidak ditemukan";
        }
        return $this->where(['id_mahasiswa' => $id_mahasiswa])
            ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
            ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
            ->first();
    }

    public function GetEditDataMahasiswa($id_mahasiswa = false)
    {
        if ($id_mahasiswa == false) {
            echo "Mohon maaf data tidak ditemukan";
        }
        return $this->where(['id_mahasiswa' => $id_mahasiswa])
            ->first();
    }


    public function getMahasiswa5($nomor_pendaftaran = false)
    {
        if ($nomor_pendaftaran == false) {
            echo "Mohon maaf data tidak ditemukan";
        }
        return $this->where(['nomor_pendaftaran' => $nomor_pendaftaran])
            ->join('status_pendaftaran', 'status_pendaftaran.id_status_pendaftarans=mahasiswa_baru.id_status_pendaftaran')
            ->join('gelombang', 'gelombang.id_gelombang=mahasiswa_baru.id_gelombang')
            ->join('jalur_pendaftaran', 'jalur_pendaftaran.id_jalur_pendaftaran=mahasiswa_baru.id_jalur_pendaftaran')
            ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
            ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
            ->first();
    }

    public function GetCetakKartu($nomor_pendaftaran = false)
    {
        if ($nomor_pendaftaran == false) {
            echo "Mohon maaf data tidak ditemukan";
        }
        return $this->where(['nomor_pendaftaran' => $nomor_pendaftaran])
            ->join('jalur_pendaftaran', 'jalur_pendaftaran.id_jalur_pendaftaran=mahasiswa_baru.id_jalur_pendaftaran')
            ->join('gelombang', 'gelombang.id_gelombang=mahasiswa_baru.id_gelombang')
            ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
            ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
            ->join('status_pendaftaran', 'status_pendaftaran.id_status_pendaftarans=mahasiswa_baru.id_status_pendaftaran')
            ->first();
    }
    
    public function GetCetakKartuRekom($nomor_pendaftaran = false)
    {
        if ($nomor_pendaftaran == false) {
            echo "Mohon maaf data tidak ditemukan";
        }
        return $this->where(['nomor_pendaftaran' => $nomor_pendaftaran])
            ->join('jalur_pendaftaran', 'jalur_pendaftaran.id_jalur_pendaftaran=mahasiswa_baru.id_jalur_pendaftaran')
            ->join('gelombang', 'gelombang.id_gelombang=mahasiswa_baru.id_gelombang')
            ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
            ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
            ->join('status_pendaftaran', 'status_pendaftaran.id_status_pendaftarans=mahasiswa_baru.id_status_pendaftaran')
            ->first();
    }

    public function GetNomorEkos($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '1')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorPs($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '2')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorPmi($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '3')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorHki($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '4')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorPai($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '5')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorPiaud($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '7')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetNomorPgmi($tahun_akademik = false)
    {
        if ($tahun_akademik == false) {
            echo "Nomor Masih Kosong";
        } else {
            return $this->table('mahasiswa_baru')
                ->like('tahun_akademik', $tahun_akademik)
                ->like('id_validasi_pendaftaran', '1')
                ->like('id_pilihan_1', '6')
                ->orderBy('id_mahasiswa DESC');
        }
    }

    public function GetCetakFormulir($nomor_pendaftaran = false)
    {
        if ($nomor_pendaftaran == false) {
            echo "Mohon maaf data tidak ditemukan";
        }
        return $this->where(['nomor_pendaftaran' => $nomor_pendaftaran])
            ->join('jenis_kelamin', 'jenis_kelamin.id_jenis_kelamin=mahasiswa_baru.id_jenis_kelamin')
            ->join('agama', 'agama.id_agama=mahasiswa_baru.id_agama')
            ->join('kawin', 'kawin.id_status=mahasiswa_baru.id_status')
            ->join('pekerjaan', 'pekerjaan.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ayah')
            ->join('pendidikan_ortu', 'pendidikan_ortu.id_pendidikan=mahasiswa_baru.id_pendidikan_ayah')
            ->join('pekerjaan_2', 'pekerjaan_2.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ibu')
            ->join('pendidikan_ortu_2', 'pendidikan_ortu_2.id_pendidikan=mahasiswa_baru.id_pendidikan_ibu')
            ->join('jalur_pendaftaran', 'jalur_pendaftaran.id_jalur_pendaftaran=mahasiswa_baru.id_jalur_pendaftaran')
            ->join('gelombang', 'gelombang.id_gelombang=mahasiswa_baru.id_gelombang')
            ->join('penghasilan', 'penghasilan.id_penghasilan_wali=mahasiswa_baru.id_penghasilan_wali')
            ->join('jurusan', 'jurusan.id_jurusan=mahasiswa_baru.id_pilihan_1')
            ->join('jurusan_2', 'jurusan_2.id_jurusan=mahasiswa_baru.id_pilihan_2')
            ->join('status_pendaftaran', 'status_pendaftaran.id_status_pendaftarans=mahasiswa_baru.id_status_pendaftaran')
            ->first();
    }

    public function GetMahasiswa2($tahun_akademik = false, $keyword = false)
    {
        if ($tahun_akademik == false) {
            return $this->table('mahasiswa_baru')
                ->join('jenis_kelamin', 'jenis_kelamin.id_jenis_kelamin=mahasiswa_baru.id_jenis_kelamin')
                ->join('agama', 'agama.id_agama=mahasiswa_baru.id_agama')
                ->join('negara', 'negara.id_wn=mahasiswa_baru.id_wn')
                ->join('pendidikan_ortu', 'pendidikan_ortu.id_pendidikan=mahasiswa_baru.id_pendidikan_ayah')
                ->join('pekerjaan', 'pekerjaan.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ayah')
                ->join('pendidikan_ortu_2', 'pendidikan_ortu_2.id_pendidikan=mahasiswa_baru.id_pendidikan_ibu')
                ->join('pekerjaan_2', 'pekerjaan_2.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ibu')
                ->join('penghasilan', 'penghasilan.id_penghasilan_wali=mahasiswa_baru.id_penghasilan_wali')
                ->orderBy('id_mahasiswa DESC')
                ->get()->getResultArray();
        } else {
            if ($keyword == false) {
                return $this->table('mahasiswa_baru')
                    ->join('jenis_kelamin', 'jenis_kelamin.id_jenis_kelamin=mahasiswa_baru.id_jenis_kelamin')
                    ->join('agama', 'agama.id_agama=mahasiswa_baru.id_agama')
                    ->join('negara', 'negara.id_wn=mahasiswa_baru.id_wn')
                    ->join('pendidikan_ortu', 'pendidikan_ortu.id_pendidikan=mahasiswa_baru.id_pendidikan_ayah')
                    ->join('pekerjaan', 'pekerjaan.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ayah')
                    ->join('pendidikan_ortu_2', 'pendidikan_ortu_2.id_pendidikan=mahasiswa_baru.id_pendidikan_ibu')
                    ->join('pekerjaan_2', 'pekerjaan_2.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ibu')
                    ->join('penghasilan', 'penghasilan.id_penghasilan_wali=mahasiswa_baru.id_penghasilan_wali')
                    ->like('id_validasi_pendaftaran', '1')
                    ->like('tahun_akademik', $tahun_akademik)
                    ->orderBy('id_mahasiswa DESC')
                    ->get()->getResultArray();
            } else {
                return $this->table('mahasiswa_baru')
                    ->join('jenis_kelamin', 'jenis_kelamin.id_jenis_kelamin=mahasiswa_baru.id_jenis_kelamin')
                    ->join('agama', 'agama.id_agama=mahasiswa_baru.id_agama')
                    ->join('negara', 'negara.id_wn=mahasiswa_baru.id_wn')
                    ->join('pendidikan_ortu', 'pendidikan_ortu.id_pendidikan=mahasiswa_baru.id_pendidikan_ayah')
                    ->join('pekerjaan', 'pekerjaan.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ayah')
                    ->join('pendidikan_ortu_2', 'pendidikan_ortu_2.id_pendidikan=mahasiswa_baru.id_pendidikan_ibu')
                    ->join('pekerjaan_2', 'pekerjaan_2.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ibu')
                    ->join('penghasilan', 'penghasilan.id_penghasilan_wali=mahasiswa_baru.id_penghasilan_wali')
                    ->like('id_validasi_pendaftaran', '1')
                    ->like('tahun_akademik', $tahun_akademik)
                    ->like('nama_mahasiswa', $keyword)
                    ->orderBy('id_mahasiswa DESC')
                    ->get()->getResultArray();
            }
        }
    }

    public function GetMahasiswa3($tahun_akademik = false, $keyword = false)
    {
        if ($tahun_akademik == false) {
            return $this->table('mahasiswa_baru')
                ->join('jenis_kelamin', 'jenis_kelamin.id_jenis_kelamin=mahasiswa_baru.id_jenis_kelamin')
                ->join('agama', 'agama.id_agama=mahasiswa_baru.id_agama')
                ->join('negara', 'negara.id_wn=mahasiswa_baru.id_wn')
                ->join('pendidikan_ortu', 'pendidikan_ortu.id_pendidikan=mahasiswa_baru.id_pendidikan_ayah')
                ->join('pekerjaan', 'pekerjaan.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ayah')
                ->join('pendidikan_ortu_2', 'pendidikan_ortu_2.id_pendidikan=mahasiswa_baru.id_pendidikan_ibu')
                ->join('pekerjaan_2', 'pekerjaan_2.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ibu')
                ->join('penghasilan', 'penghasilan.id_penghasilan_wali=mahasiswa_baru.id_penghasilan_wali')
                ->join('kawin', 'kawin.id_status=mahasiswa_baru.id_status')
                ->join('jalur_pendaftaran', 'jalur_pendaftaran.id_jalur_pendaftaran=mahasiswa_baru.id_jalur_pendaftaran')
                ->orderBy('id_mahasiswa DESC')
                ->get()->getResultArray();
        } else {
            if ($keyword == false) {
                return $this->table('mahasiswa_baru')
                    ->join('jenis_kelamin', 'jenis_kelamin.id_jenis_kelamin=mahasiswa_baru.id_jenis_kelamin')
                    ->join('agama', 'agama.id_agama=mahasiswa_baru.id_agama')
                    ->join('negara', 'negara.id_wn=mahasiswa_baru.id_wn')
                    ->join('pendidikan_ortu', 'pendidikan_ortu.id_pendidikan=mahasiswa_baru.id_pendidikan_ayah')
                    ->join('pekerjaan', 'pekerjaan.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ayah')
                    ->join('pendidikan_ortu_2', 'pendidikan_ortu_2.id_pendidikan=mahasiswa_baru.id_pendidikan_ibu')
                    ->join('pekerjaan_2', 'pekerjaan_2.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ibu')
                    ->join('penghasilan', 'penghasilan.id_penghasilan_wali=mahasiswa_baru.id_penghasilan_wali')
                    ->join('kawin', 'kawin.id_status=mahasiswa_baru.id_status')
                    ->join('jalur_pendaftaran', 'jalur_pendaftaran.id_jalur_pendaftaran=mahasiswa_baru.id_jalur_pendaftaran')
                    ->like('id_validasi_pendaftaran', '1')
                    ->like('tahun_akademik', $tahun_akademik)
                    ->orderBy('id_mahasiswa DESC')
                    ->get()->getResultArray();
            } else {
                return $this->table('mahasiswa_baru')
                    ->join('jenis_kelamin', 'jenis_kelamin.id_jenis_kelamin=mahasiswa_baru.id_jenis_kelamin')
                    ->join('agama', 'agama.id_agama=mahasiswa_baru.id_agama')
                    ->join('negara', 'negara.id_wn=mahasiswa_baru.id_wn')
                    ->join('pendidikan_ortu', 'pendidikan_ortu.id_pendidikan=mahasiswa_baru.id_pendidikan_ayah')
                    ->join('pekerjaan', 'pekerjaan.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ayah')
                    ->join('pendidikan_ortu_2', 'pendidikan_ortu_2.id_pendidikan=mahasiswa_baru.id_pendidikan_ibu')
                    ->join('pekerjaan_2', 'pekerjaan_2.id_pekerjaan=mahasiswa_baru.id_pekerjaan_ibu')
                    ->join('penghasilan', 'penghasilan.id_penghasilan_wali=mahasiswa_baru.id_penghasilan_wali')
                    ->join('kawin', 'kawin.id_status=mahasiswa_baru.id_status')
                    ->join('jalur_pendaftaran', 'jalur_pendaftaran.id_jalur_pendaftaran=mahasiswa_baru.id_jalur_pendaftaran')
                    ->like('id_validasi_pendaftaran', '1')
                    ->like('tahun_akademik', $tahun_akademik)
                    ->like('nama_mahasiswa', $keyword)
                    ->orderBy('id_mahasiswa DESC')
                    ->get()->getResultArray();
            }
        }
    }



    public function getGelombang()
    {
        return $this->db->table('gelombang')
            ->get()->getResult();
    }

    public function getJalurPendaftaran()
    {
        return $this->db->table('jalur_pendaftaran')
            ->get()->getResult();
    }

    public function getStatusPendaftaran()
    {
        return $this->db->table('pendaftaran')
            ->get()->getResult();
    }

    public function getJenisKelamin()
    {
        return $this->db->table('jenis_kelamin')
            ->get()->getResult();
    }

    public function getAgamaa()
    {
        return $this->db->table('agama')
            ->get()->getResult();
    }

    public function getNegaraa()
    {
        return $this->db->table('negara')
            ->get()->getResult();
    }

    public function getStatuss()
    {
        return $this->db->table('kawin')
            ->get()->getResult();
    }

    public function getPendidikan()
    {
        return $this->db->table('pendidikan_ortu')
            ->get()->getResult();
    }

    public function getPekerjaan()
    {
        return $this->db->table('pekerjaan')
            ->get()->getResult();
    }

    public function getPenghasilann()
    {
        return $this->db->table('penghasilan')
            ->get()->getResult();
    }

    public function getJurusann()
    {
        return $this->db->table('jurusan')
            ->orderBy('id_fak ASC')
            ->like('id_atr', '1')
            ->get()->getResult();
    }

    public function getJurusann3()
    {
        return $this->db->table('jurusan')
            ->like('id_atr', '2')
            ->get()->getResult();
    }

    public function getJurusann2()
    {
        return $this->db->table('jurusan_2')
            ->like('id_atr_2', '1')
            ->get()->getResult();
    }

    public function getJurusann4()
    {
        return $this->db->table('jurusan_2')
            ->like('id_atr_2', '2')
            ->get()->getResult();
    }

    public function getJalur()
    {
        return $this->db->table('jalur_pendaftaran')
            ->get()->getResultArray();
    }

    public function getKelamin()
    {
        return $this->db->table('jenis_kelamin')
            ->get()->getResultArray();
    }

    public function getAgama()
    {
        return $this->db->table('agama')
            ->get()->getResultArray();
    }

    public function getNegara()
    {
        return $this->db->table('negara')
            ->get()->getResultArray();
    }

    public function getStatus()
    {
        return $this->db->table('kawin')
            ->get()->getResultArray();
    }

    public function getPendidikanOrtu()
    {
        return $this->db->table('pendidikan_ortu')
            ->get()->getResultArray();
    }

    public function getPekerjaanOrtu()
    {
        return $this->db->table('pekerjaan')
            ->get()->getResultArray();
    }

    public function getJurusan()
    {
        return $this->db->table('jurusan')
            ->like('id_atr', '1')
            ->get()->getResultArray();
    }
    public function getJurusan2()
    {
        return $this->db->table('jurusan_2')
            ->like('id_atr_2', '1')
            ->get()->getResultArray();
    }
    public function getJurusan3()
    {
        return $this->db->table('jurusan')
            ->like('id_atr', '2')
            ->get()->getResultArray();
    }
    public function getJurusan4()
    {
        return $this->db->table('jurusan_2')
            ->like('id_atr_2', '2')
            ->get()->getResultArray();
    }
    public function GetPenghasilan()
    {
        return $this->db->table('penghasilan')
            ->get()->getResultArray();
    }
    public function GetPendaftaran()
    {
        return $this->db->table('pendaftaran')
            ->get()->getResultArray();
    }
    public function GetValidasi()
    {
        return $this->db->table('validasi')
            ->get()->getResultArray();
    }
    public function GetGelombangg()
    {
        return $this->db->table('gelombang')
            ->get()->getResultArray();
    }
    public function GetAllPendaftar($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetHaveValidation($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_validasi_pendaftaran', '1')
            ->like('id_status_pendaftaran', '2')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetNotValidation($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_validasi_pendaftaran', '0')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetCountLaki($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_jenis_kelamin', '1')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetCountCewek($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_jenis_kelamin', '2')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetCountGel1($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_gelombang', '1')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetCountGel2($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_gelombang', '2')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPai1($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_1', '5')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPai2($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_2', '5')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPgmi1($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_1', '6')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPgmi2($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_2', '6')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPiaud1($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_1', '7')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPiaud2($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_2', '7')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetEkos1($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_1', '1')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetEkos2($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_2', '1')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPs1($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_1', '2')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPs2($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_2', '2')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetHki1($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_1', '4')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetHki2($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_2', '4')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPmi1($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_1', '3')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPmi2($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_2', '3')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetMat1($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_1', '11')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetMat2($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_2', '11')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
    public function GetPasca($tahun_akademik)
    {
        return $this->db->table('mahasiswa_baru')
            ->like('id_pilihan_1', '8')
            ->like('tahun_akademik', $tahun_akademik)
            ->countAllResults();
    }
}
