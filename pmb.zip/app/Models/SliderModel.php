<?php

namespace App\Models;

use CodeIgniter\Model;

class SliderModel extends Model
{
    protected $table      = 'slider';
    protected $primaryKey = 'id_slider';
    protected $useTimestamps = false;
    protected $allowedFields = ['nama_slider'];
}
