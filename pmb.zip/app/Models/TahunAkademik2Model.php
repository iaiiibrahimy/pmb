<?php

namespace App\Models;

use CodeIgniter\Model;

class TahunAkademik2Model extends Model
{
    protected $table      = 'tahun_akademik';
    protected $primaryKey = 'id_tahun_akademik';
    protected $useTimestamps = false;
    protected $allowedFields = ['id_tahun_akademik', 'nama_tahun_akademik'];
}
