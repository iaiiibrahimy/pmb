<?php

namespace App\Models;

use CodeIgniter\Model;

class DeveloperModel extends Model
{
    protected $table      = 'developer';
    protected $primaryKey = 'id_developer';
    protected $useTimestamps = true;
    protected $allowedFields = ['username', 'nama_developer', 'password'];

    public function CountDeveloper()
    {
    }
}
