-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2022 at 08:57 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `agama`
--

CREATE TABLE `agama` (
  `id_agama` int(11) NOT NULL,
  `agama` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agama`
--

INSERT INTO `agama` (`id_agama`, `agama`) VALUES
(1, 'ISLAM'),
(2, 'KRISTEN'),
(3, 'KATHOLIK'),
(4, 'HINDU'),
(5, 'BUDHA'),
(6, 'KONGHUCHU'),
(99, 'LAINNYA');

-- --------------------------------------------------------

--
-- Table structure for table `data_offline`
--

CREATE TABLE `data_offline` (
  `id_data_offline` int(11) NOT NULL,
  `gelombang` text NOT NULL,
  `nomor_test` text NOT NULL,
  `program_studi` int(11) NOT NULL,
  `nama` text NOT NULL,
  `jenis_kelamin` int(11) NOT NULL,
  `ttl` text NOT NULL,
  `tempat_lahir` text NOT NULL,
  `agama` int(11) NOT NULL,
  `nama_kelurahan` text NOT NULL,
  `nama_kecamatan` text NOT NULL,
  `nama_ibu` text NOT NULL,
  `kewarganegaraan` int(11) NOT NULL,
  `nisn` text NOT NULL,
  `nik` text NOT NULL,
  `nama_jalan` text NOT NULL,
  `rt` text NOT NULL,
  `rw` text NOT NULL,
  `dusun` text NOT NULL,
  `hp` text NOT NULL,
  `email` text NOT NULL,
  `nama_ayah` text NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `developer`
--

CREATE TABLE `developer` (
  `id_developer` int(11) NOT NULL,
  `username` text NOT NULL,
  `nama_developer` text NOT NULL,
  `password` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `developer`
--

INSERT INTO `developer` (`id_developer`, `username`, `nama_developer`, `password`, `created_at`, `updated_at`) VALUES
(1, 'sudirman', 'GHASFDOUW', '$2y$10$yn3OUtywoLgZWcf7wCaWcOkgrYrCercGbeL6qqBsI04Mb4sLlzm3e', '2021-02-02 21:34:03', '2021-02-02 21:34:03');

-- --------------------------------------------------------

--
-- Table structure for table `gelombang`
--

CREATE TABLE `gelombang` (
  `id_gelombang` int(11) NOT NULL,
  `gelombang` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gelombang`
--

INSERT INTO `gelombang` (`id_gelombang`, `gelombang`) VALUES
(0, 'PILIH GELOMBANG'),
(1, 'GELOMBANG 1'),
(2, 'GELOMBANG 2'),
(3, 'GELOMBANG 3');

-- --------------------------------------------------------

--
-- Table structure for table `gelombang_status`
--

CREATE TABLE `gelombang_status` (
  `id_gelombang_status` int(11) NOT NULL,
  `id_gelombang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gelombang_status`
--

INSERT INTO `gelombang_status` (`id_gelombang_status`, `id_gelombang`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jalur_pendaftaran`
--

CREATE TABLE `jalur_pendaftaran` (
  `id_jalur_pendaftaran` int(11) NOT NULL,
  `jalur_pendaftaran` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jalur_pendaftaran`
--

INSERT INTO `jalur_pendaftaran` (`id_jalur_pendaftaran`, `jalur_pendaftaran`) VALUES
(1, 'REGULER'),
(2, 'BEASISWA PRESTASI'),
(3, 'BEASISWA TAHFIDZ'),
(4, 'BEASISWA BINA LINGKUNGAN');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_kelamin`
--

CREATE TABLE `jenis_kelamin` (
  `id_jenis_kelamin` int(11) NOT NULL,
  `jenis_kelamin` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jenis_kelamin`
--

INSERT INTO `jenis_kelamin` (`id_jenis_kelamin`, `jenis_kelamin`) VALUES
(1, 'LAKI-LAKI'),
(2, 'PEREMPUAN');

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE `jurusan` (
  `id_jurusan` int(11) NOT NULL,
  `nama_jurusan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id_jurusan`, `nama_jurusan`) VALUES
(1, 'S1 EKONOMI SYARIAH (FAKULTAS EKONOMI DAN BISNIS ISLAM)'),
(2, 'S1 PERBANKAN SYARIAH (FAKULTAS EKONOMI DAN BISNIS ISLAM)'),
(3, 'S1 PENGEMBANGAN MASYARAKAT ISLAM (FAKULTAS DAKWAH)'),
(4, 'S1 HUKUM KELUARGA ISLAM (FAKULTAS SYARIAH)'),
(5, 'S1 PENDIDIKAN AGAMA ISLAM (FAKULTAS TARBIYAH)'),
(6, 'S1 PENDIDIKAN GURU MI (FAKULTAS TARBIYAH)'),
(7, 'S1 PENDIDIKAN ISLAM ANAK USIA DINI (FAKULTAS TARBIYAH)');

-- --------------------------------------------------------

--
-- Table structure for table `jurusan_2`
--

CREATE TABLE `jurusan_2` (
  `id_jurusan` int(11) NOT NULL,
  `nama_jurusan_2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jurusan_2`
--

INSERT INTO `jurusan_2` (`id_jurusan`, `nama_jurusan_2`) VALUES
(1, 'S1 EKONOMI SYARIAH (FAKULTAS EKONOMI DAN BISNIS ISLAM)'),
(2, 'S1 PERBANKAN SYARIAH (FAKULTAS EKONOMI DAN BISNIS ISLAM)'),
(3, 'S1 PENGEMBANGAN MASYARAKAT ISLAM (FAKULTAS DAKWAH)'),
(4, 'S1 HUKUM KELUARGA ISLAM (FAKULTAS SYARIAH)'),
(5, 'S1 PENDIDIKAN AGAMA ISLAM (FAKULTAS TARBIYAH)'),
(6, 'S1 PENDIDIKAN GURU MI (FAKULTAS TARBIYAH)'),
(7, 'S1 PENDIDIKAN ISLAM ANAK USIA DINI (FAKULTAS TARBIYAH)');

-- --------------------------------------------------------

--
-- Table structure for table `kartu`
--

CREATE TABLE `kartu` (
  `id_kartu` int(11) NOT NULL,
  `kartu` varchar(100) NOT NULL,
  `ttd` text NOT NULL,
  `nama_ketua` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kartu`
--

INSERT INTO `kartu` (`id_kartu`, `kartu`, `ttd`, `nama_ketua`) VALUES
(1, 'jadwal-tes.png', 'ttd.png', 'MOH. ANAS SYAMSUDIN, M.PD');

-- --------------------------------------------------------

--
-- Table structure for table `kawin`
--

CREATE TABLE `kawin` (
  `id_status` int(11) NOT NULL,
  `nama_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kawin`
--

INSERT INTO `kawin` (`id_status`, `nama_status`) VALUES
(1, 'SUDAH KAWIN'),
(2, 'BELUM KAWIN'),
(3, 'DUDA'),
(4, 'JANDA');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa_baru`
--

CREATE TABLE `mahasiswa_baru` (
  `id_mahasiswa` int(11) NOT NULL,
  `id_status_pendaftaran` int(11) NOT NULL,
  `id_gelombang` int(11) NOT NULL,
  `id_jalur_pendaftaran` int(11) NOT NULL,
  `id_validasi_pendaftaran` int(11) NOT NULL,
  `tanggal_daftar` text NOT NULL,
  `nomor_pendaftaran` text NOT NULL,
  `bukti_pembayaran` text NOT NULL,
  `nama_mahasiswa` text NOT NULL,
  `nik` text NOT NULL,
  `tempat_lahir` text NOT NULL,
  `tanggal_lahir` text NOT NULL,
  `bulan_lahir` text NOT NULL,
  `tahun_lahir` text NOT NULL,
  `id_jenis_kelamin` int(11) NOT NULL,
  `id_agama` int(11) NOT NULL,
  `id_wn` int(11) NOT NULL,
  `id_status` int(11) NOT NULL,
  `nama_jalan` text NOT NULL,
  `rt` text NOT NULL,
  `rw` text NOT NULL,
  `dusun` text NOT NULL,
  `kelurahan` text NOT NULL,
  `kecamatan` text NOT NULL,
  `kabupaten` text NOT NULL,
  `no_hp` text NOT NULL,
  `asal_sekolah` text NOT NULL,
  `nisn` text NOT NULL,
  `tahun_lulus` text NOT NULL,
  `nama_tempat_kerja` text NOT NULL,
  `alamat_tempat_kerja` text NOT NULL,
  `nomor_telephone_kerja` text NOT NULL,
  `nama_ayah` text NOT NULL,
  `id_pendidikan_ayah` int(11) NOT NULL,
  `id_pekerjaan_ayah` int(11) NOT NULL,
  `nama_ibu` text NOT NULL,
  `id_pendidikan_ibu` int(11) NOT NULL,
  `id_pekerjaan_ibu` int(11) NOT NULL,
  `id_penghasilan_wali` int(11) NOT NULL,
  `alamat_wali` text NOT NULL,
  `nomor_hp_wali` text NOT NULL,
  `id_pilihan_1` int(11) NOT NULL,
  `id_pilihan_2` int(11) NOT NULL,
  `tahun_akademik` int(11) NOT NULL,
  `nama_rekomendasi` text NOT NULL,
  `nomor_rekomendasi` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `negara`
--

CREATE TABLE `negara` (
  `id_wn` int(11) NOT NULL,
  `nama_negara` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `negara`
--

INSERT INTO `negara` (`id_wn`, `nama_negara`) VALUES
(1, 'INDONESIA\r\n'),
(2, 'MALAYSIA'),
(3, 'SINGAPURA'),
(4, 'BRUNEI DARUSSALAM'),
(5, 'NEGARA TIMUR TENGAH (ARAB)'),
(6, 'NEGARA LAINNYA DI BENUA ASIA'),
(7, 'NEGARA DI BENUA AFRIKA'),
(8, 'NEGARA DI BENUA EROPA'),
(9, 'NEGARA DI BENUA LAINNYA');

-- --------------------------------------------------------

--
-- Table structure for table `panitia_pmb`
--

CREATE TABLE `panitia_pmb` (
  `id_panitia` int(11) NOT NULL,
  `username` text NOT NULL,
  `nama_panitia` text NOT NULL,
  `password` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `panitia_pmb`
--

INSERT INTO `panitia_pmb` (`id_panitia`, `username`, `nama_panitia`, `password`, `created_at`, `updated_at`) VALUES
(1, 'andre', 'ANFDG', '$2y$10$t2wnaqOs2VHzfBG1x9mp1O4zei8hN64XpCrxRLAM8wzxDabncN/Ci', '2021-02-02 21:32:04', '2021-02-02 21:32:04');

-- --------------------------------------------------------

--
-- Table structure for table `pekerjaan`
--

CREATE TABLE `pekerjaan` (
  `id_pekerjaan` int(11) NOT NULL,
  `pekerjaan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pekerjaan`
--

INSERT INTO `pekerjaan` (`id_pekerjaan`, `pekerjaan`) VALUES
(1, 'TIDAK BEKERJA'),
(2, 'PENSIUNAN/ALMARHUM'),
(3, 'PNS (SELAIN GURU, DOSEN, DOKTER, BIDAN, DAN PERAWAT)'),
(4, 'TNI/POLISI'),
(5, 'GURU/DOSEN'),
(6, 'PEGAWAI SWASTA'),
(7, 'PENGUSAHA/WIRASWASTA'),
(8, 'PENGACARA/HAKIM/JAKSA/NOTARIS'),
(9, 'SENIMAN/PELUKIS/ARTIS/SEJENIS'),
(10, 'DOKTER/BIDAN/PERAWAT'),
(11, 'PILOT/PRAMUGARI'),
(12, 'PEDAGANG'),
(13, 'PETANI/PETERNAK'),
(14, 'NELAYAN'),
(15, 'BURUH (TANI/PABRIK/BANGUNAN)'),
(16, 'SOPIR/MASINIS/KONDEKTUR'),
(17, 'POLITIKUS'),
(18, 'LAINNYA');

-- --------------------------------------------------------

--
-- Table structure for table `pekerjaan_2`
--

CREATE TABLE `pekerjaan_2` (
  `id_pekerjaan` int(11) NOT NULL,
  `pekerjaan_2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pekerjaan_2`
--

INSERT INTO `pekerjaan_2` (`id_pekerjaan`, `pekerjaan_2`) VALUES
(1, 'TIDAK BEKERJA'),
(2, 'PENSIUNAN/ALMARHUM'),
(3, 'PNS (SELAIN GURU, DOSEN, DOKTER, BIDAN, DAN PERAWAT)'),
(4, 'TNI/POLISI'),
(5, 'GURU/DOSEN'),
(6, 'PEGAWAI SWASTA'),
(7, 'PENGUSAHA/WIRASWASTA'),
(8, 'PENGACARA/HAKIM/JAKSA/NOTARIS'),
(9, 'SENIMAN/PELUKIS/ARTIS/SEJENIS'),
(10, 'DOKTER/BIDAN/PERAWAT'),
(11, 'PILOT/PRAMUGARI'),
(12, 'PEDAGANG'),
(13, 'PETANI/PETERNAK'),
(14, 'NELAYAN'),
(15, 'BURUH (TANI/PABRIK/BANGUNAN)'),
(16, 'SOPIR/MASINIS/KONDEKTUR'),
(17, 'POLITIKUS'),
(18, 'LAINNYA');

-- --------------------------------------------------------

--
-- Table structure for table `pendaftaran`
--

CREATE TABLE `pendaftaran` (
  `id_status_pendaftaran` int(11) NOT NULL,
  `nama_pendaftaran` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pendaftaran`
--

INSERT INTO `pendaftaran` (`id_status_pendaftaran`, `nama_pendaftaran`) VALUES
(1, 'MAHASISWA BARU'),
(2, 'MAHASISWA PINDAHAN'),
(3, 'MAHASISWA TRANSFER');

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan_ortu`
--

CREATE TABLE `pendidikan_ortu` (
  `id_pendidikan` int(11) NOT NULL,
  `pendidikan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pendidikan_ortu`
--

INSERT INTO `pendidikan_ortu` (`id_pendidikan`, `pendidikan`) VALUES
(1, '<= SLTA'),
(2, 'DIPLOMA'),
(3, 'S1'),
(4, 'S2'),
(5, 'S3'),
(6, 'TIDAK BERPENDIDIKAN FORMAL');

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan_ortu_2`
--

CREATE TABLE `pendidikan_ortu_2` (
  `id_pendidikan` int(11) NOT NULL,
  `pendidikan_2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pendidikan_ortu_2`
--

INSERT INTO `pendidikan_ortu_2` (`id_pendidikan`, `pendidikan_2`) VALUES
(1, '<= SLTA'),
(2, 'DIPLOMA'),
(3, 'S1'),
(4, 'S2'),
(5, 'S3'),
(6, 'TIDAK BERPENDIDIKAN FORMAL');

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan`
--

CREATE TABLE `pengaturan` (
  `id_pengaturan` int(11) NOT NULL,
  `alamat_jalan` varchar(1000) NOT NULL,
  `alamat_desa` varchar(1000) NOT NULL,
  `alamat_provinsi` varchar(1000) NOT NULL,
  `telephone` varchar(1000) NOT NULL,
  `email_sekolah` varchar(1000) NOT NULL,
  `twitter_sekolah` varchar(1000) NOT NULL,
  `facebook_sekolah` varchar(1000) NOT NULL,
  `instagram_sekolah` varchar(1000) NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengaturan`
--

INSERT INTO `pengaturan` (`id_pengaturan`, `alamat_jalan`, `alamat_desa`, `alamat_provinsi`, `telephone`, `email_sekolah`, `twitter_sekolah`, `facebook_sekolah`, `instagram_sekolah`, `updated_at`) VALUES
(1, 'Jl. KH. Hasyim Asy`ari No. 1', 'Genteng, Banyuwangi 68465', 'Jawa Timur ', '(0333) 845654', 'admin@iaiibrahimy.ac.id', 'https://twitter.com/iaiibrahimygtg', 'https://facebook.com/profile.php?id=100011571872385', 'https://www.instagram.com/iaiibrahimy_official', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `penghasilan`
--

CREATE TABLE `penghasilan` (
  `id_penghasilan_wali` int(11) NOT NULL,
  `penghasilan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `penghasilan`
--

INSERT INTO `penghasilan` (`id_penghasilan_wali`, `penghasilan`) VALUES
(1, 'DIBAWAH RP. 1.000.000'),
(2, 'RP. 1.000.000 - RP. 2.000.000'),
(3, 'RP. 2.000.001 - RP. 4.000.000'),
(4, 'RP. 4.000.001 - RP 6.000.000'),
(5, 'DIATAS RP. 6.000.000');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id_slider` int(11) NOT NULL,
  `nama_slider` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id_slider`, `nama_slider`) VALUES
(1, 'slider1.jpg'),
(2, 'slider2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `status_pendaftaran`
--

CREATE TABLE `status_pendaftaran` (
  `id_status_pendaftarans` int(11) NOT NULL,
  `nama_status_pendaftaran` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status_pendaftaran`
--

INSERT INTO `status_pendaftaran` (`id_status_pendaftarans`, `nama_status_pendaftaran`) VALUES
(1, 'OFFLINE'),
(2, 'ONLINE');

-- --------------------------------------------------------

--
-- Table structure for table `tahun_akademik`
--

CREATE TABLE `tahun_akademik` (
  `id_tahun_akademik` int(11) NOT NULL,
  `nama_tahun_akademik` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tahun_akademik`
--

INSERT INTO `tahun_akademik` (`id_tahun_akademik`, `nama_tahun_akademik`) VALUES
(1, '2019/2020'),
(2, '2020/2021'),
(3, '2021/2022'),
(4, '2022/2023');

-- --------------------------------------------------------

--
-- Table structure for table `tahun_akademik_status`
--

CREATE TABLE `tahun_akademik_status` (
  `id_tahun_akademik_status` int(11) NOT NULL,
  `id_tahun_akademiks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tahun_akademik_status`
--

INSERT INTO `tahun_akademik_status` (`id_tahun_akademik_status`, `id_tahun_akademiks`) VALUES
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tutup_pendaftaran`
--

CREATE TABLE `tutup_pendaftaran` (
  `id_tutup_pendaftaran` int(11) NOT NULL,
  `status_tutup_pendaftaran` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tutup_pendaftaran`
--

INSERT INTO `tutup_pendaftaran` (`id_tutup_pendaftaran`, `status_tutup_pendaftaran`) VALUES
(1, 'BUKA'),
(2, 'TUTUP');

-- --------------------------------------------------------

--
-- Table structure for table `tutup_pendaftaran_status`
--

CREATE TABLE `tutup_pendaftaran_status` (
  `id_tutup_pendaftaran_status` int(11) NOT NULL,
  `id_tutup_pendaftaran` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tutup_pendaftaran_status`
--

INSERT INTO `tutup_pendaftaran_status` (`id_tutup_pendaftaran_status`, `id_tutup_pendaftaran`) VALUES
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `validasi`
--

CREATE TABLE `validasi` (
  `id_validasi` int(11) NOT NULL,
  `validasi` text NOT NULL,
  `nama_validasi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `validasi`
--

INSERT INTO `validasi` (`id_validasi`, `validasi`, `nama_validasi`) VALUES
(0, 'disabled', 'BELUM VALIDASI'),
(1, 'enable', 'SUDAH VALIDASI');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agama`
--
ALTER TABLE `agama`
  ADD PRIMARY KEY (`id_agama`);

--
-- Indexes for table `data_offline`
--
ALTER TABLE `data_offline`
  ADD PRIMARY KEY (`id_data_offline`);

--
-- Indexes for table `developer`
--
ALTER TABLE `developer`
  ADD PRIMARY KEY (`id_developer`);

--
-- Indexes for table `gelombang`
--
ALTER TABLE `gelombang`
  ADD PRIMARY KEY (`id_gelombang`);

--
-- Indexes for table `gelombang_status`
--
ALTER TABLE `gelombang_status`
  ADD PRIMARY KEY (`id_gelombang_status`);

--
-- Indexes for table `jalur_pendaftaran`
--
ALTER TABLE `jalur_pendaftaran`
  ADD PRIMARY KEY (`id_jalur_pendaftaran`);

--
-- Indexes for table `jenis_kelamin`
--
ALTER TABLE `jenis_kelamin`
  ADD PRIMARY KEY (`id_jenis_kelamin`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`id_jurusan`);

--
-- Indexes for table `jurusan_2`
--
ALTER TABLE `jurusan_2`
  ADD PRIMARY KEY (`id_jurusan`);

--
-- Indexes for table `kartu`
--
ALTER TABLE `kartu`
  ADD PRIMARY KEY (`id_kartu`);

--
-- Indexes for table `kawin`
--
ALTER TABLE `kawin`
  ADD PRIMARY KEY (`id_status`);

--
-- Indexes for table `mahasiswa_baru`
--
ALTER TABLE `mahasiswa_baru`
  ADD PRIMARY KEY (`id_mahasiswa`);

--
-- Indexes for table `negara`
--
ALTER TABLE `negara`
  ADD PRIMARY KEY (`id_wn`);

--
-- Indexes for table `panitia_pmb`
--
ALTER TABLE `panitia_pmb`
  ADD PRIMARY KEY (`id_panitia`);

--
-- Indexes for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  ADD PRIMARY KEY (`id_pekerjaan`);

--
-- Indexes for table `pekerjaan_2`
--
ALTER TABLE `pekerjaan_2`
  ADD PRIMARY KEY (`id_pekerjaan`);

--
-- Indexes for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  ADD PRIMARY KEY (`id_status_pendaftaran`);

--
-- Indexes for table `pendidikan_ortu`
--
ALTER TABLE `pendidikan_ortu`
  ADD PRIMARY KEY (`id_pendidikan`);

--
-- Indexes for table `pendidikan_ortu_2`
--
ALTER TABLE `pendidikan_ortu_2`
  ADD PRIMARY KEY (`id_pendidikan`);

--
-- Indexes for table `pengaturan`
--
ALTER TABLE `pengaturan`
  ADD PRIMARY KEY (`id_pengaturan`);

--
-- Indexes for table `penghasilan`
--
ALTER TABLE `penghasilan`
  ADD PRIMARY KEY (`id_penghasilan_wali`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id_slider`);

--
-- Indexes for table `status_pendaftaran`
--
ALTER TABLE `status_pendaftaran`
  ADD PRIMARY KEY (`id_status_pendaftarans`);

--
-- Indexes for table `tahun_akademik`
--
ALTER TABLE `tahun_akademik`
  ADD PRIMARY KEY (`id_tahun_akademik`);

--
-- Indexes for table `tahun_akademik_status`
--
ALTER TABLE `tahun_akademik_status`
  ADD PRIMARY KEY (`id_tahun_akademik_status`);

--
-- Indexes for table `tutup_pendaftaran`
--
ALTER TABLE `tutup_pendaftaran`
  ADD PRIMARY KEY (`id_tutup_pendaftaran`);

--
-- Indexes for table `tutup_pendaftaran_status`
--
ALTER TABLE `tutup_pendaftaran_status`
  ADD PRIMARY KEY (`id_tutup_pendaftaran_status`);

--
-- Indexes for table `validasi`
--
ALTER TABLE `validasi`
  ADD PRIMARY KEY (`id_validasi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agama`
--
ALTER TABLE `agama`
  MODIFY `id_agama` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `data_offline`
--
ALTER TABLE `data_offline`
  MODIFY `id_data_offline` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `developer`
--
ALTER TABLE `developer`
  MODIFY `id_developer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gelombang`
--
ALTER TABLE `gelombang`
  MODIFY `id_gelombang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gelombang_status`
--
ALTER TABLE `gelombang_status`
  MODIFY `id_gelombang_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jalur_pendaftaran`
--
ALTER TABLE `jalur_pendaftaran`
  MODIFY `id_jalur_pendaftaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jenis_kelamin`
--
ALTER TABLE `jenis_kelamin`
  MODIFY `id_jenis_kelamin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `id_jurusan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `kartu`
--
ALTER TABLE `kartu`
  MODIFY `id_kartu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kawin`
--
ALTER TABLE `kawin`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mahasiswa_baru`
--
ALTER TABLE `mahasiswa_baru`
  MODIFY `id_mahasiswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `negara`
--
ALTER TABLE `negara`
  MODIFY `id_wn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `panitia_pmb`
--
ALTER TABLE `panitia_pmb`
  MODIFY `id_panitia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  MODIFY `id_pekerjaan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `pekerjaan_2`
--
ALTER TABLE `pekerjaan_2`
  MODIFY `id_pekerjaan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  MODIFY `id_status_pendaftaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pendidikan_ortu`
--
ALTER TABLE `pendidikan_ortu`
  MODIFY `id_pendidikan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pendidikan_ortu_2`
--
ALTER TABLE `pendidikan_ortu_2`
  MODIFY `id_pendidikan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pengaturan`
--
ALTER TABLE `pengaturan`
  MODIFY `id_pengaturan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `penghasilan`
--
ALTER TABLE `penghasilan`
  MODIFY `id_penghasilan_wali` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id_slider` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `status_pendaftaran`
--
ALTER TABLE `status_pendaftaran`
  MODIFY `id_status_pendaftarans` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tahun_akademik`
--
ALTER TABLE `tahun_akademik`
  MODIFY `id_tahun_akademik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tahun_akademik_status`
--
ALTER TABLE `tahun_akademik_status`
  MODIFY `id_tahun_akademik_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tutup_pendaftaran`
--
ALTER TABLE `tutup_pendaftaran`
  MODIFY `id_tutup_pendaftaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tutup_pendaftaran_status`
--
ALTER TABLE `tutup_pendaftaran_status`
  MODIFY `id_tutup_pendaftaran_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `validasi`
--
ALTER TABLE `validasi`
  MODIFY `id_validasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
